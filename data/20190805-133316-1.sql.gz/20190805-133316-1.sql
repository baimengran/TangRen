-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : tangren
-- 
-- Part : #1
-- Date : 2019-08-05 13:33:16
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `think_about`
-- -----------------------------
DROP TABLE IF EXISTS `think_about`;
CREATE TABLE `think_about` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '关于我们表',
  `img` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '图片',
  `content` text CHARACTER SET utf8 COMMENT '详细信息',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

-- -----------------------------
-- Records of `think_about`
-- -----------------------------
INSERT INTO `think_about` VALUES ('1', 'http://ceshi.800123456.top//public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '关于我们aiwfabwgagwegbiprngpibeigppinaegipwngpignwe');

-- -----------------------------
-- Table structure for `think_ad`
-- -----------------------------
DROP TABLE IF EXISTS `think_ad`;
CREATE TABLE `think_ad` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(64) DEFAULT NULL,
  `ad_position_id` varchar(10) DEFAULT NULL COMMENT '广告位',
  `link_url` varchar(128) DEFAULT NULL,
  `images` varchar(128) DEFAULT NULL,
  `start_date` date DEFAULT NULL COMMENT '开始时间',
  `end_date` date DEFAULT NULL COMMENT '结束时间',
  `status` tinyint(1) DEFAULT NULL COMMENT '状态',
  `closed` tinyint(1) DEFAULT '0',
  `orderby` tinyint(3) DEFAULT '100',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_ad`
-- -----------------------------
INSERT INTO `think_ad` VALUES ('24', '23', '1', '123', '20170416\\363c841674371a9e730e65a085fbdf18.jpg', '0000-00-00', '0000-00-00', '1', '0', '23');
INSERT INTO `think_ad` VALUES ('25', '123', '1', '213', '20170416\\d8f2098b4846f2e087cc2c5dd1575219.jpg', '2016-10-12', '2016-10-12', '1', '0', '100');
INSERT INTO `think_ad` VALUES ('26', '345', '1', '345', '20170416\\f59059c762d959f04f9226eb0c126987.jpg', '2016-10-25', '2016-10-20', '0', '1', '127');

-- -----------------------------
-- Table structure for `think_ad_position`
-- -----------------------------
DROP TABLE IF EXISTS `think_ad_position`;
CREATE TABLE `think_ad_position` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) DEFAULT NULL COMMENT '分类名称',
  `orderby` varchar(10) DEFAULT '100' COMMENT '排序',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `update_time` int(11) DEFAULT NULL COMMENT '更新时间',
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_ad_position`
-- -----------------------------
INSERT INTO `think_ad_position` VALUES ('23', 'aaa', '30', '1501813046', '1501813046', '1');
INSERT INTO `think_ad_position` VALUES ('22', 'abvc', '15', '1501813036', '1502294001', '1');
INSERT INTO `think_ad_position` VALUES ('25', '首页banner', '50', '1502181832', '1502181832', '1');
INSERT INTO `think_ad_position` VALUES ('26', '6168', '11', '1502182772', '1502182772', '1');

-- -----------------------------
-- Table structure for `think_address_phone`
-- -----------------------------
DROP TABLE IF EXISTS `think_address_phone`;
CREATE TABLE `think_address_phone` (
  `address_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户地址管理表',
  `id` int(11) DEFAULT NULL COMMENT '用户ID',
  `city` varchar(255) DEFAULT NULL COMMENT '地址',
  `name` varchar(255) DEFAULT NULL COMMENT '姓名',
  `phone` varchar(255) DEFAULT NULL COMMENT '电话',
  `default_address` int(10) DEFAULT NULL COMMENT '默认地址状态(0默认地址)',
  PRIMARY KEY (`address_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_address_phone`
-- -----------------------------
INSERT INTO `think_address_phone` VALUES ('2', '22', '', '', '', '1');
INSERT INTO `think_address_phone` VALUES ('22', '22', '1', '', '', '1');
INSERT INTO `think_address_phone` VALUES ('23', '22', '北京市房山区长阳', '', '', '1');
INSERT INTO `think_address_phone` VALUES ('31', '22', '北京市房山区aaa', '', '', '1');
INSERT INTO `think_address_phone` VALUES ('32', '22', '北京市房山区aaa', '', '', '0');
INSERT INTO `think_address_phone` VALUES ('33', '212067', '北京市朝阳区bbb', '', '', '1');
INSERT INTO `think_address_phone` VALUES ('35', '212067', '北京市房山区eee', 'awd', '张三', '1');
INSERT INTO `think_address_phone` VALUES ('36', '13', '测试地址', 'ceshi2', '123456789', '1');
INSERT INTO `think_address_phone` VALUES ('37', '13', '12312312222', '测试1', '123123123', '0');
INSERT INTO `think_address_phone` VALUES ('38', '212082', '内活到九十九我', '也一样', '2131312112', '0');
INSERT INTO `think_address_phone` VALUES ('39', '212082', '活动活动活动活动好', '爷爷', '1245454546646454', '1');

-- -----------------------------
-- Table structure for `think_admin`
-- -----------------------------
DROP TABLE IF EXISTS `think_admin`;
CREATE TABLE `think_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) COLLATE utf8_bin DEFAULT '' COMMENT '用户名',
  `password` varchar(32) COLLATE utf8_bin DEFAULT '' COMMENT '密码',
  `portrait` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT '头像',
  `loginnum` int(11) DEFAULT '0' COMMENT '登陆次数',
  `last_login_ip` varchar(255) COLLATE utf8_bin DEFAULT '' COMMENT '最后登录IP',
  `last_login_time` int(11) DEFAULT '0' COMMENT '最后登录时间',
  `real_name` varchar(20) COLLATE utf8_bin DEFAULT '' COMMENT '真实姓名',
  `status` int(1) DEFAULT '0' COMMENT '状态',
  `groupid` int(11) DEFAULT '1' COMMENT '用户角色id',
  `token` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `think_admin`
-- -----------------------------
INSERT INTO `think_admin` VALUES ('1', 'admin', '218dbb225911693af03a713581a7227f', '20161122\\admin.jpg', '367', '127.0.0.1', '1564973469', 'admin', '1', '1', '1ac2fc424c64cdf80db98a246f439287');
INSERT INTO `think_admin` VALUES ('21', 'baimengran', '3062bd30287d3fd3806950a4eff3ee05', '', '0', '', '0', '白孟冉', '1', '4', '');

-- -----------------------------
-- Table structure for `think_article`
-- -----------------------------
DROP TABLE IF EXISTS `think_article`;
CREATE TABLE `think_article` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '文章逻辑ID',
  `title` varchar(128) NOT NULL COMMENT '文章标题',
  `cate_id` int(11) NOT NULL DEFAULT '1' COMMENT '文章类别',
  `photo` varchar(64) DEFAULT '' COMMENT '文章图片',
  `remark` varchar(256) DEFAULT '' COMMENT '文章描述',
  `keyword` varchar(32) DEFAULT '' COMMENT '文章关键字',
  `content` text NOT NULL COMMENT '文章内容',
  `views` int(11) NOT NULL DEFAULT '1' COMMENT '浏览量',
  `status` tinyint(1) DEFAULT NULL,
  `type` int(1) NOT NULL DEFAULT '1' COMMENT '文章类型',
  `is_tui` int(1) DEFAULT '0' COMMENT '是否推荐',
  `from` varchar(16) NOT NULL DEFAULT '' COMMENT '来源',
  `writer` varchar(64) NOT NULL COMMENT '作者',
  `ip` varchar(16) NOT NULL,
  `create_time` int(11) NOT NULL COMMENT '创建时间',
  `update_time` int(11) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `a_title` (`title`)
) ENGINE=MyISAM AUTO_INCREMENT=69 DEFAULT CHARSET=utf8 COMMENT='文章表';

-- -----------------------------
-- Records of `think_article`
-- -----------------------------
INSERT INTO `think_article` VALUES ('46', 'PHP人民币金额数字转中文大写的函数代码', '5', '20170416\\8b2ef718255d495dc9668f0dec0224af.jpg', '在网上看到一个非常有趣的PHP人民币金额数字转中文大写的函数，其实质就是数字转换成中文大写，测试了一下，非常有趣，随便输个数字，就可以将其大写打印出来，新手朋友们试一下吧', '人民币转大写', '<p>在网上看到一个非常有趣的PHP人民币金额数字转中文大写的函数，其实质就是数字转换成中文大写，测试了一下，非常有趣，随便输个数字，就可以将其大写打印出来，新手朋友们试一下吧</p><pre class=\"brush:php;toolbar:false\">/**\n*数字金额转换成中文大写金额的函数\n*String&nbsp;Int&nbsp;&nbsp;$num&nbsp;&nbsp;要转换的小写数字或小写字符串\n*return&nbsp;大写字母\n*小数位为两位\n**/\nfunction&nbsp;get_amount($num){\n$c1&nbsp;=&nbsp;&quot;零壹贰叁肆伍陆柒捌玖&quot;;\n$c2&nbsp;=&nbsp;&quot;分角元拾佰仟万拾佰仟亿&quot;;\n$num&nbsp;=&nbsp;round($num,&nbsp;2);\n$num&nbsp;=&nbsp;$num&nbsp;*&nbsp;100;\nif&nbsp;(strlen($num)&nbsp;&gt;&nbsp;10)&nbsp;{\nreturn&nbsp;&quot;数据太长，没有这么大的钱吧，检查下&quot;;\n}&nbsp;\n$i&nbsp;=&nbsp;0;\n$c&nbsp;=&nbsp;&quot;&quot;;\nwhile&nbsp;(1)&nbsp;{\nif&nbsp;($i&nbsp;==&nbsp;0)&nbsp;{\n$n&nbsp;=&nbsp;substr($num,&nbsp;strlen($num)-1,&nbsp;1);\n}&nbsp;else&nbsp;{\n$n&nbsp;=&nbsp;$num&nbsp;%&nbsp;10;\n}&nbsp;\n$p1&nbsp;=&nbsp;substr($c1,&nbsp;3&nbsp;*&nbsp;$n,&nbsp;3);\n$p2&nbsp;=&nbsp;substr($c2,&nbsp;3&nbsp;*&nbsp;$i,&nbsp;3);\nif&nbsp;($n&nbsp;!=&nbsp;&#39;0&#39;&nbsp;||&nbsp;($n&nbsp;==&nbsp;&#39;0&#39;&nbsp;&amp;&amp;&nbsp;($p2&nbsp;==&nbsp;&#39;亿&#39;&nbsp;||&nbsp;$p2&nbsp;==&nbsp;&#39;万&#39;&nbsp;||&nbsp;$p2&nbsp;==&nbsp;&#39;元&#39;)))&nbsp;{\n$c&nbsp;=&nbsp;$p1&nbsp;.&nbsp;$p2&nbsp;.&nbsp;$c;\n}&nbsp;else&nbsp;{\n$c&nbsp;=&nbsp;$p1&nbsp;.&nbsp;$c;\n}&nbsp;\n$i&nbsp;=&nbsp;$i&nbsp;+&nbsp;1;\n$num&nbsp;=&nbsp;$num&nbsp;/&nbsp;10;\n$num&nbsp;=&nbsp;(int)$num;\nif&nbsp;($num&nbsp;==&nbsp;0)&nbsp;{\nbreak;\n}&nbsp;\n}\n$j&nbsp;=&nbsp;0;\n$slen&nbsp;=&nbsp;strlen($c);\nwhile&nbsp;($j&nbsp;&lt;&nbsp;$slen)&nbsp;{\n$m&nbsp;=&nbsp;substr($c,&nbsp;$j,&nbsp;6);\nif&nbsp;($m&nbsp;==&nbsp;&#39;零元&#39;&nbsp;||&nbsp;$m&nbsp;==&nbsp;&#39;零万&#39;&nbsp;||&nbsp;$m&nbsp;==&nbsp;&#39;零亿&#39;&nbsp;||&nbsp;$m&nbsp;==&nbsp;&#39;零零&#39;)&nbsp;{\n$left&nbsp;=&nbsp;substr($c,&nbsp;0,&nbsp;$j);\n$right&nbsp;=&nbsp;substr($c,&nbsp;$j&nbsp;+&nbsp;3);\n$c&nbsp;=&nbsp;$left&nbsp;.&nbsp;$right;\n$j&nbsp;=&nbsp;$j-3;\n$slen&nbsp;=&nbsp;$slen-3;\n}&nbsp;\n$j&nbsp;=&nbsp;$j&nbsp;+&nbsp;3;\n}&nbsp;\nif&nbsp;(substr($c,&nbsp;strlen($c)-3,&nbsp;3)&nbsp;==&nbsp;&#39;零&#39;)&nbsp;{\n$c&nbsp;=&nbsp;substr($c,&nbsp;0,&nbsp;strlen($c)-3);\n}\nif&nbsp;(empty($c))&nbsp;{\nreturn&nbsp;&quot;零元整&quot;;\n}else{\nreturn&nbsp;$c&nbsp;.&nbsp;&quot;整&quot;;\n}\n}</pre><p>最终实现效果：</p><p><img src=\"/Uploads/ueditor/2015-12-28/1451310141372440.png\" title=\"1451310141372440.png\" alt=\"1449026968974428.png\"/></p>', '1', '1', '1', '1', 'Win 8.1', '轮回', '124.152.7.106', '1449026848', '1492346057');
INSERT INTO `think_article` VALUES ('47', 'Windows下mysql忘记密码的解决方法', '1', '20170416\\f5f5aacefa23b9efb1c81895cb932572.jpg', 'Windows下mysql忘记密码的解决方法', 'mysql', '<p>方法一：</p><p>1、在DOS窗口下输入</p><pre>net&nbsp;stop&nbsp;mysql5</pre><p>&nbsp;</p><p>或</p><pre>net&nbsp;stop&nbsp;mysql</pre><p>&nbsp;</p><p>2、开一个DOS窗口，这个需要切换到mysql的bin目录。<br/>一般在bin目录里面创建一个批处理1.bat,内容是cmd.exe运行一下即可就切换到当前目录，然后输入</p><pre>mysqld-nt&nbsp;--skip-grant-tables;</pre><p>&nbsp;</p><p>3、再开一个DOS窗口</p><pre>mysql&nbsp;-u&nbsp;root</pre><p>&nbsp;</p><p>4、输入：</p><pre>use&nbsp;mysql&nbsp;\nupdate&nbsp;user&nbsp;set&nbsp;password=password(&quot;new_pass&quot;)&nbsp;where&nbsp;user=&quot;root&quot;;&nbsp;\nflush&nbsp;privileges;&nbsp;\nexit</pre><p>&nbsp;</p><p>5、使用任务管理器，找到mysqld-nt的进程，结束进程&nbsp;<br/>或下面的步骤<br/>1，停止MYSQL服务，CMD打开DOS窗口，输入 net stop mysql&nbsp;<br/>2，在CMD命令行窗口，进入MYSQL安装目录 比如E:Program FilesMySQLMySQL Server 5.0bin&nbsp;<br/>示范命令:&nbsp;<br/>输入 e:回车,&nbsp;<br/>输入cd &quot;E:Program FilesMySQLMySQL Server 5.0bin&quot;&nbsp;<br/>注意双引号也要输入,这样就可以进入Mysql安装目录了.&nbsp;<br/>3，进入mysql安全模式，即当mysql起来后，不用输入密码就能进入数据库。&nbsp;<br/>命令为：</p><pre>mysqld-nt&nbsp;--skip-grant-tables</pre><p>&nbsp;</p><p>4，重新打开一个CMD命令行窗口，输入</p><p>mysql -uroot -p，使用空密码的方式登录MySQL（不用输入密码，直接按回车）</p><p>5，输入以下命令开始修改root用户的密码（注意：命令中mysql.user中间有个“点”）</p><p>mysql.user：数据库名.表名<br/>mysql&gt; update mysql.user set password=PASSWORD(&#39;新密码&#39;) where User=&#39;root&#39;;&nbsp;<br/>6，刷新权限表&nbsp;<br/>mysql&gt; flush privileges;&nbsp;<br/>7，退出&nbsp;<br/>mysql&gt; quit</p><p><br/>这样MYSQL超级管理员账号 ROOT已经重新设置好了，接下来 在任务管理器里结束掉 mysql-nt.exe 这个进程，重新启动MYSQL即可！</p><p>（也可以直接重新启动服务器）&nbsp;<br/>MYSQL重新启动后，就可以用新设置的ROOT密码登陆MYSQL了！</p><p>方法二：</p><p>首先在 MySQL的安装目录下 新建一个pwdhf.txt, 输入文本：</p><pre>SET&nbsp;PASSWORD&nbsp;FOR&nbsp;&#39;root&#39;@&#39;localhost&#39;&nbsp;=&nbsp;PASSWORD(&#39;*****&#39;);</pre><p>&nbsp;</p><p>红色部份为 需要设置的新密码&nbsp;<br/>用windows服务管理工具或任务管理器来停止MySQL服务 (任务管理器K掉 mysqld-nt 进程)&nbsp;<br/>Dos命令提示符到 MySQL安装目录下的bin目录 如我的是</p><p>D:Program FilesMySQLMySQL Server 5.1bin&nbsp;<br/>然后运行：</p><pre>mysqld-nt&nbsp;--init-file=../pwdhf.txt</pre><p>&nbsp;</p><p>执行完毕， 停止MySQL数据库服务 (任务管理器K掉 mysqld-nt 进程)，然后再重新以正常模式启动MYSQL 即可</p><hr style=\"color: rgb(51, 51, 51); font-family: Arial; font-size: 14px; line-height: 26px; white-space: normal; background-color: rgb(255, 255, 255);\"/><p>mysql5.1或以上</p><p>1、 首先检查mysql服务是否启动，若已启动则先将其停止服务，可在开始菜单的运行，使用命令：</p><pre>net&nbsp;stop&nbsp;mysql</pre><p>&nbsp;</p><p>2、打开第一个cmd窗口，切换到mysql的bin目录，运行命令：</p><pre>mysqld&nbsp;--defaults-file=&quot;C:Program&nbsp;FilesMySQLMySQL&nbsp;Server&nbsp;5.1my.ini&quot;&nbsp;--console&nbsp;--skip-grant-tables</pre><p>&nbsp;</p><p>注释：</p><p>该命令通过跳过权限安全检查，开启mysql服务，这样连接mysql时，可以不用输入用户密码。&nbsp;<br/>&nbsp;</p><p>&nbsp;</p><p>3、打开第二个cmd窗口，连接mysql：</p><p>输入命令：</p><pre>mysql&nbsp;-uroot&nbsp;-p</pre><p>出现：</p><p>Enter password:</p><p>在这里直接回车，不用输入密码。</p><p>然后就就会出现登录成功的信息，</p><p>&nbsp;</p><p>&nbsp;</p><p>4、使用命令：</p><pre>show&nbsp;databases;</pre><p>&nbsp;</p><p>&nbsp;</p><p>5、使用命令切换到mysql数据库：</p><pre>use&nbsp;mysql;</pre><p>&nbsp;</p><p>6、使用命令更改root密码为123456：</p><pre>UPDATE&nbsp;user&nbsp;SET&nbsp;Password=PASSWORD(&#39;123456&#39;)&nbsp;where&nbsp;USER=&#39;root&#39;;</pre><p>&nbsp;</p><p>&nbsp;</p><p>7、刷新权限：</p><pre>FLUSH&nbsp;PRIVILEGES;</pre><p>&nbsp;</p><p>8、然后退出，重新登录：</p><p>quit</p><p>重新登录：</p><pre>mysql&nbsp;-uroot&nbsp;-p</pre><p>&nbsp;</p><p>9、出现输入密码提示，输入新的密码即可登录：</p><p>Enter password: ***********</p><p>显示登录信息： 成功&nbsp; 就一切ok了</p><p>&nbsp;</p><p>10、重新启动mysql服务</p><pre>net&nbsp;start&nbsp;mysql</pre><p><br/></p>', '1', '1', '0', '0', 'Win 8.1', '轮回', '0.0.0.0', '1450339377', '1492346047');
INSERT INTO `think_article` VALUES ('48', '禁止网页复制的代码', '1', '20170416\\c3646031ca540e4217d1228eefe99c4c.jpg', '禁止网页复制的代码', '网页复制', '<p>今天做一网站项目时，客户要求让用户不能复制网站内容，网上搜索了一下，总结成以下二几行代码。其实吧，要是懂的人，这些都是浮云来的，客户就是要让一般人不能复制他的内容资料。</p><pre class=\"brush:html;toolbar:false\" style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 10px; padding: 9.5px; list-style: none; border: 1px solid rgb(204, 204, 204); overflow: auto; font-family: Menlo, Monaco, Consolas, &#39;Courier New&#39;, monospace; font-size: 13px; line-height: 1.42857; color: rgb(51, 51, 51); word-break: break-all; word-wrap: break-word; border-radius: 4px; background-color: rgb(245, 245, 245);\">&quot;&nbsp;_ue_custom_node_=&quot;true&quot;&gt;&lt;\ntitle\n&gt;禁止网页复制的代码&nbsp;&nbsp;网页禁止右键、禁止查看源代码、禁止复制的代码，试试你的右键、ctrl+c和ctrl+c吧~\n&nbsp;&nbsp;\n&nbsp;&nbsp;&quot;&nbsp;_ue_custom_node_=&quot;true&quot;&gt;</pre><p><br/></p>', '1', '1', '1', '1', 'Win 8.1', '轮回', '0.0.0.0', '1450340150', '1492346038');

-- -----------------------------
-- Table structure for `think_article_cate`
-- -----------------------------
DROP TABLE IF EXISTS `think_article_cate`;
CREATE TABLE `think_article_cate` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) DEFAULT NULL COMMENT '分类名称',
  `orderby` varchar(10) DEFAULT '100' COMMENT '排序',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `update_time` int(11) DEFAULT NULL COMMENT '更新时间',
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_article_cate`
-- -----------------------------
INSERT INTO `think_article_cate` VALUES ('1', '大鼻孔', '1', '1477140627', '1502266891', '1');
INSERT INTO `think_article_cate` VALUES ('2', '生活随笔', '2', '1477140627', '1477140627', '0');
INSERT INTO `think_article_cate` VALUES ('3', '热点分享', '3', '1477140604', '1477140627', '0');
INSERT INTO `think_article_cate` VALUES ('4', '.NET', '4', '1477140627', '1477140627', '1');
INSERT INTO `think_article_cate` VALUES ('5', 'PHP', '5', '1477140627', '1477140627', '0');
INSERT INTO `think_article_cate` VALUES ('6', 'Java', '6', '1477140627', '1477140627', '0');

-- -----------------------------
-- Table structure for `think_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `think_auth_group`;
CREATE TABLE `think_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `rules` text NOT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_auth_group`
-- -----------------------------
INSERT INTO `think_auth_group` VALUES ('1', '超级管理员', '1', '', '1446535750', '1446535750');
INSERT INTO `think_auth_group` VALUES ('4', '系统测试员', '1', '1,2,9,3,30,4,39,61,62,5,6,7,27,29,13,14,22,24,25,40,41,43,26,44,45,47,48,49,50,51,52,53,54,55,56,57,58,70,71,72,73,80,75,76,77,79', '1446535750', '1501581108');
INSERT INTO `think_auth_group` VALUES ('10', '审核', '1', '', '1562827175', '1562827175');

-- -----------------------------
-- Table structure for `think_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `think_auth_group_access`;
CREATE TABLE `think_auth_group_access` (
  `uid` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_auth_group_access`
-- -----------------------------
INSERT INTO `think_auth_group_access` VALUES ('1', '1');
INSERT INTO `think_auth_group_access` VALUES ('21', '4');

-- -----------------------------
-- Table structure for `think_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `think_auth_rule`;
CREATE TABLE `think_auth_rule` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(80) NOT NULL DEFAULT '',
  `title` char(20) NOT NULL DEFAULT '',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `css` varchar(20) NOT NULL COMMENT '样式',
  `condition` char(100) NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '父栏目ID',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=116 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_auth_rule`
-- -----------------------------
INSERT INTO `think_auth_rule` VALUES ('1', '#', '系统管理', '1', '1', 'fa fa-gear', '', '0', '13', '1446535750', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('2', 'admin/user/index', '用户管理', '1', '1', '', '', '1', '10', '1446535750', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('3', 'admin/role/index', '角色管理', '1', '0', '', '', '1', '20', '1446535750', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('4', 'admin/menu/index', '菜单管理', '1', '1', '', '', '1', '30', '1446535750', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('5', '#', '数据库管理', '1', '1', 'fa fa-database', '', '0', '13', '1446535750', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('6', 'admin/data/index', '数据库备份', '1', '1', '', '', '5', '50', '1446535750', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('7', 'admin/data/optimize', '优化表', '1', '1', '', '', '6', '50', '1477312169', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('8', 'admin/data/repair', '修复表', '1', '1', '', '', '6', '50', '1477312169', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('9', 'admin/user/useradd', '添加用户', '1', '1', '', '', '2', '50', '1477312169', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('10', 'admin/user/useredit', '编辑用户', '1', '1', '', '', '2', '50', '1477312169', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('11', 'admin/user/userdel', '删除用户', '1', '1', '', '', '2', '50', '1477312169', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('12', 'admin/user/user_state', '用户状态', '1', '1', '', '', '2', '50', '1477312169', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('13', '#', '日志管理', '1', '0', 'fa fa-tasks', '', '0', '50', '1477312169', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('14', 'admin/log/operate_log', '行为日志', '1', '0', '', '', '13', '50', '1477312169', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('22', 'admin/log/del_log', '删除日志', '1', '0', '', '', '14', '50', '1477312169', '1477316778');
INSERT INTO `think_auth_rule` VALUES ('24', '#', '文章管理', '1', '0', 'fa fa-paste', '', '0', '20', '1477312169', '1563721739');
INSERT INTO `think_auth_rule` VALUES ('25', 'admin/article/index_cate', '文章分类', '1', '0', '', '', '24', '10', '1477312260', '1477312260');
INSERT INTO `think_auth_rule` VALUES ('26', 'admin/article/index', '文章列表', '1', '0', '', '', '24', '20', '1477312333', '1477312333');
INSERT INTO `think_auth_rule` VALUES ('27', 'admin/data/import', '数据库还原', '1', '1', '', '', '5', '50', '1477639870', '1477639870');
INSERT INTO `think_auth_rule` VALUES ('28', 'admin/data/revert', '还原', '1', '1', '', '', '27', '50', '1477639972', '1477639972');
INSERT INTO `think_auth_rule` VALUES ('29', 'admin/data/del', '删除', '1', '1', '', '', '27', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('30', 'admin/role/roleAdd', '添加角色', '1', '0', '', '', '3', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('31', 'admin/role/roleEdit', '编辑角色', '1', '0', '', '', '3', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('32', 'admin/role/roleDel', '删除角色', '1', '0', '', '', '3', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('33', 'admin/role/role_state', '角色状态', '1', '0', '', '', '3', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('34', 'admin/role/giveAccess', '权限分配', '1', '0', '', '', '3', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('35', 'admin/menu/add_rule', '添加菜单', '1', '1', '', '', '4', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('36', 'admin/menu/edit_rule', '编辑菜单', '1', '1', '', '', '4', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('37', 'admin/menu/del_rule', '删除菜单', '1', '1', '', '', '4', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('38', 'admin/menu/rule_state', '菜单状态', '1', '1', '', '', '4', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('39', 'admin/menu/ruleorder', '菜单排序', '1', '1', '', '', '4', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('40', 'admin/article/add_cate', '添加分类', '1', '0', '', '', '25', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('41', 'admin/article/edit_cate', '编辑分类', '1', '0', '', '', '25', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('42', 'admin/article/del_cate', '删除分类', '1', '0', '', '', '25', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('43', 'admin/article/cate_state', '分类状态', '1', '0', '', '', '25', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('44', 'admin/article/add_article', '添加文章', '1', '0', '', '', '26', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('45', 'admin/article/edit_article', '编辑文章', '1', '0', '', '', '26', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('46', 'admin/article/del_article', '删除文章', '1', '0', '', '', '26', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('47', 'admin/article/article_state', '文章状态', '1', '0', '', '', '26', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('48', '#', '广告管理', '1', '0', 'fa fa-image', '', '0', '11', '1477640011', '1563721754');
INSERT INTO `think_auth_rule` VALUES ('49', 'admin/ad/index_position', '广告位', '1', '0', '', '', '48', '10', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('50', 'admin/ad/add_position', '添加广告位', '1', '0', '', '', '49', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('51', 'admin/ad/edit_position', '编辑广告位', '1', '0', '', '', '49', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('52', 'admin/ad/del_position', '删除广告位', '1', '0', '', '', '49', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('53', 'admin/ad/position_state', '广告位状态', '1', '0', '', '', '49', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('54', 'admin/ad/index', '广告列表', '1', '0', '', '', '48', '20', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('55', 'admin/ad/add_ad', '添加广告', '1', '0', '', '', '54', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('56', 'admin/ad/edit_ad', '编辑广告', '1', '0', '', '', '54', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('57', 'admin/ad/del_ad', '删除广告', '1', '0', '', '', '54', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('58', 'admin/ad/ad_state', '广告状态', '1', '0', '', '', '54', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('83', '#', '示例', '1', '0', 'fa fa-paper-plane', '', '0', '50', '1505281878', '1505281878');
INSERT INTO `think_auth_rule` VALUES ('84', 'admin/demo/sms', '发送短信', '1', '0', '', '', '83', '50', '1505281944', '1505281944');
INSERT INTO `think_auth_rule` VALUES ('61', 'admin/config/index', '配置管理', '1', '0', '', '', '1', '50', '1479908607', '1479908607');
INSERT INTO `think_auth_rule` VALUES ('62', 'admin/config/index', '配置列表', '1', '0', '', '', '61', '50', '1479908607', '1487943813');
INSERT INTO `think_auth_rule` VALUES ('63', 'admin/config/save', '保存配置', '1', '0', '', '', '61', '50', '1479908607', '1487943831');
INSERT INTO `think_auth_rule` VALUES ('70', '#', '会员管理', '1', '0', 'fa fa-users', '', '0', '10', '1484103066', '1484103066');
INSERT INTO `think_auth_rule` VALUES ('72', 'admin/member/add_group', '添加会员组', '1', '0', '', '', '71', '50', '1484103304', '1484103304');
INSERT INTO `think_auth_rule` VALUES ('71', 'admin/member/group', '会员组', '1', '0', '', '', '70', '10', '1484103304', '1484103304');
INSERT INTO `think_auth_rule` VALUES ('73', 'admin/member/edit_group', '编辑会员组', '1', '0', '', '', '71', '50', '1484103304', '1484103304');
INSERT INTO `think_auth_rule` VALUES ('74', 'admin/member/del_group', '删除会员组', '1', '0', '', '', '71', '50', '1484103304', '1484103304');
INSERT INTO `think_auth_rule` VALUES ('75', 'admin/member/index', '会员列表', '1', '0', '', '', '70', '20', '1484103304', '1484103304');
INSERT INTO `think_auth_rule` VALUES ('76', 'admin/member/add_member', '添加会员', '1', '0', '', '', '75', '50', '1484103304', '1484103304');
INSERT INTO `think_auth_rule` VALUES ('77', 'admin/member/edit_member', '编辑会员', '1', '0', '', '', '75', '50', '1484103304', '1484103304');
INSERT INTO `think_auth_rule` VALUES ('78', 'admin/member/del_member', '删除会员', '1', '0', '', '', '75', '50', '1484103304', '1484103304');
INSERT INTO `think_auth_rule` VALUES ('79', 'admin/member/member_status', '会员状态', '1', '0', '', '', '75', '50', '1484103304', '1487937671');
INSERT INTO `think_auth_rule` VALUES ('80', 'admin/member/group_status', '会员组状态', '1', '0', '', '', '71', '50', '1484103304', '1484103304');
INSERT INTO `think_auth_rule` VALUES ('89', '#', '分类管理', '1', '1', 'fa fa-th-large', '', '0', '1', '1563721684', '1563721774');
INSERT INTO `think_auth_rule` VALUES ('90', 'admin/region/index', '区域管理', '1', '1', 'fa fa-map-marker', '', '89', '10', '1563721939', '1563759367');
INSERT INTO `think_auth_rule` VALUES ('87', 'admin/renting/index', '房屋出租', '1', '1', 'col-xs-11', '', '85', '20', '1562833352', '1562841015');
INSERT INTO `think_auth_rule` VALUES ('88', 'admin/job/index', '招聘求职', '1', '1', 'col-xs-11', '', '85', '30', '1562833468', '1562833468');
INSERT INTO `think_auth_rule` VALUES ('91', 'admin/topic/index', '话题管理', '1', '1', 'fa fa-commenting-o', '', '89', '20', '1563722067', '1563759385');
INSERT INTO `think_auth_rule` VALUES ('92', 'admin/profession/index', '行业管理', '1', '1', 'fa fa-briefcase', '', '89', '30', '1563722169', '1563759439');
INSERT INTO `think_auth_rule` VALUES ('93', '#', '发现', '1', '1', 'fa fa-eye', '', '0', '7', '1563722441', '1564225886');
INSERT INTO `think_auth_rule` VALUES ('94', 'admin/coupon/index', '优惠卷管理', '1', '1', 'fa fa-money', '', '93', '10', '1563722672', '1563759458');
INSERT INTO `think_auth_rule` VALUES ('95', '#', '其他', '1', '1', 'fa fa-th', '', '0', '50', '1563723508', '1563723508');
INSERT INTO `think_auth_rule` VALUES ('96', 'admin/marquee/index', '系统通知', '1', '1', 'fa fa-warning', '', '95', '10', '1563723655', '1564204331');
INSERT INTO `think_auth_rule` VALUES ('97', '#', '社区管理', '1', '1', 'fa fa-thumbs-o-up', '', '0', '3', '1563723756', '1564225747');
INSERT INTO `think_auth_rule` VALUES ('98', 'admin/community/index', '社区动态列表', '1', '1', '', '', '97', '10', '1563724173', '1564225760');
INSERT INTO `think_auth_rule` VALUES ('99', 'admin/turns/index', '轮播图管理', '1', '1', 'fa fa-university', '', '0', '2', '1563714309', '1564225678');
INSERT INTO `think_auth_rule` VALUES ('100', 'admin/turns/add_turns', '添加轮播图', '1', '1', 'envelope-open', '', '99', '10', '1563759229', '1564225701');
INSERT INTO `think_auth_rule` VALUES ('101', 'admin/turns/index', '查看轮播图列表', '1', '1', ' Example of bandcamp', '', '99', '20', '1563759334', '1564225717');
INSERT INTO `think_auth_rule` VALUES ('102', 'admin/taxi/index', '叫车管理', '1', '1', 'fa fa-clipboard', '', '0', '4', '1563760144', '1564225782');
INSERT INTO `think_auth_rule` VALUES ('103', 'admin/taxi/index', '叫车管理列表', '1', '1', 'fa fa-clipboard', '', '102', '10', '1564018003', '1564225800');
INSERT INTO `think_auth_rule` VALUES ('104', 'admin/hotel/index', '酒店旅馆管理', '1', '1', 'fa fa-clipboard', '', '0', '5', '1564018364', '1564225819');
INSERT INTO `think_auth_rule` VALUES ('105', 'admin/hotel/index', '酒店管理列表', '1', '1', '', '', '104', '10', '1564018421', '1564225834');
INSERT INTO `think_auth_rule` VALUES ('106', 'admin/dining/index', '美食管理', '1', '1', 'fa fa-clipboard', '', '0', '6', '1564106195', '1564225848');
INSERT INTO `think_auth_rule` VALUES ('107', 'admin/dining/index', '美食管理列表', '1', '1', '', '', '106', '10', '1564106228', '1564225859');
INSERT INTO `think_auth_rule` VALUES ('108', 'admin/customer_service/index', '客服管理', '1', '1', '', '', '95', '50', '1564213698', '1564213698');
INSERT INTO `think_auth_rule` VALUES ('109', 'admin/sticky/index', '积分管理', '1', '1', 'fa fa-money', '', '0', '8', '1564213762', '1564226081');
INSERT INTO `think_auth_rule` VALUES ('110', 'admin/sticky/index', '置顶积分列表', '1', '1', '', '', '109', '10', '1564213793', '1564225930');
INSERT INTO `think_auth_rule` VALUES ('111', '#', '订单管理', '1', '1', 'fa fa-file-text-o', '', '0', '9', '1564213828', '1564225943');
INSERT INTO `think_auth_rule` VALUES ('112', 'admin/good_order/index', '订单列表', '1', '1', '', '', '111', '10', '1564213845', '1564225956');
INSERT INTO `think_auth_rule` VALUES ('114', 'admin/integral/index', '积分充值列表', '1', '1', '', '', '109', '50', '1564566288', '1564566288');
INSERT INTO `think_auth_rule` VALUES ('115', 'admin/idea/index', '意见反馈', '1', '1', '', '', '95', '50', '1564570388', '1564570388');

-- -----------------------------
-- Table structure for `think_comment_list`
-- -----------------------------
DROP TABLE IF EXISTS `think_comment_list`;
CREATE TABLE `think_comment_list` (
  `comment_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '租房评论表',
  `renting_id` int(11) DEFAULT NULL COMMENT '房屋ID',
  `user_id` int(11) DEFAULT NULL COMMENT '用户ID',
  `comment_content` text COMMENT '评论详情',
  `comment_time` varchar(255) DEFAULT NULL COMMENT '评论时间',
  PRIMARY KEY (`comment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_comment_list`
-- -----------------------------
INSERT INTO `think_comment_list` VALUES ('1', '1', '1', '', '');

-- -----------------------------
-- Table structure for `think_community`
-- -----------------------------
DROP TABLE IF EXISTS `think_community`;
CREATE TABLE `think_community` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `topic_id` int(10) unsigned NOT NULL COMMENT '话题id',
  `body` text NOT NULL COMMENT '话题内容',
  `sticky_create_time` int(11) unsigned DEFAULT NULL COMMENT '置顶开始时间',
  `sticky_end_time` int(11) unsigned DEFAULT NULL COMMENT '置顶结束时间',
  `sticky_status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '置顶状态(0:置顶1:不置顶)',
  `essence` tinyint(11) unsigned NOT NULL DEFAULT '1' COMMENT '精华(0:是 1:不是)',
  `praise` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '点赞数量',
  `browse` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览量',
  `review` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '评论数量',
  `collect` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '收藏数量',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '发布状态(0:以审核,1:未审核2:审核未通过)',
  `recommend_status` tinyint(1) unsigned DEFAULT '1' COMMENT '首页推荐状态（0：显示 1：不显示）',
  `create_time` int(11) unsigned NOT NULL COMMENT '创建日期',
  `update_time` int(11) unsigned NOT NULL COMMENT '修改日期',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COMMENT='社区动态';

-- -----------------------------
-- Records of `think_community`
-- -----------------------------
INSERT INTO `think_community` VALUES ('1', '13', '1', '社区动态测试', '0', '0', '1', '0', '1', '4', '5', '0', '0', '0', '1563616474', '1564036539');
INSERT INTO `think_community` VALUES ('2', '13', '1', '社区动态测试', '0', '0', '1', '0', '0', '4', '3', '2', '0', '0', '1563616482', '1564192224');
INSERT INTO `think_community` VALUES ('3', '13', '1', '社区动态测试', '0', '0', '1', '0', '0', '8', '3', '1', '0', '0', '1563616483', '1564192243');
INSERT INTO `think_community` VALUES ('4', '13', '2', '社区动态测试', '0', '0', '1', '1', '0', '0', '3', '0', '0', '1', '1563616487', '1563616487');
INSERT INTO `think_community` VALUES ('5', '13', '2', '社区动态测试', '0', '0', '1', '1', '0', '0', '3', '0', '0', '1', '1563616488', '1563616488');
INSERT INTO `think_community` VALUES ('6', '13', '2', '社区动态测试', '0', '0', '1', '1', '1', '2', '3', '1', '0', '1', '1563616489', '1564204169');
INSERT INTO `think_community` VALUES ('7', '13', '1', '社区动态测试1', '0', '0', '1', '1', '0', '1', '0', '0', '0', '1', '1563616805', '1563618652');
INSERT INTO `think_community` VALUES ('8', '13', '1', '11111', '0', '0', '1', '1', '0', '0', '0', '0', '0', '1', '1563623873', '1563623873');
INSERT INTO `think_community` VALUES ('9', '13', '1', '社区动态测试1', '0', '0', '1', '0', '1', '1', '0', '1', '0', '1', '1563627472', '1563774587');
INSERT INTO `think_community` VALUES ('10', '13', '1', '社区动态测试1', '0', '0', '1', '1', '1', '9', '1', '1', '0', '1', '1563627521', '1563758263');
INSERT INTO `think_community` VALUES ('11', '13', '1', '社区动态测试1', '0', '0', '1', '0', '1', '6', '0', '1', '0', '1', '1563639085', '1563774579');
INSERT INTO `think_community` VALUES ('12', '13', '1', '社区动态测试1', '0', '0', '1', '1', '0', '5', '1', '0', '0', '1', '1563677527', '1563758275');
INSERT INTO `think_community` VALUES ('13', '13', '1', '1111111', '0', '0', '1', '1', '1', '1', '0', '1', '0', '1', '1564045371', '1564204166');
INSERT INTO `think_community` VALUES ('14', '13', '1', '关键是咯路', '0', '0', '1', '1', '0', '0', '0', '0', '0', '1', '1564206748', '1564206748');
INSERT INTO `think_community` VALUES ('15', '212082', '1', '社区动态测试', '0', '0', '1', '0', '0', '7', '0', '0', '0', '0', '1564206852', '1564970804');
INSERT INTO `think_community` VALUES ('16', '13', '1', '1111？', '0', '0', '1', '1', '0', '0', '0', '0', '0', '1', '1564207762', '1564207762');
INSERT INTO `think_community` VALUES ('17', '212082', '2', '社区动态测试', '0', '0', '1', '1', '0', '0', '0', '0', '0', '1', '1564399942', '1564399942');
INSERT INTO `think_community` VALUES ('18', '13', '1', '111231231', '1564449669', '1564708869', '1', '1', '1', '4', '0', '0', '0', '1', '1564449669', '1564721629');
INSERT INTO `think_community` VALUES ('19', '212082', '1', '西华大学邢娟娟下决心', '0', '0', '1', '1', '0', '0', '0', '0', '0', '1', '1564449914', '1564449914');
INSERT INTO `think_community` VALUES ('20', '13', '1', '个家海上世界', '0', '0', '1', '1', '0', '0', '0', '0', '0', '1', '1564484958', '1564484958');
INSERT INTO `think_community` VALUES ('21', '212082', '1', '<script>alert(1)<script>', '0', '0', '1', '1', '0', '1', '0', '0', '0', '1', '1564675104', '1564675114');

-- -----------------------------
-- Table structure for `think_community_comment`
-- -----------------------------
DROP TABLE IF EXISTS `think_community_comment`;
CREATE TABLE `think_community_comment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `community_id` int(11) unsigned NOT NULL COMMENT '社区ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '用户ID',
  `body` text NOT NULL COMMENT '评论内容',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '审核状态(0:以审核 1:未审核 2:审核未通过)',
  `create_time` int(11) unsigned NOT NULL,
  `update_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COMMENT='社区评论';

-- -----------------------------
-- Records of `think_community_comment`
-- -----------------------------
INSERT INTO `think_community_comment` VALUES ('1', '1', '13', '社区动态评论测试', '1', '1563616528', '1563616528');
INSERT INTO `think_community_comment` VALUES ('2', '1', '13', '社区动态评论测试', '1', '1563616529', '1563616529');
INSERT INTO `think_community_comment` VALUES ('3', '1', '13', '社区动态评论测试', '1', '1563616530', '1563616530');
INSERT INTO `think_community_comment` VALUES ('4', '2', '13', '社区动态评论测试', '1', '1563616534', '1563616534');
INSERT INTO `think_community_comment` VALUES ('5', '2', '13', '社区动态评论测试', '1', '1563616535', '1563616535');
INSERT INTO `think_community_comment` VALUES ('6', '2', '13', '社区动态评论测试', '1', '1563616536', '1563616536');
INSERT INTO `think_community_comment` VALUES ('7', '3', '13', '社区动态评论测试', '1', '1563616539', '1563616539');
INSERT INTO `think_community_comment` VALUES ('8', '3', '13', '社区动态评论测试', '1', '1563616540', '1563616540');
INSERT INTO `think_community_comment` VALUES ('9', '3', '13', '社区动态评论测试', '1', '1563616541', '1563616541');
INSERT INTO `think_community_comment` VALUES ('10', '4', '13', '社区动态评论测试', '1', '1563616544', '1563616544');
INSERT INTO `think_community_comment` VALUES ('11', '4', '13', '社区动态评论测试', '1', '1563616545', '1563616545');
INSERT INTO `think_community_comment` VALUES ('12', '4', '13', '社区动态评论测试', '1', '1563616546', '1563616546');
INSERT INTO `think_community_comment` VALUES ('13', '5', '13', '社区动态评论测试', '1', '1563616549', '1563616549');
INSERT INTO `think_community_comment` VALUES ('14', '5', '13', '社区动态评论测试', '1', '1563616551', '1563616551');
INSERT INTO `think_community_comment` VALUES ('15', '5', '13', '社区动态评论测试', '1', '1563616552', '1563616552');
INSERT INTO `think_community_comment` VALUES ('16', '6', '13', '社区动态评论测试', '1', '1563616554', '1563616554');
INSERT INTO `think_community_comment` VALUES ('17', '6', '13', '社区动态评论测试', '1', '1563616555', '1563616555');
INSERT INTO `think_community_comment` VALUES ('18', '6', '13', '社区动态评论测试', '1', '1563616556', '1563616556');
INSERT INTO `think_community_comment` VALUES ('19', '1', '13', '社区动态评论测试', '1', '1563627762', '1563627762');
INSERT INTO `think_community_comment` VALUES ('20', '10', '13', '............0000', '1', '1563638018', '1563638018');
INSERT INTO `think_community_comment` VALUES ('21', '1', '13', '社区动态评论测试', '1', '1563639144', '1563639144');
INSERT INTO `think_community_comment` VALUES ('22', '12', '13', '11111', '1', '1563688376', '1563688376');

-- -----------------------------
-- Table structure for `think_community_comment_image`
-- -----------------------------
DROP TABLE IF EXISTS `think_community_comment_image`;
CREATE TABLE `think_community_comment_image` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` int(11) unsigned NOT NULL COMMENT '评论ID',
  `path` varchar(255) DEFAULT NULL COMMENT '评论图片路径',
  `create_time` int(10) unsigned NOT NULL,
  `update_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 COMMENT='社区评论图片';

-- -----------------------------
-- Records of `think_community_comment_image`
-- -----------------------------
INSERT INTO `think_community_comment_image` VALUES ('1', '1', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616528', '1563616528');
INSERT INTO `think_community_comment_image` VALUES ('2', '1', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616528', '1563616528');
INSERT INTO `think_community_comment_image` VALUES ('3', '2', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616529', '1563616529');
INSERT INTO `think_community_comment_image` VALUES ('4', '2', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616529', '1563616529');
INSERT INTO `think_community_comment_image` VALUES ('5', '3', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616530', '1563616530');
INSERT INTO `think_community_comment_image` VALUES ('6', '3', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616530', '1563616530');
INSERT INTO `think_community_comment_image` VALUES ('7', '4', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616534', '1563616534');
INSERT INTO `think_community_comment_image` VALUES ('8', '4', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616534', '1563616534');
INSERT INTO `think_community_comment_image` VALUES ('9', '5', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616535', '1563616535');
INSERT INTO `think_community_comment_image` VALUES ('10', '5', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616535', '1563616535');
INSERT INTO `think_community_comment_image` VALUES ('11', '6', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616536', '1563616536');
INSERT INTO `think_community_comment_image` VALUES ('12', '6', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616536', '1563616536');
INSERT INTO `think_community_comment_image` VALUES ('13', '7', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616539', '1563616539');
INSERT INTO `think_community_comment_image` VALUES ('14', '7', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616539', '1563616539');
INSERT INTO `think_community_comment_image` VALUES ('15', '8', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616540', '1563616540');
INSERT INTO `think_community_comment_image` VALUES ('16', '8', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616540', '1563616540');
INSERT INTO `think_community_comment_image` VALUES ('17', '9', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616541', '1563616541');
INSERT INTO `think_community_comment_image` VALUES ('18', '9', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616541', '1563616541');
INSERT INTO `think_community_comment_image` VALUES ('19', '10', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616544', '1563616544');
INSERT INTO `think_community_comment_image` VALUES ('20', '10', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616544', '1563616544');
INSERT INTO `think_community_comment_image` VALUES ('21', '11', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616545', '1563616545');
INSERT INTO `think_community_comment_image` VALUES ('22', '11', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616545', '1563616545');
INSERT INTO `think_community_comment_image` VALUES ('23', '12', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616546', '1563616546');
INSERT INTO `think_community_comment_image` VALUES ('24', '12', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616546', '1563616546');
INSERT INTO `think_community_comment_image` VALUES ('25', '13', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616549', '1563616549');
INSERT INTO `think_community_comment_image` VALUES ('26', '13', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616549', '1563616549');
INSERT INTO `think_community_comment_image` VALUES ('27', '14', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616551', '1563616551');
INSERT INTO `think_community_comment_image` VALUES ('28', '14', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616551', '1563616551');
INSERT INTO `think_community_comment_image` VALUES ('29', '15', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616552', '1563616552');
INSERT INTO `think_community_comment_image` VALUES ('30', '15', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616552', '1563616552');
INSERT INTO `think_community_comment_image` VALUES ('31', '16', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616554', '1563616554');
INSERT INTO `think_community_comment_image` VALUES ('32', '16', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616554', '1563616554');
INSERT INTO `think_community_comment_image` VALUES ('33', '17', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616555', '1563616555');
INSERT INTO `think_community_comment_image` VALUES ('34', '17', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616555', '1563616555');
INSERT INTO `think_community_comment_image` VALUES ('35', '18', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616556', '1563616556');
INSERT INTO `think_community_comment_image` VALUES ('36', '18', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616556', '1563616556');
INSERT INTO `think_community_comment_image` VALUES ('37', '19', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563627762', '1563627762');
INSERT INTO `think_community_comment_image` VALUES ('38', '19', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563627762', '1563627762');
INSERT INTO `think_community_comment_image` VALUES ('39', '20', '', '1563638018', '1563638018');
INSERT INTO `think_community_comment_image` VALUES ('40', '21', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563639144', '1563639144');
INSERT INTO `think_community_comment_image` VALUES ('41', '21', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563639144', '1563639144');
INSERT INTO `think_community_comment_image` VALUES ('42', '22', '', '1563688376', '1563688376');

-- -----------------------------
-- Table structure for `think_community_file`
-- -----------------------------
DROP TABLE IF EXISTS `think_community_file`;
CREATE TABLE `think_community_file` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `community_id` int(11) NOT NULL COMMENT '社区ID',
  `path` varchar(255) DEFAULT NULL COMMENT '社区图片路径',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8 COMMENT='社区图片/视频';

-- -----------------------------
-- Records of `think_community_file`
-- -----------------------------
INSERT INTO `think_community_file` VALUES ('1', '1', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616474', '1563616474');
INSERT INTO `think_community_file` VALUES ('2', '1', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616474', '1563616474');
INSERT INTO `think_community_file` VALUES ('3', '1', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616474', '1563616474');
INSERT INTO `think_community_file` VALUES ('4', '2', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616482', '1563616482');
INSERT INTO `think_community_file` VALUES ('5', '2', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616482', '1563616482');
INSERT INTO `think_community_file` VALUES ('6', '2', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616482', '1563616482');
INSERT INTO `think_community_file` VALUES ('7', '3', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616483', '1563616483');
INSERT INTO `think_community_file` VALUES ('8', '3', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616483', '1563616483');
INSERT INTO `think_community_file` VALUES ('9', '3', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616483', '1563616483');
INSERT INTO `think_community_file` VALUES ('10', '4', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616487', '1563616487');
INSERT INTO `think_community_file` VALUES ('11', '4', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616487', '1563616487');
INSERT INTO `think_community_file` VALUES ('12', '4', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616487', '1563616487');
INSERT INTO `think_community_file` VALUES ('13', '5', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616488', '1563616488');
INSERT INTO `think_community_file` VALUES ('14', '5', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616488', '1563616488');
INSERT INTO `think_community_file` VALUES ('15', '5', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616488', '1563616488');
INSERT INTO `think_community_file` VALUES ('16', '6', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616489', '1563616489');
INSERT INTO `think_community_file` VALUES ('17', '6', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616489', '1563616489');
INSERT INTO `think_community_file` VALUES ('18', '6', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616489', '1563616489');
INSERT INTO `think_community_file` VALUES ('19', '7', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616805', '1563616805');
INSERT INTO `think_community_file` VALUES ('20', '7', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616805', '1563616805');
INSERT INTO `think_community_file` VALUES ('21', '7', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563616805', '1563616805');
INSERT INTO `think_community_file` VALUES ('22', '8', '', '1563623873', '1563623873');
INSERT INTO `think_community_file` VALUES ('23', '9', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563627472', '1563627472');
INSERT INTO `think_community_file` VALUES ('24', '9', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563627472', '1563627472');
INSERT INTO `think_community_file` VALUES ('25', '9', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563627472', '1563627472');
INSERT INTO `think_community_file` VALUES ('26', '10', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563627521', '1563627521');
INSERT INTO `think_community_file` VALUES ('27', '10', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563627521', '1563627521');
INSERT INTO `think_community_file` VALUES ('28', '10', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563627521', '1563627521');
INSERT INTO `think_community_file` VALUES ('29', '11', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563639085', '1563639085');
INSERT INTO `think_community_file` VALUES ('30', '11', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563639085', '1563639085');
INSERT INTO `think_community_file` VALUES ('31', '11', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563639085', '1563639085');
INSERT INTO `think_community_file` VALUES ('32', '12', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563677527', '1563677527');
INSERT INTO `think_community_file` VALUES ('33', '12', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563677527', '1563677527');
INSERT INTO `think_community_file` VALUES ('34', '12', '\\/public\\/uploads\\/issue\\/20190720\\/9b3087629b86c3a4e241e56c204629bf.jpg', '1563677527', '1563677527');
INSERT INTO `think_community_file` VALUES ('35', '13', '/public/uploads/issue/20190725/413b9ab93d81328302723a9f0a5b8e24.png', '1564045371', '1564045371');
INSERT INTO `think_community_file` VALUES ('36', '13', '/public/uploads/issue/20190725/34031efedd8f01dfd02667f0b10ba708.png', '1564045371', '1564045371');
INSERT INTO `think_community_file` VALUES ('37', '13', '/public/uploads/issue/20190725/68fd60920de4c8865c62e2ff8a52476f.png', '1564045371', '1564045371');
INSERT INTO `think_community_file` VALUES ('38', '13', '/public/uploads/issue/20190725/00176ab41aa5bba66d865140da86d527.png', '1564045371', '1564045371');
INSERT INTO `think_community_file` VALUES ('39', '13', '/public/uploads/issue/20190725/1863720e005172f7b239c02472ec4edc.png', '1564045371', '1564045371');
INSERT INTO `think_community_file` VALUES ('40', '13', '/public/uploads/issue/20190725/5d77cc66e76c38ce5efc0637228c3670.png', '1564045371', '1564045371');
INSERT INTO `think_community_file` VALUES ('41', '13', '/public/uploads/issue/20190725/85362d7636c17a649081443133be5516.png', '1564045371', '1564045371');
INSERT INTO `think_community_file` VALUES ('42', '13', '/public/uploads/issue/20190725/7d0c1e7904d3eac3020f78b6fb889169.png', '1564045371', '1564045371');
INSERT INTO `think_community_file` VALUES ('43', '13', '/public/uploads/issue/20190725/e2dbad0901aed95109f16960c4386736.png', '1564045371', '1564045371');
INSERT INTO `think_community_file` VALUES ('44', '14', '', '1564206748', '1564206748');
INSERT INTO `think_community_file` VALUES ('45', '15', '/public/uploads/issue/20190727/1ffced163de234b9befd7163ec346143.jpg', '1564206852', '1564206852');
INSERT INTO `think_community_file` VALUES ('46', '15', '/public/uploads/issue/20190727/bcb9ee836cfae33c09060b3f45b3fa49.jpg', '1564206852', '1564206852');
INSERT INTO `think_community_file` VALUES ('47', '15', '/public/uploads/issue/20190727/c68ecb531b4131a7d21754d2ee038866.jpg', '1564206852', '1564206852');
INSERT INTO `think_community_file` VALUES ('48', '15', '/public/uploads/issue/20190727/8edc49673a98491ad853272c7928ad3c.jpg', '1564206852', '1564206852');
INSERT INTO `think_community_file` VALUES ('49', '15', '/public/uploads/issue/20190727/74f14e61650e10a739b75ff39ae34e1f.jpg', '1564206852', '1564206852');
INSERT INTO `think_community_file` VALUES ('50', '15', '/public/uploads/issue/20190727/3e057e81ffe0309d12cbdb7523cb6875.jpg', '1564206852', '1564206852');
INSERT INTO `think_community_file` VALUES ('51', '15', '/public/uploads/issue/20190727/236af87e8de6441b28f2a2c3b5bdd546.jpg', '1564206852', '1564206852');
INSERT INTO `think_community_file` VALUES ('52', '15', '/public/uploads/issue/20190727/501ac335b5e50dfd943bec947a86a1a0.jpg', '1564206852', '1564206852');
INSERT INTO `think_community_file` VALUES ('53', '15', '/public/uploads/issue/20190727/33b8dcd8fc995eefaac67f8058d25bb2.jpg', '1564206852', '1564206852');
INSERT INTO `think_community_file` VALUES ('54', '16', '', '1564207762', '1564207762');
INSERT INTO `think_community_file` VALUES ('55', '17', '/public/uploads/issue/20190729/fe082d76b3e95df2cb278138bb089c44.jpg', '1564399942', '1564399942');
INSERT INTO `think_community_file` VALUES ('56', '17', '/public/uploads/issue/20190729/5b1bffa6b3aab712244f604f78071344.jpg', '1564399942', '1564399942');
INSERT INTO `think_community_file` VALUES ('57', '17', '/public/uploads/issue/20190729/cc6a14dd7efe7484de0884943692d942.jpg', '1564399942', '1564399942');
INSERT INTO `think_community_file` VALUES ('58', '17', '/public/uploads/issue/20190729/203303c9d2dd188af06ec4395e5e01f0.jpg', '1564399942', '1564399942');
INSERT INTO `think_community_file` VALUES ('59', '17', '/public/uploads/issue/20190729/cb4c9dbc73aa9e27ba74892025ebbf71.jpg', '1564399942', '1564399942');
INSERT INTO `think_community_file` VALUES ('60', '17', '/public/uploads/issue/20190729/3cd33ed23e6382c1f898cd1607f611fa.jpg', '1564399942', '1564399942');
INSERT INTO `think_community_file` VALUES ('61', '17', '/public/uploads/issue/20190729/eb2c1b91fb4f36131af75589c4e000fc.jpg', '1564399942', '1564399942');
INSERT INTO `think_community_file` VALUES ('62', '17', '/public/uploads/issue/20190729/4a79f87fe0aeb93d7d14146add50ea8b.jpg', '1564399942', '1564399942');
INSERT INTO `think_community_file` VALUES ('63', '17', '/public/uploads/issue/20190729/045d01915fd49d7a62f1e9af0fa28d0a.jpg', '1564399942', '1564399942');
INSERT INTO `think_community_file` VALUES ('64', '18', '', '1564449669', '1564449669');
INSERT INTO `think_community_file` VALUES ('65', '19', '', '1564449914', '1564449914');
INSERT INTO `think_community_file` VALUES ('66', '20', '/public/uploads/issue/20190730/d2eac0bb13c0ce240c54197bd1543ff9.jpg', '1564484958', '1564484958');
INSERT INTO `think_community_file` VALUES ('67', '20', '/public/uploads/issue/20190730/c367c4b5e31889f5b83f71180ef26d2b.jpg', '1564484958', '1564484958');
INSERT INTO `think_community_file` VALUES ('68', '20', '/public/uploads/issue/20190730/b3b5264a275c23afafaadb5a7113fc3f.jpg', '1564484958', '1564484958');
INSERT INTO `think_community_file` VALUES ('69', '20', '/public/uploads/issue/20190730/b772ec25e1de926408c45aa454115da0.jpg', '1564484958', '1564484958');
INSERT INTO `think_community_file` VALUES ('70', '20', '/public/uploads/issue/20190730/c72d667ff76cbd548f79829b9d957fe0.jpg', '1564484958', '1564484958');
INSERT INTO `think_community_file` VALUES ('71', '20', '/public/uploads/issue/20190730/d7596b7b26f7ceb3b0c01c3b7a526dc2.jpg', '1564484958', '1564484958');
INSERT INTO `think_community_file` VALUES ('72', '20', '/public/uploads/issue/20190730/c443f939b9c5acfcaa889cf0798729cb.jpg', '1564484958', '1564484958');
INSERT INTO `think_community_file` VALUES ('73', '20', '/public/uploads/issue/20190730/5b411ff51c4acdac13b9fadf901a5f40.jpg', '1564484958', '1564484958');
INSERT INTO `think_community_file` VALUES ('74', '21', '', '1564675104', '1564675104');

-- -----------------------------
-- Table structure for `think_config`
-- -----------------------------
DROP TABLE IF EXISTS `think_config`;
CREATE TABLE `think_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `value` text COMMENT '配置值',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_config`
-- -----------------------------
INSERT INTO `think_config` VALUES ('1', 'web_site_title', '唐人后台管理系统');
INSERT INTO `think_config` VALUES ('2', 'web_site_description', '唐人后台管理系统');
INSERT INTO `think_config` VALUES ('3', 'web_site_keyword', '唐人后台管理系统');
INSERT INTO `think_config` VALUES ('4', 'web_site_icp', '******');
INSERT INTO `think_config` VALUES ('5', 'web_site_cnzz', '');
INSERT INTO `think_config` VALUES ('6', 'web_site_copy', 'Copyright © 2019 唐人后台管理系统 All rights reserved.');
INSERT INTO `think_config` VALUES ('7', 'web_site_close', '1');
INSERT INTO `think_config` VALUES ('8', 'list_rows', '10');
INSERT INTO `think_config` VALUES ('9', 'admin_allow_ip', '');
INSERT INTO `think_config` VALUES ('10', 'alisms_appkey', '');
INSERT INTO `think_config` VALUES ('11', 'alisms_appsecret', '');
INSERT INTO `think_config` VALUES ('12', 'alisms_signname', '');

-- -----------------------------
-- Table structure for `think_coupon`
-- -----------------------------
DROP TABLE IF EXISTS `think_coupon`;
CREATE TABLE `think_coupon` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL COMMENT '优惠卷标题',
  `money` decimal(10,0) NOT NULL DEFAULT '1' COMMENT '优惠卷金额',
  `description` varchar(255) NOT NULL COMMENT '优惠卷描述',
  `shop_name` varchar(50) NOT NULL COMMENT '使用优惠卷店铺',
  `address` varchar(255) NOT NULL COMMENT '店铺地址',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '显示状态(0:显示 1:不显示)',
  `activity_create_time` int(10) unsigned NOT NULL COMMENT '活动开始时间',
  `activity_end_time` int(10) unsigned NOT NULL COMMENT '活动结束时间',
  `expire` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否过期（0:没过期 1:过期）',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='优惠卷';

-- -----------------------------
-- Records of `think_coupon`
-- -----------------------------
INSERT INTO `think_coupon` VALUES ('1', '七月海鲜大优惠', '100', '仅到店消费满660元可减免', '邵记海鲜店', '212 Grand', '0', '1563258029', '1563533115', '1', '1563258029', '1563533132');
INSERT INTO `think_coupon` VALUES ('2', '新店开张大优惠', '100', '仅到店消费满660元可减免', '中华大超市', '212 Grand', '0', '1563258029', '1563613416', '1', '1563258029', '1563618390');
INSERT INTO `think_coupon` VALUES ('3', '新店开张大优惠', '1000', '新店开张大优惠', '新店开张大优惠', '新店开张大优惠', '0', '1563258029', '1563258029', '1', '1563258029', '1563589797');

-- -----------------------------
-- Table structure for `think_customer_service`
-- -----------------------------
DROP TABLE IF EXISTS `think_customer_service`;
CREATE TABLE `think_customer_service` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `phone` varchar(32) CHARACTER SET utf8 NOT NULL COMMENT '客服电话',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态（0：显示 1：不显示）',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

-- -----------------------------
-- Records of `think_customer_service`
-- -----------------------------
INSERT INTO `think_customer_service` VALUES ('1', '13466365876', '0', '1563104486', '1563104486');

-- -----------------------------
-- Table structure for `think_dining_images`
-- -----------------------------
DROP TABLE IF EXISTS `think_dining_images`;
CREATE TABLE `think_dining_images` (
  `dining_img_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '餐厅详情表ID',
  `dining_id` int(11) DEFAULT NULL COMMENT '餐厅ID',
  `dining_images` varchar(255) DEFAULT NULL COMMENT '餐厅图片',
  `dining_status` int(1) DEFAULT NULL COMMENT '图片状态',
  PRIMARY KEY (`dining_img_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_dining_images`
-- -----------------------------
INSERT INTO `think_dining_images` VALUES ('1', '1', '20190726/954f1d38e7f2220efa42c110469bc6c0.jpg', '1');
INSERT INTO `think_dining_images` VALUES ('2', '1', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '1');
INSERT INTO `think_dining_images` VALUES ('3', '1', '20190726/ca43c469bea1287a63d5df3c2cc1ada9.jpg', '0');
INSERT INTO `think_dining_images` VALUES ('4', '2', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '0');
INSERT INTO `think_dining_images` VALUES ('5', '2', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '0');
INSERT INTO `think_dining_images` VALUES ('6', '2', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '0');
INSERT INTO `think_dining_images` VALUES ('7', '3', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '0');
INSERT INTO `think_dining_images` VALUES ('8', '3', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '0');
INSERT INTO `think_dining_images` VALUES ('9', '3', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '0');
INSERT INTO `think_dining_images` VALUES ('10', '4', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '0');
INSERT INTO `think_dining_images` VALUES ('11', '4', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '0');
INSERT INTO `think_dining_images` VALUES ('12', '4', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '0');
INSERT INTO `think_dining_images` VALUES ('13', '1', '20190726/1c1bcb92950e89548fbc20f896042d2d.jpg', '0');
INSERT INTO `think_dining_images` VALUES ('14', '2', '20190726/469af8c17fd4d49db9c305785775bf6d.jpg', '0');
INSERT INTO `think_dining_images` VALUES ('15', '1', '20190726/6c4267a029d94dcc3b30b55224d1cbc3.jpg', '0');

-- -----------------------------
-- Table structure for `think_dining_list`
-- -----------------------------
DROP TABLE IF EXISTS `think_dining_list`;
CREATE TABLE `think_dining_list` (
  `dining_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '餐厅列表',
  `dining_logo` varchar(255) DEFAULT NULL COMMENT '餐厅详情',
  `dining_class` varchar(255) DEFAULT NULL COMMENT '餐厅所在地区',
  `dining_name` varchar(255) DEFAULT NULL COMMENT '餐厅名称',
  `dining_content` varchar(255) DEFAULT NULL COMMENT '餐厅介绍',
  `dining_time` varchar(255) DEFAULT NULL COMMENT '营业时间',
  `dining_day` varchar(255) DEFAULT NULL COMMENT '营业时间周几到周几',
  `dining_phone` varchar(12) DEFAULT NULL COMMENT '联系电话',
  `dining_address` varchar(255) DEFAULT NULL COMMENT '具体位置',
  `dining_all` int(1) DEFAULT NULL COMMENT '综合平分',
  `dining_service` int(1) DEFAULT NULL COMMENT '服务',
  `dining_hygiene` int(1) DEFAULT NULL COMMENT '卫生评分',
  `dining_taste` int(1) DEFAULT NULL COMMENT '味道评分',
  `dining_label` varchar(255) DEFAULT NULL COMMENT '餐厅标签',
  `dining_status` int(1) DEFAULT '1' COMMENT '推荐状态（0：推荐 1：不推荐）',
  `dining_home` int(1) DEFAULT '1' COMMENT '首页推荐状态(0 ：推荐 1：不推荐:)',
  `collect` int(11) DEFAULT '0' COMMENT '收藏数量',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `exits_status` varchar(255) DEFAULT '0' COMMENT '删除状态（0为未删除 时间戳为删除时间）',
  PRIMARY KEY (`dining_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_dining_list`
-- -----------------------------
INSERT INTO `think_dining_list` VALUES ('1', '/public/uploads/images/20190730/1f0daf52e7f04022f83a8fc7d650c459.jpg', '海淀', '餐厅1', '介绍1', '00:00-00:00', '周一到周一', '13465258942', '亮马桥', '3', '3', '3', '3', '[\"wifi\"]', '0', '0', '2', '', '', '0');
INSERT INTO `think_dining_list` VALUES ('2', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '海淀', '餐厅2', '介绍2', '00:00-24:00', '周一到周日', '13465258942', '亮马桥', '3', '3', '3', '3', '[\"wifi\"]', '0', '0', '1', '', '', '0');
INSERT INTO `think_dining_list` VALUES ('3', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '海淀', '餐厅3', '介绍3', '00:00-24:00', '周一到周日', '13465258942', '亮马桥', '3', '3', '3', '3', '[\"wifi\"]', '0', '0', '0', '', '', '1564134500');
INSERT INTO `think_dining_list` VALUES ('4', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '海淀', '餐厅4', '介绍4', '00:00-24:00', '周一到周日', '13465258942', '亮马桥', '3', '3', '3', '3', '[\"wifi\"]', '0', '0', '0', '', '', '1564113465');
INSERT INTO `think_dining_list` VALUES ('5', '', '东城', '北京烤鸭', '北京烤鸭，北京烤鸭，北京烤鸭，', '06:19-22:20', '周一到周日', '18406985126', '北京东直门大街25号', '', '', '', '', '[\"wifi\"]', '', '', '0', '', '', '1564134472');
INSERT INTO `think_dining_list` VALUES ('6', '/public/uploads/images/20190730/08f1192d614ebcd8eadeffae6839397c.jpg', '东城', '全聚德', '全聚德全聚德全聚德全聚德全聚德', '09:00-19:19', '周一到周日', '18406985126', '北京东直门大街26号', '', '', '', '', '[\"wifi\"]', '0', '0', '0', '', '', '0');
INSERT INTO `think_dining_list` VALUES ('7', '20190726/e5cdc03fedfa5530fec12d71112137ee.jpg', '海淀', '1', '2', '00:00-00:00', '周一到周一', '2', '2', '', '', '', '', '[\"免费矿泉水\",\"24小时接送服务\"]', '1', '', '0', '', '', '1564193706');
INSERT INTO `think_dining_list` VALUES ('8', '/public/uploads/images/20190730/8f67181dea2da3ef4258edb4f5c7e31a.jpeg', '东城', '小笼包', '小笼包', '06:00-10:00', '周一到周日', '1234533565', '小笼包大街', '', '', '', '', '[\"免费矿泉水\",\"wifi\"]', '0', '0', '0', '', '', '0');
INSERT INTO `think_dining_list` VALUES ('9', '/public/uploads/images/20190730/b5a59ae2dcb9d82f6a7a542ae07c2a33.jpg', '海淀', '虾饺', '虾饺', '06:00-10:00', '周一到周日', '84764038743', '虾饺大街', '', '', '', '', '[\"免费矿泉水\",\"wifi\"]', '1', '1', '0', '', '', '0');

-- -----------------------------
-- Table structure for `think_dining_user`
-- -----------------------------
DROP TABLE IF EXISTS `think_dining_user`;
CREATE TABLE `think_dining_user` (
  `dining_user_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户评价餐厅表',
  `dining_id` int(11) DEFAULT NULL COMMENT '餐厅id',
  `id` int(11) DEFAULT NULL COMMENT '用户id',
  `comment_time` int(11) DEFAULT NULL COMMENT '评价时间',
  `comment_content` varchar(255) DEFAULT NULL COMMENT '评论内容',
  `comment_images` text COMMENT '评论图片',
  `comment_all` int(1) DEFAULT NULL COMMENT '综合评分',
  `comment_service` int(1) DEFAULT NULL COMMENT '服务评分',
  `comment_hygiene` int(1) DEFAULT NULL COMMENT '卫生评分',
  `comment_taste` int(1) DEFAULT NULL COMMENT '味道评分',
  `comment_sati` varchar(255) DEFAULT NULL COMMENT '满意度',
  PRIMARY KEY (`dining_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_dining_user`
-- -----------------------------
INSERT INTO `think_dining_user` VALUES ('1', '1', '13', '1563150916', '评论1', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '1', '1', '1', '1', '满意');
INSERT INTO `think_dining_user` VALUES ('2', '1', '13', '1563151885', '这是评论', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '2', '2', '2', '2', '满意');
INSERT INTO `think_dining_user` VALUES ('3', '1', '13', '1563152055', '这是评论', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '2', '2', '2', '2', '满意');
INSERT INTO `think_dining_user` VALUES ('4', '1', '13', '1563152116', '这是评论', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '2', '2', '2', '2', '满意');
INSERT INTO `think_dining_user` VALUES ('5', '1', '13', '1563152303', '这是评论', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '2', '2', '2', '2', '满意');
INSERT INTO `think_dining_user` VALUES ('6', '1', '13', '1563152986', '这是评论', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '2', '2', '2', '2', '满意');
INSERT INTO `think_dining_user` VALUES ('7', '1', '13', '1563153036', '这是评论', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '2', '2', '2', '2', '满意');
INSERT INTO `think_dining_user` VALUES ('8', '1', '13', '1563153117', '这是评论', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '2', '2', '2', '2', '满意');
INSERT INTO `think_dining_user` VALUES ('9', '1', '13', '1563155628', '这是评论', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '2', '2', '2', '2', '满意');
INSERT INTO `think_dining_user` VALUES ('10', '1', '13', '1563155711', '这是评论', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '2', '2', '2', '2', '满意');
INSERT INTO `think_dining_user` VALUES ('11', '1', '13', '1563156188', '这是评论', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '2', '2', '2', '2', '满意');
INSERT INTO `think_dining_user` VALUES ('12', '1', '13', '1563691303', '111111', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '3', '3', '3', '3', '满意');
INSERT INTO `think_dining_user` VALUES ('13', '1', '13', '1563691657', '111111', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '4', '5', '5', '3', '满意');
INSERT INTO `think_dining_user` VALUES ('14', '1', '13', '1563692603', '11111111111', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '4', '3', '5', '3', '满意');
INSERT INTO `think_dining_user` VALUES ('15', '1', '23', '1563692603', '1', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '2', '2', '1', '2', '一般');
INSERT INTO `think_dining_user` VALUES ('20', '1', '212082', '1563692603', '不错不错不错', '/public/uploads/issue/20190730/036a809f774a241c4f2965bc4c043b76.jpg,/public/uploads/issue/20190730/2fbe507c05fcf69416119b50e49e9cb3.jpg', '4', '3', '3', '5', '超满意');
INSERT INTO `think_dining_user` VALUES ('21', '1', '212082', '1564539922', '不错不错不错', '', '4', '5', '4', '4', '超满意');
INSERT INTO `think_dining_user` VALUES ('22', '1', '212082', '1564539961', '不错不错不错', '', '4', '5', '4', '3', '超满意');
INSERT INTO `think_dining_user` VALUES ('23', '1', '13', '1564540009', 'azxaa', '/public/uploads/issue/20190731/ea9056e352069eae394fb91125512453.jpg', '3', '3', '3', '4', '满意');

-- -----------------------------
-- Table structure for `think_goods_fraction`
-- -----------------------------
DROP TABLE IF EXISTS `think_goods_fraction`;
CREATE TABLE `think_goods_fraction` (
  `goods_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '积分商城表',
  `goods_name` varchar(255) DEFAULT NULL COMMENT '商品名称',
  `goods_img` varchar(255) DEFAULT NULL COMMENT '商品图片',
  `goods_fraction` int(11) DEFAULT NULL COMMENT '价格',
  `goods_number` int(11) DEFAULT NULL COMMENT '数量',
  PRIMARY KEY (`goods_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_goods_fraction`
-- -----------------------------
INSERT INTO `think_goods_fraction` VALUES ('1', '商品去', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '10', '100');
INSERT INTO `think_goods_fraction` VALUES ('2', '商品2', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '20', '200');

-- -----------------------------
-- Table structure for `think_goods_order`
-- -----------------------------
DROP TABLE IF EXISTS `think_goods_order`;
CREATE TABLE `think_goods_order` (
  `order_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '积分商城订单表',
  `id` int(11) DEFAULT NULL COMMENT '用户ID',
  `goods_id` int(11) DEFAULT NULL COMMENT '商品ID',
  `order_status` int(11) DEFAULT NULL COMMENT '订单状态(0已购买 1未购买)',
  `logistics` tinyint(1) DEFAULT NULL COMMENT '物流状态(0已发货 1未发货)',
  `order_time` varchar(255) DEFAULT NULL COMMENT '订单生成时间',
  `address_id` int(11) NOT NULL COMMENT '地址id',
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_goods_order`
-- -----------------------------
INSERT INTO `think_goods_order` VALUES ('9', '1', '1', '0', '1', '2019年08月02日', '2');
INSERT INTO `think_goods_order` VALUES ('10', '1', '1', '0', '1', '2019年08月02日', '2');
INSERT INTO `think_goods_order` VALUES ('11', '13', '1', '0', '1', '2019年08月02日', '37');
INSERT INTO `think_goods_order` VALUES ('12', '1', '1', '0', '1', '2019年08月02日', '2');
INSERT INTO `think_goods_order` VALUES ('13', '13', '1', '0', '1', '2019年08月02日', '37');
INSERT INTO `think_goods_order` VALUES ('14', '13', '1', '0', '1', '2019年08月02日', '36');
INSERT INTO `think_goods_order` VALUES ('15', '13', '1', '0', '1', '2019年08月02日', '37');

-- -----------------------------
-- Table structure for `think_hotel_img`
-- -----------------------------
DROP TABLE IF EXISTS `think_hotel_img`;
CREATE TABLE `think_hotel_img` (
  `hotel_img_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '酒店详情图片表',
  `hotel_id` int(11) DEFAULT NULL COMMENT '酒店ID',
  `hotel_images` varchar(255) DEFAULT NULL COMMENT '详情图片',
  `img_status` int(1) DEFAULT NULL COMMENT '图片ID状态(是否被删除)',
  PRIMARY KEY (`hotel_img_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_hotel_img`
-- -----------------------------
INSERT INTO `think_hotel_img` VALUES ('1', '1', '/public/uploads/images/20190730/438eb6a61bc0bfa28cbb4940baec09b9.jpeg', '0');
INSERT INTO `think_hotel_img` VALUES ('2', '1', 'http://ceshi.800123456.top//public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '1');
INSERT INTO `think_hotel_img` VALUES ('3', '1', 'http://ceshi.800123456.top//public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '1');
INSERT INTO `think_hotel_img` VALUES ('4', '1', 'http://ceshi.800123456.top//public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '1');
INSERT INTO `think_hotel_img` VALUES ('5', '1', '/public/uploads/images/20190730/41bcd6f847a2afae4d5a57259eb2f099.jpeg', '0');
INSERT INTO `think_hotel_img` VALUES ('6', '1', '20190726/5348a519bf8899a667f2d193b3dfd55e.jpg', '1');
INSERT INTO `think_hotel_img` VALUES ('7', '1', '/public/uploads/images/20190730/e3a7f410f6644a7c0ad3c639d30566b9.jpg', '0');
INSERT INTO `think_hotel_img` VALUES ('8', '1', '/public/uploads/images/20190730/199bd3621365d005d17cae17f6aab496.jpg', '0');
INSERT INTO `think_hotel_img` VALUES ('9', '6', '/public/uploads/images/20190730/e3c766ba795d10c577da5f95ba3bea20.jpg', '0');
INSERT INTO `think_hotel_img` VALUES ('10', '6', '/public/uploads/images/20190730/c694fc257e2d05b1f27a222b43e1c7fd.jpeg', '0');
INSERT INTO `think_hotel_img` VALUES ('11', '6', '/public/uploads/images/20190730/33af482287a1d39957990d4092f3b3e0.jpg', '0');
INSERT INTO `think_hotel_img` VALUES ('12', '6', '/public/uploads/images/20190730/1746c1694c063e46bf6372327c13a06c.jpg', '0');
INSERT INTO `think_hotel_img` VALUES ('13', '7', '/public/uploads/images/20190730/27c91da3e0e1bd7a8ca03998f53b2f02.jpeg', '0');
INSERT INTO `think_hotel_img` VALUES ('14', '7', '/public/uploads/images/20190730/45fc037d8706de6ed116484cd757bea1.jpg', '0');
INSERT INTO `think_hotel_img` VALUES ('15', '7', '/public/uploads/images/20190730/675b5848d09cb71b64040210193898ad.jpg', '0');
INSERT INTO `think_hotel_img` VALUES ('16', '7', '/public/uploads/images/20190730/b37980936ed71dad0e6004da9acc8fe2.jpeg', '0');
INSERT INTO `think_hotel_img` VALUES ('17', '12', '/public/uploads/images/20190730/5d41121190e58a324ea5ce0a7f00f24a.jpg', '0');
INSERT INTO `think_hotel_img` VALUES ('18', '12', '/public/uploads/images/20190730/d81d6eefdf45ea69fe0d58740c2d08a8.jpeg', '0');
INSERT INTO `think_hotel_img` VALUES ('19', '12', '/public/uploads/images/20190730/67ac1eff59283bc540aa76580a83990f.jpeg', '0');
INSERT INTO `think_hotel_img` VALUES ('20', '12', '/public/uploads/images/20190730/f23b8a3dca5853b17282b592dfeb5744.jpeg', '0');
INSERT INTO `think_hotel_img` VALUES ('21', '2', '/public/uploads/images/20190730/b1786d70928a12b94435ea326a2e5dd5.jpeg', '0');
INSERT INTO `think_hotel_img` VALUES ('22', '2', '/public/uploads/images/20190730/784482b385965eefc0896c6cd3c50170.jpg', '0');
INSERT INTO `think_hotel_img` VALUES ('23', '2', '/public/uploads/images/20190730/7bcedc2d913cfda843b37fa25fd3756e.jpeg', '0');
INSERT INTO `think_hotel_img` VALUES ('24', '2', '/public/uploads/images/20190730/14bc2b996f5cf73b6d14d8363d84557d.jpeg', '0');
INSERT INTO `think_hotel_img` VALUES ('25', '3', '/public/uploads/images/20190730/ae41139e97c89b0a09034a9e3979051c.jpg', '0');
INSERT INTO `think_hotel_img` VALUES ('26', '3', '/public/uploads/images/20190730/b2111879137e8a1d6ffbc7bc4efec150.jpeg', '0');
INSERT INTO `think_hotel_img` VALUES ('27', '3', '/public/uploads/images/20190730/3d7bdf2e9e5eab48bd2bb64312b0b7ec.jpeg', '0');
INSERT INTO `think_hotel_img` VALUES ('28', '3', '/public/uploads/images/20190730/84a8e205d86c8f20aad54aa262c11fbe.jpg', '0');
INSERT INTO `think_hotel_img` VALUES ('29', '13', '/public/uploads/images/20190730/9b6d399e1d5e9e1f4db9b0e8055e113c.jpg', '0');
INSERT INTO `think_hotel_img` VALUES ('30', '13', '/public/uploads/images/20190730/e5a0b7989594a6f758f9d8e00f8304e3.jpg', '0');
INSERT INTO `think_hotel_img` VALUES ('31', '13', '/public/uploads/images/20190730/03e9cd643056cb21ccdd4029bef0aa38.jpeg', '0');
INSERT INTO `think_hotel_img` VALUES ('32', '13', '/public/uploads/images/20190730/88167117b476c36a53fa7ea05ea5a3bf.jpg', '0');
INSERT INTO `think_hotel_img` VALUES ('33', '14', '/public/uploads/images/20190730/1635e0e4d4a34d57e0aef5edb7360a80.jpg', '0');
INSERT INTO `think_hotel_img` VALUES ('34', '14', '/public/uploads/images/20190730/bf2234a30dc086a8617498135f906072.jpg', '0');
INSERT INTO `think_hotel_img` VALUES ('35', '14', '/public/uploads/images/20190730/d26c303408fb72e7d01662ada83b6f1b.jpeg', '0');
INSERT INTO `think_hotel_img` VALUES ('36', '14', '/public/uploads/images/20190730/befeef36b5b19cb5e082642284b58e3c.jpg', '0');

-- -----------------------------
-- Table structure for `think_hotel_list`
-- -----------------------------
DROP TABLE IF EXISTS `think_hotel_list`;
CREATE TABLE `think_hotel_list` (
  `hotel_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '酒店详情表',
  `hotel_logo` varchar(255) DEFAULT NULL COMMENT '酒店主图logo',
  `hotel_class` varchar(255) DEFAULT NULL COMMENT '酒店地区',
  `hotel_name` varchar(255) DEFAULT NULL COMMENT '酒店名称',
  `hotel_content` varchar(255) DEFAULT NULL COMMENT '酒店介绍',
  `hotel_time` varchar(255) DEFAULT NULL COMMENT '营业时间',
  `hotel_day` varchar(255) DEFAULT NULL COMMENT '营业时间周几到周几',
  `hotel_phone` varchar(255) DEFAULT NULL COMMENT '联系电话',
  `hotel_address` varchar(255) DEFAULT NULL COMMENT '地址',
  `hotel_all` int(11) DEFAULT NULL COMMENT '酒店综合积分',
  `hotel_status` int(11) DEFAULT '1' COMMENT '推荐状态(默认1未推荐 0为推荐)',
  `hotel_hygiene` int(11) DEFAULT NULL COMMENT '卫生评分',
  `hotel_ambient` int(11) DEFAULT NULL COMMENT '环境评分',
  `hotel_service` int(11) DEFAULT NULL COMMENT '服务评分',
  `hotel_label` varchar(255) DEFAULT NULL COMMENT '酒店标签(首页，24小时热水等x信息)',
  `collect` int(11) NOT NULL DEFAULT '0' COMMENT '收藏数量',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `exits_status` tinyint(1) DEFAULT '0' COMMENT '删除状态(0 为未删除 时间戳为已删除)',
  PRIMARY KEY (`hotel_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_hotel_list`
-- -----------------------------
INSERT INTO `think_hotel_list` VALUES ('1', '/public/uploads/images/20190726/11982e80767f739e93ef950ddc714d9c.jpg', '海淀', '万达酒店', '亮马桥万达酒店，亮马桥万达酒店，亮马桥万达酒店，', '00:00-00:00', '周一到周一', '15026981576', '亮马桥', '3', '0', '3', '2', '3', '[\"wifi\"]', '1', '', '', '0');
INSERT INTO `think_hotel_list` VALUES ('2', '/public/uploads/images/20190726/ef74ebfc09053e96758e0878ecabe70e.jpg', '海淀', '西尔顿', '酒店介绍', '00:00-00:00', '周一到周一', '12312312312', '车道沟', '4', '1', '4', '4', '4', '[\"免费矿泉水\"]', '2', '', '', '0');
INSERT INTO `think_hotel_list` VALUES ('3', '/public/uploads/images/20190726/e5acba38a3913d7fa1e56ab9fc664eb7.jpg', '海淀', '索菲亚', '介绍', '00:00-23:23', '周一到周日', '123123123', '长阳', '3', '1', '3', '3', '3', '[\"24小时营业\"]', '0', '', '', '0');
INSERT INTO `think_hotel_list` VALUES ('4', 'http://ceshi.800123456.top//public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '东城', '万达酒店2', '酒店介绍', '00:00:00-23:59:59', '周一至周日', '12312312312', '亮马桥', '3', '0', '3', '3', '3', '[\"wifi\",\"有窗\"]', '0', '', '', '127');
INSERT INTO `think_hotel_list` VALUES ('5', 'http://ceshi.800123456.top//public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '东城', '万达酒店3', '酒店介绍', '00:00:00-23:59:59', '周一至周日', '12312312312', '亮马桥', '3', '0', '3', '3', '3', '[\"wifi\"]', '0', '', '', '127');
INSERT INTO `think_hotel_list` VALUES ('6', '/public/uploads/images/20190726/a3bde317f233234600b624a9e5ce8def.jpg', '海淀', '万达酒店4', '酒店介绍', '00:00-21:21', '周一到周日', '12312312312', '亮马桥', '3', '0', '3', '3', '3', '[\"免费矿泉水\"]', '0', '', '', '0');
INSERT INTO `think_hotel_list` VALUES ('7', '/public/uploads/images/20190730/39507933474b5f8660157853ba1f7f09.jpg', '海淀', '万达酒店5', '酒店介绍', '06:00-20:20', '周一到周日', '12312312312', '亮马桥', '3', '0', '3', '3', '3', '[\"wifi\"]', '0', '', '', '0');
INSERT INTO `think_hotel_list` VALUES ('8', '20190726/04dbb0506b4aa7d166934fe0ad4a5fa6.jpg', '海淀', '万达酒店6', '酒店介绍', '00:00-00:00', '周一到周一', '12312312312', '亮马桥', '3', '0', '3', '3', '3', '[\"wifi\"]', '0', '', '', '127');
INSERT INTO `think_hotel_list` VALUES ('9', 'http://ceshi.800123456.top//public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '海淀', '万达酒店7', '酒店介绍', '00:00:00-23:59:59', '周一至周日', '12312312312', '亮马桥', '3', '0', '3', '3', '3', '[\"wifi\"]', '0', '', '', '127');
INSERT INTO `think_hotel_list` VALUES ('10', 'http://ceshi.800123456.top//public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '海淀', '万达酒店8', '酒店介绍', '00:00:00-23:59:59', '周一至周日', '12312312312', '亮马桥', '3', '0', '3', '3', '3', '[\"wifi\"]', '0', '', '', '127');
INSERT INTO `think_hotel_list` VALUES ('11', 'http://ceshi.800123456.top//public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '海淀', '万达酒店9', '酒店介绍', '00:00:00-23:59:59', '周一至周日', '12312312312', '亮马桥', '3', '0', '3', '3', '3', '[\"wifi\"]', '0', '', '', '127');
INSERT INTO `think_hotel_list` VALUES ('12', '/public/uploads/images/20190730/790f1f1f18ce0fa65b3dcadb207399ee.jpg', '海淀', '希尔顿酒店', '希尔顿酒店，希尔顿酒店，希尔顿酒店，希尔顿酒店，', '09:10-22:22', '周一到周日', '15026981576', '北京市海淀区五道口', '', '0', '', '', '', '[\"免费矿泉水\",\"wifi\"]', '0', '', '', '0');
INSERT INTO `think_hotel_list` VALUES ('13', '/public/uploads/images/20190730/4b076dae33883e1d16487fba5ade786a.jpg', '东城', '如家', '如家', '00:00-23:59', '周一到周日', '12345674321', '东城2号', '', '1', '', '', '', '[\"免费矿泉水\",\"wifi\"]', '0', '', '', '0');
INSERT INTO `think_hotel_list` VALUES ('14', '/public/uploads/images/20190730/4e36314ca54553052341207afb4987a8.jpg', '东城', '万家灯火', '万家灯火', '00:00-23:59', '周一到周日', '253478963254', '东城3号', '5', '1', '5', '5', '5', '[\"免费矿泉水\",\"wifi\"]', '0', '', '', '0');

-- -----------------------------
-- Table structure for `think_hotel_user`
-- -----------------------------
DROP TABLE IF EXISTS `think_hotel_user`;
CREATE TABLE `think_hotel_user` (
  `hotel_user_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户评价酒店表',
  `hotel_id` int(11) DEFAULT NULL COMMENT '酒店ID',
  `id` int(11) DEFAULT NULL COMMENT '用户ID',
  `comment_time` int(11) DEFAULT NULL COMMENT '评论时间',
  `comment_content` varchar(255) DEFAULT NULL COMMENT '评论内容',
  `comment_service` int(11) DEFAULT NULL COMMENT '服务评分',
  `comment_ambient` int(11) DEFAULT NULL COMMENT '环境评分',
  `comment_hygiene` int(11) DEFAULT NULL COMMENT '卫生评分',
  `comment_all` int(11) DEFAULT NULL COMMENT '综合评分',
  `images` text COMMENT '评论图片(可能是多张图片，或者没有)',
  `comment_sati` varchar(255) DEFAULT NULL COMMENT '满意度',
  PRIMARY KEY (`hotel_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_hotel_user`
-- -----------------------------
INSERT INTO `think_hotel_user` VALUES ('70', '1', '13', '1563692603', '1231', '4', '1', '10', '6', '/public/uploads/hotel/20190721\\CtgFCVzVXd6AEvGfAAE1TGqrmPM173.jpg_C_800_600_Q100.jpg', '一般');
INSERT INTO `think_hotel_user` VALUES ('71', '1', '13', '1563692603', '1232', '4', '2', '10', '6', '/public/uploads/hotel/20190721\\CtgFCVzVXd6AEvGfAAE1TGqrmPM173.jpg_C_800_600_Q100.jpg', '一般');
INSERT INTO `think_hotel_user` VALUES ('81', '1', '13', '1563692603', '1233', '5', '8', '10', '8', '/public/uploads/hotel/20190721\\CtgFCVzVXd6AEvGfAAE1TGqrmPM173.jpg_C_800_600_Q100.jpg', '一般');
INSERT INTO `think_hotel_user` VALUES ('82', '1', '13', '1563692603', '1234', '1', '1', '1', '1', '/public/uploads/hotel/20190721\\CtgFCVzVXd6AEvGfAAE1TGqrmPM173.jpg_C_800_600_Q100.jpg', '一般');
INSERT INTO `think_hotel_user` VALUES ('83', '1', '13', '1563692603', '1235', '1', '1', '1', '1', '/public/uploads/hotel/20190721\\CtgFCVzVXd6AEvGfAAE1TGqrmPM173.jpg_C_800_600_Q100.jpg', '一般');
INSERT INTO `think_hotel_user` VALUES ('84', '1', '13', '1563692603', '1236', '1', '1', '1', '1', '/public/uploads/hotel/20190721\\CtgFCVzVXd6AEvGfAAE1TGqrmPM173.jpg_C_800_600_Q100.jpg', '一般');
INSERT INTO `think_hotel_user` VALUES ('85', '1', '13', '1563692603', '1237', '1', '1', '1', '1', '/public/uploads/hotel/20190721\\CtgFCVzVXd6AEvGfAAE1TGqrmPM173.jpg_C_800_600_Q100.jpg', '一般');
INSERT INTO `think_hotel_user` VALUES ('86', '1', '13', '1563692603', '1238', '1', '1', '1', '1', '/public/uploads/hotel/20190721\\CtgFCVzVXd6AEvGfAAE1TGqrmPM173.jpg_C_800_600_Q100.jpg', '一般');
INSERT INTO `think_hotel_user` VALUES ('87', '1', '13', '1563692603', '1239', '1', '1', '1', '1', '/public/uploads/hotel/20190721\\CtgFCVzVXd6AEvGfAAE1TGqrmPM173.jpg_C_800_600_Q100.jpg', '一般');
INSERT INTO `think_hotel_user` VALUES ('88', '2', '13', '1563692603', '1230', '1', '1', '1', '1', '/public/uploads/hotel/20190721\\CtgFCVzVXd6AEvGfAAE1TGqrmPM173.jpg_C_800_600_Q100.jpg', '一般');
INSERT INTO `think_hotel_user` VALUES ('89', '1', '13', '1563692603', '2230', '1', '1', '1', '1', '/public/uploads/hotel/20190721\\CtgFCVzVXd6AEvGfAAE1TGqrmPM173.jpg_C_800_600_Q100.jpg', '一般');
INSERT INTO `think_hotel_user` VALUES ('90', '1', '13', '1563692603', '1231', '1', '1', '1', '1', '/public/uploads/hotel/20190721\\CtgFCVzVXd6AEvGfAAE1TGqrmPM173.jpg_C_800_600_Q100.jpg', '一般');
INSERT INTO `think_hotel_user` VALUES ('91', '8', '13', '1563692603', '11111', '3', '3', '3', '3', '', '一般');
INSERT INTO `think_hotel_user` VALUES ('92', '14', '212082', '1563692603', '不错不错不错', '5', '5', '5', '5', '/public/uploads/issue/20190730/f035edcbadb5249e14d43403f6220ec2.jpg', '超满意');
INSERT INTO `think_hotel_user` VALUES ('93', '1', '212082', '1563692603', '不错不错不错', '5', '5', '5', '5', '/public/uploads/issue/20190730/df387e7a625eec98a3b1ec4c676b1be1.jpg,/public/uploads/issue/20190730/eb4f9a12e559cd394cbdcc44df3a3f3f.jpg,/public/uploads/issue/20190730/5badebf7d6b484654c2444cbf7af891f.jpg,/public/uploads/issue/20190730/96faf501c1e7912f35241af4b5f199f9.jpg,/public/uploads/issue/20190730/070b74983193ce2c156e9be4a1fb9bae.jpg,/public/uploads/issue/20190730/519f350cc1d0e856b047eb2ed2504779.jpg', '超满意');
INSERT INTO `think_hotel_user` VALUES ('94', '1', '13', '1563692603', '123aaa', '3', '4', '3', '3', '/public/uploads/issue/20190730/0df706950875c912eecd3c1465fae3ad.jpg', '一般');
INSERT INTO `think_hotel_user` VALUES ('95', '1', '13', '1563692603', '2134234', '1', '1', '1', '1', '/public/uploads/issue/20190730/0cbd359eaef44b073b6fc9efdaaa3594.jpg', '很不满意');
INSERT INTO `think_hotel_user` VALUES ('96', '1', '212082', '1563692603', '不错不错不错', '5', '5', '5', '5', '', '超满意');
INSERT INTO `think_hotel_user` VALUES ('97', '1', '212082', '1563692603', '不错不错不错', '1', '3', '3', '2', '', '不满意');
INSERT INTO `think_hotel_user` VALUES ('98', '1', '212082', '1563692603', '不错不错不错', '1', '1', '1', '1', '', '很不满意');
INSERT INTO `think_hotel_user` VALUES ('99', '1', '212082', '1563692603', '不错不错不错', '3', '5', '4', '4', '', '满意');
INSERT INTO `think_hotel_user` VALUES ('100', '1', '212082', '1563692603', '不错不错不错', '1', '1', '1', '1', '', '很不满意');
INSERT INTO `think_hotel_user` VALUES ('101', '1', '212082', '1563692603', '不错不错不错', '4', '2', '4', '3', '', '一般');
INSERT INTO `think_hotel_user` VALUES ('102', '1', '212082', '1563692603', '不错不错不错', '3', '2', '3', '3', '', '一般');
INSERT INTO `think_hotel_user` VALUES ('103', '1', '212082', '1564538975', '不错不错不错', '5', '3', '3', '4', '', '满意');
INSERT INTO `think_hotel_user` VALUES ('104', '1', '212082', '1564539008', '不错不错不错', '3', '3', '2', '3', '', '一般');
INSERT INTO `think_hotel_user` VALUES ('105', '1', '212082', '1564539106', '不错不错不错', '4', '2', '3', '3', '', '一般');
INSERT INTO `think_hotel_user` VALUES ('106', '1', '212082', '1564539778', '还好还好还', '3', '3', '3', '3', '', '一般');
INSERT INTO `think_hotel_user` VALUES ('107', '1', '212082', '1564539897', '不错不错不错', '5', '5', '5', '5', '', '超满意');

-- -----------------------------
-- Table structure for `think_idea`
-- -----------------------------
DROP TABLE IF EXISTS `think_idea`;
CREATE TABLE `think_idea` (
  `eid` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '发表意见表',
  `user_id` int(11) DEFAULT NULL COMMENT '用户ID',
  `content` text COMMENT '内容',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '查看状态（0：以查看 1：未查看）',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`eid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

-- -----------------------------
-- Records of `think_idea`
-- -----------------------------
INSERT INTO `think_idea` VALUES ('1', '212067', '11111', '0', '', '');
INSERT INTO `think_idea` VALUES ('2', '13', '啊实打实大啊实打实大师', '1', '', '');
INSERT INTO `think_idea` VALUES ('3', '212082', '河山大好打电话的好好的', '0', '', '');
INSERT INTO `think_idea` VALUES ('4', '212082', '活动活动忽大忽小好想好想', '1', '1564570409', '1564570409');
INSERT INTO `think_idea` VALUES ('5', '212082', '啊啊啊啊啊啊', '0', '1564570428', '1564570428');

-- -----------------------------
-- Table structure for `think_integral_list`
-- -----------------------------
DROP TABLE IF EXISTS `think_integral_list`;
CREATE TABLE `think_integral_list` (
  `integral_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '积分管理表',
  `integral_number` int(11) DEFAULT NULL COMMENT '积分数量',
  `rmb_number` int(11) DEFAULT NULL COMMENT '积分价格',
  `integral_status` int(1) DEFAULT '1' COMMENT '积分售价状态(是否显示,0显示 1不显示)',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`integral_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_integral_list`
-- -----------------------------
INSERT INTO `think_integral_list` VALUES ('1', '100', '10', '0', '', '');
INSERT INTO `think_integral_list` VALUES ('2', '200', '15', '0', '', '');

-- -----------------------------
-- Table structure for `think_job_comment`
-- -----------------------------
DROP TABLE IF EXISTS `think_job_comment`;
CREATE TABLE `think_job_comment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `job_id` int(11) unsigned NOT NULL COMMENT '求职ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '用户ID',
  `body` text NOT NULL COMMENT '评论内容',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '审核状态(0:已审核 1:未审核 2:审核未通过)',
  `create_time` int(11) unsigned NOT NULL,
  `update_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COMMENT='招聘求职评论';

-- -----------------------------
-- Records of `think_job_comment`
-- -----------------------------
INSERT INTO `think_job_comment` VALUES ('1', '1', '13', '求职招聘评论测试', '1', '1563616305', '1563616305');
INSERT INTO `think_job_comment` VALUES ('2', '1', '13', '求职招聘评论测试', '1', '1563616307', '1563616307');
INSERT INTO `think_job_comment` VALUES ('3', '1', '13', '求职招聘评论测试', '1', '1563616309', '1563616309');
INSERT INTO `think_job_comment` VALUES ('4', '2', '13', '求职招聘评论测试', '1', '1563616313', '1563616313');
INSERT INTO `think_job_comment` VALUES ('5', '2', '13', '求职招聘评论测试', '1', '1563616314', '1563616314');
INSERT INTO `think_job_comment` VALUES ('6', '2', '13', '求职招聘评论测试', '1', '1563616315', '1563616315');
INSERT INTO `think_job_comment` VALUES ('7', '3', '13', '求职招聘评论测试', '1', '1563616319', '1563616319');
INSERT INTO `think_job_comment` VALUES ('8', '3', '13', '求职招聘评论测试', '1', '1563616320', '1563616320');
INSERT INTO `think_job_comment` VALUES ('9', '3', '13', '求职招聘评论测试', '1', '1563616321', '1563616321');
INSERT INTO `think_job_comment` VALUES ('10', '4', '13', '求职招聘评论测试', '1', '1563616324', '1563616324');
INSERT INTO `think_job_comment` VALUES ('11', '4', '13', '求职招聘评论测试', '1', '1563616325', '1563616325');
INSERT INTO `think_job_comment` VALUES ('12', '4', '13', '求职招聘评论测试', '1', '1563616326', '1563616326');
INSERT INTO `think_job_comment` VALUES ('13', '5', '13', '求职招聘评论测试', '1', '1563616330', '1563616330');
INSERT INTO `think_job_comment` VALUES ('14', '5', '13', '求职招聘评论测试', '1', '1563616331', '1563616331');
INSERT INTO `think_job_comment` VALUES ('15', '5', '13', '求职招聘评论测试', '1', '1563616332', '1563616332');
INSERT INTO `think_job_comment` VALUES ('16', '6', '13', '求职招聘评论测试', '1', '1563616335', '1563616335');
INSERT INTO `think_job_comment` VALUES ('17', '6', '13', '求职招聘评论测试', '1', '1563616336', '1563616336');
INSERT INTO `think_job_comment` VALUES ('18', '6', '13', '求职招聘评论测试', '1', '1563616337', '1563616337');
INSERT INTO `think_job_comment` VALUES ('19', '6', '13', '求职招聘评论测试', '1', '1563627728', '1563627728');
INSERT INTO `think_job_comment` VALUES ('20', '6', '13', '求职招聘评论测试', '1', '1563639064', '1563639064');

-- -----------------------------
-- Table structure for `think_job_comment_image`
-- -----------------------------
DROP TABLE IF EXISTS `think_job_comment_image`;
CREATE TABLE `think_job_comment_image` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` int(11) unsigned NOT NULL COMMENT '评论ID',
  `path` varchar(255) DEFAULT NULL COMMENT '评论图片路径',
  `create_time` int(10) unsigned NOT NULL,
  `update_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COMMENT='招聘求职评论图片';

-- -----------------------------
-- Records of `think_job_comment_image`
-- -----------------------------
INSERT INTO `think_job_comment_image` VALUES ('1', '1', '\\/public\\/uploads\\/issue\\/20190720\\/1f2a01283c73ccf88e1126151d132e65.jpg', '1563616305', '1563616305');
INSERT INTO `think_job_comment_image` VALUES ('2', '2', '\\/public\\/uploads\\/issue\\/20190720\\/1f2a01283c73ccf88e1126151d132e65.jpg', '1563616307', '1563616307');
INSERT INTO `think_job_comment_image` VALUES ('3', '3', '\\/public\\/uploads\\/issue\\/20190720\\/1f2a01283c73ccf88e1126151d132e65.jpg', '1563616309', '1563616309');
INSERT INTO `think_job_comment_image` VALUES ('4', '4', '\\/public\\/uploads\\/issue\\/20190720\\/1f2a01283c73ccf88e1126151d132e65.jpg', '1563616313', '1563616313');
INSERT INTO `think_job_comment_image` VALUES ('5', '5', '\\/public\\/uploads\\/issue\\/20190720\\/1f2a01283c73ccf88e1126151d132e65.jpg', '1563616314', '1563616314');
INSERT INTO `think_job_comment_image` VALUES ('6', '6', '\\/public\\/uploads\\/issue\\/20190720\\/1f2a01283c73ccf88e1126151d132e65.jpg', '1563616315', '1563616315');
INSERT INTO `think_job_comment_image` VALUES ('7', '7', '\\/public\\/uploads\\/issue\\/20190720\\/1f2a01283c73ccf88e1126151d132e65.jpg', '1563616319', '1563616319');
INSERT INTO `think_job_comment_image` VALUES ('8', '8', '\\/public\\/uploads\\/issue\\/20190720\\/1f2a01283c73ccf88e1126151d132e65.jpg', '1563616320', '1563616320');
INSERT INTO `think_job_comment_image` VALUES ('9', '9', '\\/public\\/uploads\\/issue\\/20190720\\/1f2a01283c73ccf88e1126151d132e65.jpg', '1563616321', '1563616321');
INSERT INTO `think_job_comment_image` VALUES ('10', '10', '\\/public\\/uploads\\/issue\\/20190720\\/1f2a01283c73ccf88e1126151d132e65.jpg', '1563616324', '1563616324');
INSERT INTO `think_job_comment_image` VALUES ('11', '11', '\\/public\\/uploads\\/issue\\/20190720\\/1f2a01283c73ccf88e1126151d132e65.jpg', '1563616325', '1563616325');
INSERT INTO `think_job_comment_image` VALUES ('12', '12', '\\/public\\/uploads\\/issue\\/20190720\\/1f2a01283c73ccf88e1126151d132e65.jpg', '1563616326', '1563616326');
INSERT INTO `think_job_comment_image` VALUES ('13', '13', '\\/public\\/uploads\\/issue\\/20190720\\/1f2a01283c73ccf88e1126151d132e65.jpg', '1563616330', '1563616330');
INSERT INTO `think_job_comment_image` VALUES ('14', '14', '\\/public\\/uploads\\/issue\\/20190720\\/1f2a01283c73ccf88e1126151d132e65.jpg', '1563616331', '1563616331');
INSERT INTO `think_job_comment_image` VALUES ('15', '15', '\\/public\\/uploads\\/issue\\/20190720\\/1f2a01283c73ccf88e1126151d132e65.jpg', '1563616332', '1563616332');
INSERT INTO `think_job_comment_image` VALUES ('16', '16', '\\/public\\/uploads\\/issue\\/20190720\\/1f2a01283c73ccf88e1126151d132e65.jpg', '1563616335', '1563616335');
INSERT INTO `think_job_comment_image` VALUES ('17', '17', '\\/public\\/uploads\\/issue\\/20190720\\/1f2a01283c73ccf88e1126151d132e65.jpg', '1563616336', '1563616336');
INSERT INTO `think_job_comment_image` VALUES ('18', '18', '\\/public\\/uploads\\/issue\\/20190720\\/1f2a01283c73ccf88e1126151d132e65.jpg', '1563616337', '1563616337');
INSERT INTO `think_job_comment_image` VALUES ('19', '19', '\\/public\\/uploads\\/issue\\/20190720\\/1f2a01283c73ccf88e1126151d132e65.jpg', '1563627728', '1563627728');
INSERT INTO `think_job_comment_image` VALUES ('20', '20', '\\/public\\/uploads\\/issue\\/20190720\\/1f2a01283c73ccf88e1126151d132e65.jpg', '1563639064', '1563639064');

-- -----------------------------
-- Table structure for `think_job_seek`
-- -----------------------------
DROP TABLE IF EXISTS `think_job_seek`;
CREATE TABLE `think_job_seek` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `region_id` int(10) unsigned NOT NULL COMMENT '区域id',
  `profession_id` int(11) unsigned NOT NULL COMMENT '行业分类ID',
  `body` text NOT NULL COMMENT '商品描述',
  `salary` int(11) unsigned NOT NULL COMMENT '工资',
  `sticky_create_time` int(11) unsigned DEFAULT NULL COMMENT '置顶开始时间',
  `sticky_end_time` int(11) unsigned DEFAULT NULL COMMENT '置顶结束时间',
  `sticky_status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '置顶状态(0:置顶1:不置顶)',
  `phone` int(32) NOT NULL COMMENT '电话',
  `praise` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '点赞数量',
  `browse` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览量',
  `review` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '评论数量',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '发布状态(0:以审核,1:未审核2:审核未通过)',
  `create_time` int(11) NOT NULL COMMENT '创建日期',
  `update_time` int(11) NOT NULL COMMENT '修改日期',
  `collect` int(11) NOT NULL DEFAULT '0' COMMENT '收藏数量',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COMMENT='招聘求职';

-- -----------------------------
-- Records of `think_job_seek`
-- -----------------------------
INSERT INTO `think_job_seek` VALUES ('1', '13', '1', '1', '求职招聘测试', '0', '0', '0', '1', '2147483647', '0', '0', '3', '1', '1563616145', '1564036536', '1');
INSERT INTO `think_job_seek` VALUES ('2', '13', '1', '1', '求职招聘测试', '0', '0', '0', '1', '2147483647', '0', '1', '3', '1', '1563616148', '1564038151', '1');
INSERT INTO `think_job_seek` VALUES ('3', '13', '1', '1', '求职招聘测试', '0', '0', '0', '1', '2147483647', '0', '0', '3', '1', '1563616149', '1563616149', '0');
INSERT INTO `think_job_seek` VALUES ('4', '13', '1', '2', '求职招聘测试', '0', '0', '0', '1', '2147483647', '0', '0', '3', '1', '1563616154', '1563616154', '0');
INSERT INTO `think_job_seek` VALUES ('5', '13', '1', '2', '求职招聘测试', '0', '0', '0', '1', '2147483647', '0', '0', '3', '1', '1563616155', '1563616155', '0');
INSERT INTO `think_job_seek` VALUES ('6', '13', '1', '2', '求职招聘测试', '0', '0', '0', '1', '2147483647', '0', '0', '5', '1', '1563616157', '1563616157', '0');
INSERT INTO `think_job_seek` VALUES ('7', '13', '1', '3', '求职招聘测试', '0', '0', '0', '1', '2147483647', '0', '0', '0', '1', '1563616160', '1563616160', '0');
INSERT INTO `think_job_seek` VALUES ('8', '13', '1', '3', '求职招聘测试', '0', '0', '0', '1', '2147483647', '0', '0', '0', '1', '1563616161', '1563616161', '0');
INSERT INTO `think_job_seek` VALUES ('9', '13', '1', '3', '求职招聘测试', '0', '0', '0', '1', '2147483647', '0', '0', '0', '1', '1563616163', '1563616163', '0');
INSERT INTO `think_job_seek` VALUES ('10', '13', '1', '4', '求职招聘测试', '0', '0', '0', '1', '2147483647', '0', '0', '0', '1', '1563616167', '1563616167', '0');
INSERT INTO `think_job_seek` VALUES ('11', '13', '1', '4', '求职招聘测试', '0', '0', '0', '1', '2147483647', '0', '0', '0', '1', '1563616168', '1563616168', '0');
INSERT INTO `think_job_seek` VALUES ('12', '13', '1', '4', '求职招聘测试', '0', '0', '0', '1', '2147483647', '0', '0', '0', '1', '1563616169', '1563616169', '0');
INSERT INTO `think_job_seek` VALUES ('13', '13', '1', '5', '求职招聘测试', '0', '0', '0', '1', '2147483647', '0', '0', '0', '1', '1563616173', '1563616173', '0');
INSERT INTO `think_job_seek` VALUES ('14', '13', '1', '5', '求职招聘测试', '0', '0', '0', '1', '2147483647', '0', '0', '0', '1', '1563616174', '1563616174', '0');
INSERT INTO `think_job_seek` VALUES ('15', '13', '1', '5', '求职招聘测试', '0', '0', '0', '1', '2147483647', '0', '0', '0', '1', '1563616175', '1563616175', '0');
INSERT INTO `think_job_seek` VALUES ('16', '13', '1', '1', '111111', '111111', '0', '0', '1', '11111', '0', '0', '0', '1', '1563624303', '1563624303', '0');
INSERT INTO `think_job_seek` VALUES ('17', '13', '1', '3', '111111', '1111', '1563624320', '1564229120', '1', '1111', '0', '0', '0', '1', '1563624320', '1564399815', '0');
INSERT INTO `think_job_seek` VALUES ('18', '13', '1', '1', '求职招聘测试', '0', '1563627439', '1563713839', '1', '2147483647', '0', '0', '0', '1', '1563627439', '1563759079', '0');
INSERT INTO `think_job_seek` VALUES ('19', '13', '1', '1', '求职招聘测试', '0', '1563627942', '1563714342', '1', '2147483647', '0', '0', '0', '1', '1563627943', '1563759079', '0');
INSERT INTO `think_job_seek` VALUES ('20', '13', '1', '1', '求职招聘测试', '0', '1563627974', '1563714374', '1', '2147483647', '0', '0', '0', '1', '1563627974', '1563759079', '0');
INSERT INTO `think_job_seek` VALUES ('21', '13', '1', '1', '求职招聘测试', '0', '1563627978', '1563714378', '1', '2147483647', '0', '0', '0', '1', '1563627978', '1563759079', '0');
INSERT INTO `think_job_seek` VALUES ('22', '13', '1', '1', '求职招聘测试', '0', '1563627984', '1563714384', '1', '2147483647', '0', '2', '0', '1', '1563627984', '1564038158', '0');
INSERT INTO `think_job_seek` VALUES ('23', '13', '1', '1', '求职招聘测试', '0', '1563638051', '1563724451', '1', '2147483647', '0', '0', '0', '1', '1563638051', '1563759079', '0');
INSERT INTO `think_job_seek` VALUES ('24', '13', '1', '1', '求职招聘测试', '0', '1563639041', '1563725441', '1', '2147483647', '0', '0', '0', '1', '1563639041', '1563759079', '0');
INSERT INTO `think_job_seek` VALUES ('25', '212082', '1', '2', '发布求职测试', '0', '0', '0', '1', '2147483647', '0', '0', '0', '1', '1564208741', '1564208741', '0');
INSERT INTO `think_job_seek` VALUES ('26', '13', '1', '1', '31312312312', '123123132', '1564449685', '1565054485', '0', '1231231231', '0', '0', '0', '1', '1564449685', '1564449685', '0');
INSERT INTO `think_job_seek` VALUES ('27', '13', '1', '1', '15545', '0', '0', '0', '1', '1747174', '0', '0', '0', '1', '1564484927', '1564484927', '0');

-- -----------------------------
-- Table structure for `think_log`
-- -----------------------------
DROP TABLE IF EXISTS `think_log`;
CREATE TABLE `think_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) DEFAULT NULL COMMENT '用户ID',
  `admin_name` varchar(50) DEFAULT NULL COMMENT '用户姓名',
  `description` varchar(300) DEFAULT NULL COMMENT '描述',
  `ip` char(60) DEFAULT NULL COMMENT 'IP地址',
  `status` tinyint(1) DEFAULT NULL COMMENT '1 成功 2 失败',
  `add_time` int(11) DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`log_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4488 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_log`
-- -----------------------------
INSERT INTO `think_log` VALUES ('4337', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1503469529');
INSERT INTO `think_log` VALUES ('4338', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1503469560');
INSERT INTO `think_log` VALUES ('4339', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1503469632');
INSERT INTO `think_log` VALUES ('4340', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1503469748');
INSERT INTO `think_log` VALUES ('4341', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1503469749');
INSERT INTO `think_log` VALUES ('4342', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1503469801');
INSERT INTO `think_log` VALUES ('4343', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1503469853');
INSERT INTO `think_log` VALUES ('4344', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1503470004');
INSERT INTO `think_log` VALUES ('4345', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1503470488');
INSERT INTO `think_log` VALUES ('4346', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1503473610');
INSERT INTO `think_log` VALUES ('4347', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1503569426');
INSERT INTO `think_log` VALUES ('4348', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1505098116');
INSERT INTO `think_log` VALUES ('4349', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1505281421');
INSERT INTO `think_log` VALUES ('4350', '1', 'admin', '用户【admin】添加菜单成功', '0.0.0.0', '1', '1505281878');
INSERT INTO `think_log` VALUES ('4351', '1', 'admin', '用户【admin】添加菜单成功', '0.0.0.0', '1', '1505281944');
INSERT INTO `think_log` VALUES ('4352', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1505283850');
INSERT INTO `think_log` VALUES ('4354', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1505291620');
INSERT INTO `think_log` VALUES ('4355', '1', 'admin', '用户【admin】登录成功', '127.0.0.1', '1', '1513569527');
INSERT INTO `think_log` VALUES ('4356', '1', 'admin', '用户【admin】登录成功', '192.168.129.120', '1', '1562821778');
INSERT INTO `think_log` VALUES ('4357', '1', 'admin', '用户【admin】删除管理员成功(ID=13)', '192.168.129.120', '1', '1562823419');
INSERT INTO `think_log` VALUES ('4358', '1', 'admin', '用户【baimengran】添加成功', '192.168.129.120', '1', '1562830133');
INSERT INTO `think_log` VALUES ('4359', '1', 'admin', '用户【admin】添加菜单成功', '192.168.129.120', '1', '1562832499');
INSERT INTO `think_log` VALUES ('4360', '1', 'admin', '用户【admin】编辑菜单成功', '192.168.129.120', '1', '1562832787');
INSERT INTO `think_log` VALUES ('4361', '1', 'admin', '用户【admin】添加菜单成功', '192.168.129.120', '1', '1562833186');
INSERT INTO `think_log` VALUES ('4362', '1', 'admin', '用户【admin】添加菜单成功', '192.168.129.120', '1', '1562833352');
INSERT INTO `think_log` VALUES ('4363', '1', 'admin', '用户【admin】添加菜单成功', '192.168.129.120', '1', '1562833468');
INSERT INTO `think_log` VALUES ('4364', '1', 'admin', '用户【admin】编辑菜单成功', '192.168.129.120', '1', '1562841015');
INSERT INTO `think_log` VALUES ('4365', '1', 'admin', '用户【admin】登录成功', '127.0.0.1', '1', '1562895267');
INSERT INTO `think_log` VALUES ('4366', '1', 'admin', '用户【admin】登录成功', '127.0.0.1', '1', '1563265303');
INSERT INTO `think_log` VALUES ('4367', '1', 'admin', '用户【admin】登录成功', '127.0.0.1', '1', '1563334292');
INSERT INTO `think_log` VALUES ('4368', '1', 'admin', '用户【admin】登录成功', '127.0.0.1', '1', '1563425655');
INSERT INTO `think_log` VALUES ('4369', '1', 'admin', '用户【admin】登录成功', '127.0.0.1', '1', '1563426376');
INSERT INTO `think_log` VALUES ('4370', '1', 'admin', '用户【admin】登录成功', '127.0.0.1', '1', '1563504635');
INSERT INTO `think_log` VALUES ('4371', '1', 'admin', '用户【admin】登录成功', '1.94.173.176', '1', '1563679751');
INSERT INTO `think_log` VALUES ('4372', '1', 'admin', '用户【admin】登录成功', '1.94.173.176', '1', '1563679776');
INSERT INTO `think_log` VALUES ('4373', '1', 'admin', '用户【admin】登录成功', '1.94.173.176', '1', '1563679895');
INSERT INTO `think_log` VALUES ('4374', '1', 'admin', '用户【admin】登录成功', '1.94.173.176', '1', '1563679935');
INSERT INTO `think_log` VALUES ('4375', '1', 'admin', '用户【admin】登录成功', '1.94.173.176', '1', '1563680743');
INSERT INTO `think_log` VALUES ('4376', '1', 'admin', '用户【admin】登录成功', '1.94.173.176', '1', '1563680991');
INSERT INTO `think_log` VALUES ('4377', '1', 'admin', '用户【admin】登录成功', '1.94.173.176', '1', '1563681038');
INSERT INTO `think_log` VALUES ('4378', '1', 'admin', '用户【admin】登录成功', '1.94.173.176', '1', '1563681099');
INSERT INTO `think_log` VALUES ('4379', '1', 'admin', '用户【admin】登录成功', '1.94.173.176', '1', '1563681227');
INSERT INTO `think_log` VALUES ('4380', '1', 'admin', '用户【admin】登录成功', '1.94.173.176', '1', '1563688987');
INSERT INTO `think_log` VALUES ('4381', '1', 'admin', '用户【admin】登录成功', '1.94.173.176', '1', '1563689260');
INSERT INTO `think_log` VALUES ('4382', '1', 'admin', '用户【admin】登录成功', '1.94.173.176', '1', '1563689524');
INSERT INTO `think_log` VALUES ('4383', '1', 'admin', '用户【admin】登录成功', '1.94.173.176', '1', '1563689941');
INSERT INTO `think_log` VALUES ('4384', '1', 'admin', '用户【admin】登录成功', '1.94.173.176', '1', '1563690115');
INSERT INTO `think_log` VALUES ('4385', '1', 'admin', '用户【admin】登录成功', '1.94.173.176', '1', '1563690242');
INSERT INTO `think_log` VALUES ('4386', '1', 'admin', '用户【admin】登录成功', '1.94.173.176', '1', '1563690331');
INSERT INTO `think_log` VALUES ('4387', '1', 'admin', '用户【admin】登录成功', '1.94.173.176', '1', '1563690666');
INSERT INTO `think_log` VALUES ('4388', '1', 'admin', '用户【admin】登录成功', '1.94.173.176', '1', '1563690674');
INSERT INTO `think_log` VALUES ('4389', '1', 'admin', '用户【admin】登录成功', '1.94.173.176', '1', '1563690677');
INSERT INTO `think_log` VALUES ('4390', '1', 'admin', '用户【admin】登录成功', '1.94.173.176', '1', '1563690681');
INSERT INTO `think_log` VALUES ('4391', '1', 'admin', '用户【admin】登录成功', '1.94.173.176', '1', '1563690684');
INSERT INTO `think_log` VALUES ('4392', '1', 'admin', '用户【admin】登录成功', '1.94.173.176', '1', '1563691066');
INSERT INTO `think_log` VALUES ('4393', '1', 'admin', '用户【admin】登录成功', '1.94.173.176', '1', '1563691105');
INSERT INTO `think_log` VALUES ('4394', '1', 'admin', '用户【admin】登录成功', '1.94.173.176', '1', '1563691469');
INSERT INTO `think_log` VALUES ('4395', '1', 'admin', '用户【admin】登录成功', '1.94.173.176', '1', '1563692464');
INSERT INTO `think_log` VALUES ('4396', '1', 'admin', '用户【admin】删除菜单成功', '1.94.173.176', '1', '1563721094');
INSERT INTO `think_log` VALUES ('4397', '1', 'admin', '用户【admin】删除菜单成功', '1.94.173.176', '1', '1563721104');
INSERT INTO `think_log` VALUES ('4398', '1', 'admin', '用户【admin】添加菜单成功', '1.94.173.176', '1', '1563721684');
INSERT INTO `think_log` VALUES ('4399', '1', 'admin', '用户【admin】编辑菜单成功', '1.94.173.176', '1', '1563721739');
INSERT INTO `think_log` VALUES ('4400', '1', 'admin', '用户【admin】编辑菜单成功', '1.94.173.176', '1', '1563721754');
INSERT INTO `think_log` VALUES ('4401', '1', 'admin', '用户【admin】编辑菜单成功', '1.94.173.176', '1', '1563721774');
INSERT INTO `think_log` VALUES ('4402', '1', 'admin', '用户【admin】添加菜单成功', '1.94.173.176', '1', '1563721939');
INSERT INTO `think_log` VALUES ('4403', '1', 'admin', '用户【admin】添加菜单成功', '1.94.173.176', '1', '1563722067');
INSERT INTO `think_log` VALUES ('4404', '1', 'admin', '用户【admin】添加菜单成功', '1.94.173.176', '1', '1563722169');
INSERT INTO `think_log` VALUES ('4405', '1', 'admin', '用户【admin】添加菜单成功', '1.94.173.176', '1', '1563722441');
INSERT INTO `think_log` VALUES ('4406', '1', 'admin', '用户【admin】添加菜单成功', '1.94.173.176', '1', '1563722672');
INSERT INTO `think_log` VALUES ('4407', '1', 'admin', '用户【admin】添加菜单成功', '1.94.173.176', '1', '1563723508');
INSERT INTO `think_log` VALUES ('4408', '1', 'admin', '用户【admin】添加菜单成功', '1.94.173.176', '1', '1563723655');
INSERT INTO `think_log` VALUES ('4409', '1', 'admin', '用户【admin】添加菜单成功', '1.94.173.176', '1', '1563723756');
INSERT INTO `think_log` VALUES ('4410', '1', 'admin', '用户【admin】添加菜单成功', '1.94.173.176', '1', '1563724173');
INSERT INTO `think_log` VALUES ('4411', '1', 'admin', '用户【admin】登录成功', '111.203.168.4', '1', '1563758179');
INSERT INTO `think_log` VALUES ('4412', '1', 'admin', '用户【admin】登录成功', '111.203.168.4', '1', '1563758184');
INSERT INTO `think_log` VALUES ('4413', '1', 'admin', '用户【admin】登录成功', '111.203.168.4', '1', '1563758201');
INSERT INTO `think_log` VALUES ('4414', '1', 'admin', '用户【admin】登录成功', '111.203.168.4', '1', '1563758229');
INSERT INTO `think_log` VALUES ('4415', '1', 'admin', '用户【admin】登录成功', '111.203.168.4', '1', '1563758240');
INSERT INTO `think_log` VALUES ('4416', '1', 'admin', '用户【admin】登录成功', '111.203.168.4', '1', '1563758249');
INSERT INTO `think_log` VALUES ('4417', '1', 'admin', '用户【admin】登录成功', '111.203.168.4', '1', '1563758454');
INSERT INTO `think_log` VALUES ('4418', '1', 'admin', '用户【admin】登录成功', '111.203.168.4', '1', '1563758536');
INSERT INTO `think_log` VALUES ('4419', '1', 'admin', '用户【admin】登录成功', '111.203.168.4', '1', '1563758563');
INSERT INTO `think_log` VALUES ('4420', '1', 'admin', '用户【admin】登录成功', '111.203.168.4', '1', '1563758635');
INSERT INTO `think_log` VALUES ('4421', '1', 'admin', '用户【admin】登录成功', '111.203.168.4', '1', '1563758644');
INSERT INTO `think_log` VALUES ('4422', '1', 'admin', '用户【admin】登录成功', '111.203.168.4', '1', '1563758708');
INSERT INTO `think_log` VALUES ('4423', '1', 'admin', '用户【admin】登录失败：密码错误', '111.203.168.4', '2', '1563759101');
INSERT INTO `think_log` VALUES ('4424', '1', 'admin', '用户【admin】登录成功', '111.203.168.4', '1', '1563759109');
INSERT INTO `think_log` VALUES ('4425', '1', 'admin', '用户【admin】添加菜单成功', '111.203.168.4', '1', '1563759229');
INSERT INTO `think_log` VALUES ('4426', '1', 'admin', '用户【admin】添加菜单成功', '111.203.168.4', '1', '1563759334');
INSERT INTO `think_log` VALUES ('4427', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1563759367');
INSERT INTO `think_log` VALUES ('4428', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1563759385');
INSERT INTO `think_log` VALUES ('4429', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1563759439');
INSERT INTO `think_log` VALUES ('4430', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1563759458');
INSERT INTO `think_log` VALUES ('4431', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1563759476');
INSERT INTO `think_log` VALUES ('4432', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1563759530');
INSERT INTO `think_log` VALUES ('4433', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1563759874');
INSERT INTO `think_log` VALUES ('4434', '1', 'admin', '用户【admin】添加菜单成功', '111.203.168.4', '1', '1563760144');
INSERT INTO `think_log` VALUES ('4435', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1563760193');
INSERT INTO `think_log` VALUES ('4436', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1563760293');
INSERT INTO `think_log` VALUES ('4437', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1563760333');
INSERT INTO `think_log` VALUES ('4438', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1563760409');
INSERT INTO `think_log` VALUES ('4439', '1', 'admin', '用户【admin】登录成功', '111.203.168.4', '1', '1563790963');
INSERT INTO `think_log` VALUES ('4440', '1', 'admin', '用户【admin】登录成功', '111.203.168.4', '1', '1563947282');
INSERT INTO `think_log` VALUES ('4441', '1', 'admin', '用户【admin】登录成功', '111.203.168.4', '1', '1564017665');
INSERT INTO `think_log` VALUES ('4442', '1', 'admin', '用户【admin】添加菜单成功', '111.203.168.4', '1', '1564018003');
INSERT INTO `think_log` VALUES ('4443', '1', 'admin', '用户【admin】添加菜单成功', '111.203.168.4', '1', '1564018364');
INSERT INTO `think_log` VALUES ('4444', '1', 'admin', '用户【admin】添加菜单成功', '111.203.168.4', '1', '1564018421');
INSERT INTO `think_log` VALUES ('4445', '1', 'admin', '用户【admin】登录成功', '111.203.168.4', '1', '1564026206');
INSERT INTO `think_log` VALUES ('4446', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1564054230');
INSERT INTO `think_log` VALUES ('4447', '1', 'admin', '用户【admin】添加菜单成功', '111.203.168.4', '1', '1564106195');
INSERT INTO `think_log` VALUES ('4448', '1', 'admin', '用户【admin】添加菜单成功', '111.203.168.4', '1', '1564106228');
INSERT INTO `think_log` VALUES ('4449', '1', 'admin', '用户【admin】登录成功', '111.203.168.4', '1', '1564133367');
INSERT INTO `think_log` VALUES ('4450', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1564134657');
INSERT INTO `think_log` VALUES ('4451', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1564134681');
INSERT INTO `think_log` VALUES ('4452', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1564134721');
INSERT INTO `think_log` VALUES ('4453', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1564204331');
INSERT INTO `think_log` VALUES ('4454', '1', 'admin', '用户【admin】添加菜单成功', '111.203.168.4', '1', '1564213698');
INSERT INTO `think_log` VALUES ('4455', '1', 'admin', '用户【admin】添加菜单成功', '111.203.168.4', '1', '1564213762');
INSERT INTO `think_log` VALUES ('4456', '1', 'admin', '用户【admin】添加菜单成功', '111.203.168.4', '1', '1564213793');
INSERT INTO `think_log` VALUES ('4457', '1', 'admin', '用户【admin】添加菜单成功', '111.203.168.4', '1', '1564213828');
INSERT INTO `think_log` VALUES ('4458', '1', 'admin', '用户【admin】添加菜单成功', '111.203.168.4', '1', '1564213845');
INSERT INTO `think_log` VALUES ('4459', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1564225678');
INSERT INTO `think_log` VALUES ('4460', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1564225701');
INSERT INTO `think_log` VALUES ('4461', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1564225717');
INSERT INTO `think_log` VALUES ('4462', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1564225747');
INSERT INTO `think_log` VALUES ('4463', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1564225760');
INSERT INTO `think_log` VALUES ('4464', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1564225782');
INSERT INTO `think_log` VALUES ('4465', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1564225800');
INSERT INTO `think_log` VALUES ('4466', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1564225819');
INSERT INTO `think_log` VALUES ('4467', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1564225834');
INSERT INTO `think_log` VALUES ('4468', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1564225848');
INSERT INTO `think_log` VALUES ('4469', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1564225859');
INSERT INTO `think_log` VALUES ('4470', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1564225886');
INSERT INTO `think_log` VALUES ('4471', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1564225918');
INSERT INTO `think_log` VALUES ('4472', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1564225930');
INSERT INTO `think_log` VALUES ('4473', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1564225943');
INSERT INTO `think_log` VALUES ('4474', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1564225956');
INSERT INTO `think_log` VALUES ('4475', '1', 'admin', '用户【admin】编辑菜单成功', '111.203.168.4', '1', '1564226081');
INSERT INTO `think_log` VALUES ('4476', '1', 'admin', '用户【admin】登录成功', '113.44.154.140', '1', '1564239538');
INSERT INTO `think_log` VALUES ('4477', '1', 'admin', '用户【admin】登录成功', '113.44.154.140', '1', '1564240312');
INSERT INTO `think_log` VALUES ('4478', '1', 'admin', '用户【admin】登录成功', '111.203.168.4', '1', '1564449277');
INSERT INTO `think_log` VALUES ('4479', '1', 'admin', '用户【admin】登录成功', '111.203.168.4', '1', '1564535852');
INSERT INTO `think_log` VALUES ('4480', '1', 'admin', '用户【admin】添加菜单成功', '111.203.168.4', '1', '1564566224');
INSERT INTO `think_log` VALUES ('4481', '1', 'admin', '用户【admin】删除菜单成功', '111.203.168.4', '1', '1564566258');
INSERT INTO `think_log` VALUES ('4482', '1', 'admin', '用户【admin】添加菜单成功', '111.203.168.4', '1', '1564566288');
INSERT INTO `think_log` VALUES ('4483', '1', 'admin', '用户【admin】添加菜单成功', '111.203.168.4', '1', '1564570388');
INSERT INTO `think_log` VALUES ('4484', '1', 'admin', '用户【admin】登录成功', '111.203.168.4', '1', '1564572504');
INSERT INTO `think_log` VALUES ('4485', '1', 'admin', '用户【admin】登录成功', '111.203.168.4', '1', '1564621812');
INSERT INTO `think_log` VALUES ('4486', '1', 'admin', '用户【admin】登录成功', '111.203.168.4', '1', '1564731707');
INSERT INTO `think_log` VALUES ('4487', '1', 'admin', '用户【admin】登录成功', '127.0.0.1', '1', '1564973469');

-- -----------------------------
-- Table structure for `think_marquee`
-- -----------------------------
DROP TABLE IF EXISTS `think_marquee`;
CREATE TABLE `think_marquee` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL COMMENT '跑马灯内容',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态（0：显示 1：不显示）',
  `cate` tinyint(1) DEFAULT '0' COMMENT '分类（0：置顶跑马灯 1：系统通知）',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='跑马灯';

-- -----------------------------
-- Records of `think_marquee`
-- -----------------------------
INSERT INTO `think_marquee` VALUES ('1', '请勿轻易相信其他人，提高自身警惕性。', '0', '0', '1563624313', '1563624313');

-- -----------------------------
-- Table structure for `think_member`
-- -----------------------------
DROP TABLE IF EXISTS `think_member`;
CREATE TABLE `think_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account` varchar(64) DEFAULT NULL COMMENT '邮件或者手机',
  `nickname` varchar(32) DEFAULT NULL COMMENT '昵称',
  `sex` int(10) DEFAULT NULL COMMENT '0未知 1男 2女',
  `password` char(32) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `head_img` varchar(128) DEFAULT NULL COMMENT '头像',
  `integral` int(11) DEFAULT '0' COMMENT '积分',
  `money` int(11) DEFAULT '0' COMMENT '账户余额',
  `mobile` varchar(11) DEFAULT NULL COMMENT '认证的手机号码',
  `create_time` int(255) DEFAULT '0' COMMENT '注册时间(计算登录多少天了)',
  `update_time` int(255) DEFAULT NULL COMMENT '最后一次登录',
  `login_num` varchar(15) DEFAULT NULL COMMENT '登录次数',
  `status` tinyint(1) DEFAULT NULL COMMENT '1正常  0 禁用',
  `closed` tinyint(1) DEFAULT '0' COMMENT '0正常，1删除',
  `token` char(32) DEFAULT '0' COMMENT '令牌',
  `session_id` varchar(20) DEFAULT NULL,
  `sign_status` int(1) DEFAULT '1' COMMENT '签到状态(0签到 1未签到）',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=212085 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_member`
-- -----------------------------
INSERT INTO `think_member` VALUES ('2', '1217037610', 'XiMi丶momo', '2', 'd41d8cd98f00b204e9800998ecf8427e', '1', '20161122\\ab9f9c492871857e1a6c5bc1c658ef7f.jpg', '300', '200', '18809321956', '1476779394', '1476779394', '0', '1', '1', '0', '', '');
INSERT INTO `think_member` VALUES ('1', '18809321929', '醉凡尘丶Wordly', '1', 'd41d8cd98f00b204e9800998ecf8427e', '1', '20161122\\admin.jpg', '92930', '73', '18809321929', '1476762875', '1476762875', '0', '1', '0', '0', '', '');
INSERT INTO `think_member` VALUES ('3', '1217037610', '紫陌轩尘', '1', 'd41d8cd98f00b204e9800998ecf8427e', '1', '20161122\\293c8cd05478b029a378ac4e5a880303.jpg', '400', '434', '49494', '1476676516', '1476676516', '0', '1', '1', '0', '', '');
INSERT INTO `think_member` VALUES ('4', '', 'fag', '1', 'd41d8cd98f00b204e9800998ecf8427e', '1', '20161122\\8a69f4c962e26265fd9f12efbff65013.jpg', '24', '424', '242', '1476425833', '1476425833', '0', '0', '1', '0', '', '');
INSERT INTO `think_member` VALUES ('5', '18809321928', '空谷幽兰', '2', 'd41d8cd98f00b204e9800998ecf8427e', '1', '20161122\\admin.jpg', '53', '3636', '3636', '1476676464', '1476676464', '0', '1', '0', '0', '', '');
INSERT INTO `think_member` VALUES ('6', '', '787367373', '1', 'd41d8cd98f00b204e9800998ecf8427e', '1', '20161122\\ab9f9c492871857e1a6c5bc1c658ef7f.jpg', '414', '9', '73737373', '1476425750', '1476425750', '0', '0', '1', '0', '', '');
INSERT INTO `think_member` VALUES ('7', '18809321929', 'XMi丶呵呵', '2', 'd41d8cd98f00b204e9800998ecf8427e', '1', '20161122\\293c8cd05478b029a378ac4e5a880303.jpg', '373373', '33', '73', '1476692255', '1476692255', '0', '0', '0', '0', '', '');
INSERT INTO `think_member` VALUES ('8', '1246470984', 'XY', '1', 'd41d8cd98f00b204e9800998ecf8427e', '1', '20161122\\8a69f4c962e26265fd9f12efbff65013.jpg', '7383', '73737373', '7373', '1476692123', '1476692123', '0', '1', '1', '0', '', '');
INSERT INTO `think_member` VALUES ('9', '18793189097', '25773', '1', 'd41d8cd98f00b204e9800998ecf8427e', '1', '20161122\\admin.jpg', '7373737', '77', '7373733', '1476433452', '1476433452', '0', '1', '1', '0', '', '');
INSERT INTO `think_member` VALUES ('10', '1246470984', 'XiYu', '2', 'e10adc3949ba59abbe56e057f20f883e', '1', '20161122\\ab9f9c492871857e1a6c5bc1c658ef7f.jpg', '100', '100', '18793189091', '1476694831', '1476694831', '0', '1', '1', '0', '', '');
INSERT INTO `think_member` VALUES ('11', '', '烟勤话少脾气好', '0', '', '1', '20161122\\293c8cd05478b029a378ac4e5a880303.jpg', '0', '0', '', '1488030906', '0', '0', '0', '0', '0', '', '');
INSERT INTO `think_member` VALUES ('12', '1246470984', 'XiYu', '2', 'e10adc3949ba59abbe56e057f20f883e', '1', '20161122\\8a69f4c962e26265fd9f12efbff65013.jpg', '100', '100', '18793189091', '1488030906', '1476694831', '0', '1', '1', '0', '', '');
INSERT INTO `think_member` VALUES ('212065', '111', '111', '0', 'deb2a3420354e40d55a1b0cb3a947cd0', '121', '<!doctype html>\n<html>\n<head>\n    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n    <title>跳转提示</title>\n', '0', '0', '', '1502341127', '1502341127', '', '', '0', '0', '', '');
INSERT INTO `think_member` VALUES ('22', '1234123', '', '', '', '', '', '8', '0', '', '1563334944', '', '', '', '0', '5e701bed3617e6b900ee5c6eca097a3e', '', '1');
INSERT INTO `think_member` VALUES ('212078', '', '问心', '', '', '', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLoxbuAWKx7BAly1v5ppvGmy0MK8wgD8QMpR13s9NMubw11ib8UwbmRsIfia2d1HQyfzfjlQ9lTibcsA/132', '0', '0', '', '1563345888', '', '', '', '0', '83e62b0ee6080de62886e887717711a6', '', '1');
INSERT INTO `think_member` VALUES ('13', '12312312', '问心', '', '', '', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLoxbuAWKx7BAly1v5ppvGmy0MK8wgD8QMpR13s9NMubw11ib8UwbmRsIfia2d1HQyfzfjlQ9lTibcsA/132', '4709', '0', '', '1563431925', '1564483037', '', '', '0', '416af5bbbf2b83b3b3d4857e4e506867', '', '1');
INSERT INTO `think_member` VALUES ('212066', 'dfgdf', 'sdfsdf', '', 'sdfsdf', '', '', '0', '0', '', '0', '', '', '', '0', '0', '', '1');
INSERT INTO `think_member` VALUES ('212067', 'sdf', 'sdf', '', 'sdf', '', '', '0', '0', '', '0', '', '', '', '0', '0', '', '1');
INSERT INTO `think_member` VALUES ('212082', '', '白孟冉', '', '', '', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTJa5Pr4M9OH9AXtJ5Z3gcWQdbjMCg1fg6la1UBic7ZwxtL6kliaw5ELLtkKzCQ1a6oSGGdCs44XecmA/132', '51', '0', '', '1564192068', '1564675104', '', '', '0', '196088cbf60cd7373278ed907dec6814', '', '1');
INSERT INTO `think_member` VALUES ('212083', '', '甲宝', '', '', '', 'https://wx.qlogo.cn/mmopen/vi_32/7GbTNZzjicab3hoU0DOwUk2k6EQHaPzggDlrb3hibRP55x450n4j1KXApWZMfTiaJK5icSomCicE3qQe2be4XmV6xQQ/132', '0', '0', '', '1564483301', '', '', '', '0', '9658db24be1c6cefff85634efe340386', '', '1');
INSERT INTO `think_member` VALUES ('212084', '', '知之者', '', '', '', 'https://wx.qlogo.cn/mmopen/vi_32/DYAIOgq83eoOHNrq0PeRVIaxw1mowNyO9DEZoQNLIqY6zh4TjAMAxqF9K5AWszL80kageibdZWDbOH4S2FrZgibg/132', '0', '0', '', '1564970805', '', '', '', '0', '8d0c0d8c56ba6d8f1c9191472959d81a', '', '1');

-- -----------------------------
-- Table structure for `think_member_cccc`
-- -----------------------------
DROP TABLE IF EXISTS `think_member_cccc`;
CREATE TABLE `think_member_cccc` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account` varchar(64) DEFAULT NULL COMMENT '邮件或者手机',
  `nickname` varchar(32) DEFAULT NULL COMMENT '昵称',
  `sex` int(10) DEFAULT NULL COMMENT '0未知 1男 2女',
  `password` char(32) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `head_img` varchar(128) DEFAULT NULL COMMENT '头像',
  `integral` int(11) DEFAULT '0' COMMENT '积分',
  `money` int(11) DEFAULT '0' COMMENT '账户余额',
  `mobile` varchar(11) DEFAULT NULL COMMENT '认证的手机号码',
  `create_time` int(255) DEFAULT '0' COMMENT '注册时间(计算登录多少天了)',
  `update_time` int(255) DEFAULT NULL COMMENT '最后一次登录',
  `login_num` varchar(15) DEFAULT NULL COMMENT '登录次数',
  `status` tinyint(1) DEFAULT NULL COMMENT '1正常  0 禁用',
  `closed` tinyint(1) DEFAULT '0' COMMENT '0正常，1删除',
  `token` char(32) DEFAULT '0' COMMENT '令牌',
  `session_id` varchar(20) DEFAULT NULL,
  `sign_status` int(1) DEFAULT '1' COMMENT '签到状态(0签到 1未签到）',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=212080 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_member_cccc`
-- -----------------------------
INSERT INTO `think_member_cccc` VALUES ('2', '1217037610', 'XiMi丶momo', '2', 'd41d8cd98f00b204e9800998ecf8427e', '1', '20161122\\ab9f9c492871857e1a6c5bc1c658ef7f.jpg', '300', '200', '18809321956', '1476779394', '1476779394', '0', '1', '1', '0', '', '');
INSERT INTO `think_member_cccc` VALUES ('1', '18809321929', '醉凡尘丶Wordly', '1', 'd41d8cd98f00b204e9800998ecf8427e', '1', '20161122\\admin.jpg', '92960', '73', '18809321929', '1476762875', '1476762875', '0', '1', '0', '0', '', '');
INSERT INTO `think_member_cccc` VALUES ('3', '1217037610', '紫陌轩尘', '1', 'd41d8cd98f00b204e9800998ecf8427e', '1', '20161122\\293c8cd05478b029a378ac4e5a880303.jpg', '400', '434', '49494', '1476676516', '1476676516', '0', '1', '1', '0', '', '');
INSERT INTO `think_member_cccc` VALUES ('4', '', 'fag', '1', 'd41d8cd98f00b204e9800998ecf8427e', '1', '20161122\\8a69f4c962e26265fd9f12efbff65013.jpg', '24', '424', '242', '1476425833', '1476425833', '0', '0', '1', '0', '', '');
INSERT INTO `think_member_cccc` VALUES ('5', '18809321928', '空谷幽兰', '2', 'd41d8cd98f00b204e9800998ecf8427e', '1', '20161122\\admin.jpg', '53', '3636', '3636', '1476676464', '1476676464', '0', '1', '0', '0', '', '');
INSERT INTO `think_member_cccc` VALUES ('6', '', '787367373', '1', 'd41d8cd98f00b204e9800998ecf8427e', '1', '20161122\\ab9f9c492871857e1a6c5bc1c658ef7f.jpg', '414', '9', '73737373', '1476425750', '1476425750', '0', '0', '1', '0', '', '');
INSERT INTO `think_member_cccc` VALUES ('7', '18809321929', 'XMi丶呵呵', '2', 'd41d8cd98f00b204e9800998ecf8427e', '1', '20161122\\293c8cd05478b029a378ac4e5a880303.jpg', '373373', '33', '73', '1476692255', '1476692255', '0', '0', '0', '0', '', '');
INSERT INTO `think_member_cccc` VALUES ('8', '1246470984', 'XY', '1', 'd41d8cd98f00b204e9800998ecf8427e', '1', '20161122\\8a69f4c962e26265fd9f12efbff65013.jpg', '7383', '73737373', '7373', '1476692123', '1476692123', '0', '1', '1', '0', '', '');
INSERT INTO `think_member_cccc` VALUES ('9', '18793189097', '25773', '1', 'd41d8cd98f00b204e9800998ecf8427e', '1', '20161122\\admin.jpg', '7373737', '77', '7373733', '1476433452', '1476433452', '0', '1', '1', '0', '', '');
INSERT INTO `think_member_cccc` VALUES ('10', '1246470984', 'XiYu', '2', 'e10adc3949ba59abbe56e057f20f883e', '1', '20161122\\ab9f9c492871857e1a6c5bc1c658ef7f.jpg', '100', '100', '18793189091', '1476694831', '1476694831', '0', '1', '1', '0', '', '');
INSERT INTO `think_member_cccc` VALUES ('11', '', '烟勤话少脾气好', '0', '', '1', '20161122\\293c8cd05478b029a378ac4e5a880303.jpg', '0', '0', '', '1488030906', '0', '0', '0', '0', '0', '', '');
INSERT INTO `think_member_cccc` VALUES ('12', '1246470984', 'XiYu', '2', 'e10adc3949ba59abbe56e057f20f883e', '1', '20161122\\8a69f4c962e26265fd9f12efbff65013.jpg', '100', '100', '18793189091', '1488030906', '1476694831', '0', '1', '1', '0', '', '');
INSERT INTO `think_member_cccc` VALUES ('212065', '111', '111', '0', 'deb2a3420354e40d55a1b0cb3a947cd0', '121', '<!doctype html>\n<html>\n<head>\n    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n    <title>跳转提示</title>\n', '0', '0', '', '1502341127', '1502341127', '', '', '0', '0', '', '');
INSERT INTO `think_member_cccc` VALUES ('22', '', '', '', '', '', '', '8', '0', '', '1563334944', '', '', '', '0', '5e701bed3617e6b900ee5c6eca097a3e', '', '1');
INSERT INTO `think_member_cccc` VALUES ('212078', '', '问心', '', '', '', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLoxbuAWKx7BAly1v5ppvGmy0MK8wgD8QMpR13s9NMubw11ib8UwbmRsIfia2d1HQyfzfjlQ9lTibcsA/132', '0', '0', '', '1563345888', '', '', '', '0', '83e62b0ee6080de62886e887717711a6', '', '1');
INSERT INTO `think_member_cccc` VALUES ('212079', '', '问心', '', '', '', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLoxbuAWKx7BAly1v5ppvGmy0MK8wgD8QMpR13s9NMubw11ib8UwbmRsIfia2d1HQyfzfjlQ9lTibcsA/132', '0', '0', '', '1563431789', '', '', '', '0', '416af5bbbf2b83b3b3d4857e4e506867', '', '1');

-- -----------------------------
-- Table structure for `think_member_collect`
-- -----------------------------
DROP TABLE IF EXISTS `think_member_collect`;
CREATE TABLE `think_member_collect` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL COMMENT '用户ID',
  `module_id` int(11) unsigned NOT NULL COMMENT '二手商品、房屋出租、招聘、社区主键ID',
  `module_type` varchar(50) NOT NULL COMMENT '1:二手商品 2:房屋出租 3:招聘 4:社区',
  `delete_time` int(11) DEFAULT NULL COMMENT '软删除',
  `create_time` int(11) unsigned NOT NULL,
  `update_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COMMENT='收藏';

-- -----------------------------
-- Records of `think_member_collect`
-- -----------------------------
INSERT INTO `think_member_collect` VALUES ('1', '13', '1', 'community_model', '1564036539', '1563964034', '1563964034');
INSERT INTO `think_member_collect` VALUES ('2', '13', '1', 'used_product_model', '', '1564036329', '1564036329');
INSERT INTO `think_member_collect` VALUES ('3', '13', '1', 'rent_house_model', '', '1564036533', '1564036533');
INSERT INTO `think_member_collect` VALUES ('4', '13', '1', 'job_seek_model', '', '1564036536', '1564036536');
INSERT INTO `think_member_collect` VALUES ('5', '13', '1', 'dining_list_model', '', '1564036543', '1564036543');
INSERT INTO `think_member_collect` VALUES ('6', '13', '1', 'hotel_list_model', '1564484518', '1564036547', '1564036547');
INSERT INTO `think_member_collect` VALUES ('7', '13', '1', 'taxi_list_model', '', '1564036550', '1564036550');
INSERT INTO `think_member_collect` VALUES ('8', '13', '2', 'rent_house_model', '', '1564037610', '1564037610');
INSERT INTO `think_member_collect` VALUES ('9', '13', '2', 'job_seek_model', '', '1564037613', '1564037613');
INSERT INTO `think_member_collect` VALUES ('10', '13', '2', 'community_model', '', '1564037616', '1564037616');
INSERT INTO `think_member_collect` VALUES ('11', '13', '2', 'dining_list_model', '1564485146', '1564037618', '1564037618');
INSERT INTO `think_member_collect` VALUES ('12', '13', '2', 'hotel_list_model', '', '1564037621', '1564037621');
INSERT INTO `think_member_collect` VALUES ('13', '13', '2', 'taxi_list_model', '1564047798', '1564037624', '1564037624');
INSERT INTO `think_member_collect` VALUES ('14', '13', '12', 'rent_house_model', '', '1564047329', '1564047329');
INSERT INTO `think_member_collect` VALUES ('15', '13', '10', 'rent_house_model', '1564118202', '1564047339', '1564047339');
INSERT INTO `think_member_collect` VALUES ('16', '13', '5', 'used_product_model', '', '1564047923', '1564047923');
INSERT INTO `think_member_collect` VALUES ('17', '13', '5', 'taxi_list_model', '', '1564048057', '1564048057');
INSERT INTO `think_member_collect` VALUES ('18', '13', '7', 'used_product_model', '', '1564058088', '1564058088');
INSERT INTO `think_member_collect` VALUES ('19', '13', '3', 'taxi_list_model', '1564102975', '1564102920', '1564102920');
INSERT INTO `think_member_collect` VALUES ('20', '13', '2', 'used_product_model', '', '1564106301', '1564106301');
INSERT INTO `think_member_collect` VALUES ('21', '212082', '13', 'community_model', '', '1564204122', '1564204122');
INSERT INTO `think_member_collect` VALUES ('22', '212082', '6', 'community_model', '', '1564204169', '1564204169');
INSERT INTO `think_member_collect` VALUES ('23', '212082', '4', 'taxi_list_model', '1564482190', '1564244538', '1564244538');
INSERT INTO `think_member_collect` VALUES ('24', '212082', '8', 'taxi_list_model', '1564482551', '1564467891', '1564467891');
INSERT INTO `think_member_collect` VALUES ('25', '212082', '1', 'taxi_list_model', '', '1564540000', '1564540000');
INSERT INTO `think_member_collect` VALUES ('26', '212082', '2', 'taxi_list_model', '', '1564540052', '1564540052');
INSERT INTO `think_member_collect` VALUES ('27', '212082', '1', 'dining_list_model', '', '1564540059', '1564540059');
INSERT INTO `think_member_collect` VALUES ('28', '212082', '2', 'dining_list_model', '', '1564540066', '1564540066');
INSERT INTO `think_member_collect` VALUES ('29', '212082', '1', 'hotel_list_model', '', '1564540072', '1564540072');
INSERT INTO `think_member_collect` VALUES ('30', '212082', '2', 'hotel_list_model', '', '1564540076', '1564540076');

-- -----------------------------
-- Table structure for `think_member_group`
-- -----------------------------
DROP TABLE IF EXISTS `think_member_group`;
CREATE TABLE `think_member_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '留言Id',
  `group_name` varchar(32) NOT NULL COMMENT '留言评论作者',
  `status` tinyint(1) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL COMMENT '留言回复时间',
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=122 DEFAULT CHARSET=utf8 COMMENT='文章评论表';

-- -----------------------------
-- Records of `think_member_group`
-- -----------------------------
INSERT INTO `think_member_group` VALUES ('1', '系统组', '0', '1441616559', '1502341098');
INSERT INTO `think_member_group` VALUES ('2', '游客组', '1', '1441617195', '1502281865');
INSERT INTO `think_member_group` VALUES ('3', 'VIP', '1', '1441769224', '');

-- -----------------------------
-- Table structure for `think_member_praise`
-- -----------------------------
DROP TABLE IF EXISTS `think_member_praise`;
CREATE TABLE `think_member_praise` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL COMMENT '用户ID',
  `module_id` int(11) unsigned NOT NULL COMMENT '二手商品、房屋出租、招聘、社区主键ID',
  `module_type` varchar(50) NOT NULL COMMENT '1:二手商品 2:房屋出租 3:招聘 4:社区',
  `delete_time` int(11) DEFAULT NULL COMMENT '软删除',
  `create_time` int(10) unsigned NOT NULL,
  `update_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8 COMMENT='点赞表';

-- -----------------------------
-- Records of `think_member_praise`
-- -----------------------------
INSERT INTO `think_member_praise` VALUES ('23', '1', '3', 'community', '1563173035', '1563172998', '1563172998');
INSERT INTO `think_member_praise` VALUES ('26', '13', '50', 'used_product', '', '1563203242', '1563203242');
INSERT INTO `think_member_praise` VALUES ('27', '13', '1', 'job_seek', '1563603902', '1563266114', '1563266114');
INSERT INTO `think_member_praise` VALUES ('28', '13', '10', 'rent_house', '1563589338', '1563267515', '1563267515');
INSERT INTO `think_member_praise` VALUES ('29', '13', '5', 'used_product', '', '1563414807', '1563414807');
INSERT INTO `think_member_praise` VALUES ('30', '13', '1', 'community', '', '1563435883', '1563435883');
INSERT INTO `think_member_praise` VALUES ('31', '13', '3', 'community', '1563684136', '1563600476', '1563600476');
INSERT INTO `think_member_praise` VALUES ('32', '13', '1', 'used_product', '1564106803', '1563601686', '1563601686');
INSERT INTO `think_member_praise` VALUES ('33', '13', '3', 'rent_house', '', '1563602832', '1563602832');
INSERT INTO `think_member_praise` VALUES ('34', '13', '1', 'rent_house', '', '1563603030', '1563603030');
INSERT INTO `think_member_praise` VALUES ('35', '13', '2', 'job_seek', '', '1563604049', '1563604049');
INSERT INTO `think_member_praise` VALUES ('36', '13', '6', 'community', '', '1563627598', '1563627598');
INSERT INTO `think_member_praise` VALUES ('37', '13', '22', 'job_seek', '1564038158', '1563629485', '1563629485');
INSERT INTO `think_member_praise` VALUES ('38', '13', '10', 'community', '', '1563638024', '1563638024');
INSERT INTO `think_member_praise` VALUES ('39', '13', '11', 'community', '', '1563640088', '1563640088');
INSERT INTO `think_member_praise` VALUES ('40', '13', '2', 'community', '1563685818', '1563685814', '1563685814');
INSERT INTO `think_member_praise` VALUES ('41', '13', '5', 'rent_house', '', '1563688463', '1563688463');
INSERT INTO `think_member_praise` VALUES ('42', '13', '9', 'community', '', '1563714879', '1563714879');
INSERT INTO `think_member_praise` VALUES ('43', '212082', '13', 'community', '', '1564204116', '1564204116');
INSERT INTO `think_member_praise` VALUES ('44', '13', '18', 'community', '', '1564485274', '1564485274');

-- -----------------------------
-- Table structure for `think_order`
-- -----------------------------
DROP TABLE IF EXISTS `think_order`;
CREATE TABLE `think_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `no` varchar(255) NOT NULL DEFAULT 'null' COMMENT '订单号',
  `user_id` int(11) NOT NULL COMMENT '用户id',
  `integral_id` int(11) NOT NULL COMMENT '积分id',
  `total_amount` decimal(10,2) NOT NULL COMMENT '金额',
  `remark` text COMMENT '订单备注',
  `paid_at` int(11) NOT NULL DEFAULT '0' COMMENT '支付时间',
  `payment_method` varchar(50) DEFAULT NULL COMMENT '支付方式',
  `payment_no` varchar(255) NOT NULL DEFAULT 'null' COMMENT '支付订单号',
  `refund_status` varchar(255) DEFAULT NULL COMMENT '退款状态',
  `refund_no` varchar(255) DEFAULT NULL COMMENT '退款订单号',
  `closed` tinyint(1) NOT NULL DEFAULT '0' COMMENT '订单是否关闭（0：没关闭 1：关闭）',
  `extra` text COMMENT '其他额外数据',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_order`
-- -----------------------------
INSERT INTO `think_order` VALUES ('1', 'null', '212082', '1', '10.00', '', '0', '', 'null', '', '', '0', '', '1564549637', '1564549637');
INSERT INTO `think_order` VALUES ('2', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564556383', '1564556383');
INSERT INTO `think_order` VALUES ('3', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564556440', '1564556440');
INSERT INTO `think_order` VALUES ('4', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564556486', '1564556486');
INSERT INTO `think_order` VALUES ('5', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564556581', '1564556581');
INSERT INTO `think_order` VALUES ('6', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564556597', '1564556597');
INSERT INTO `think_order` VALUES ('7', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564556758', '1564556758');
INSERT INTO `think_order` VALUES ('8', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564556808', '1564556808');
INSERT INTO `think_order` VALUES ('9', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564556819', '1564556819');
INSERT INTO `think_order` VALUES ('10', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564556849', '1564556849');
INSERT INTO `think_order` VALUES ('11', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564557002', '1564557002');
INSERT INTO `think_order` VALUES ('12', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564557083', '1564557083');
INSERT INTO `think_order` VALUES ('13', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564557243', '1564557243');
INSERT INTO `think_order` VALUES ('14', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564557498', '1564557498');
INSERT INTO `think_order` VALUES ('15', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564557506', '1564557506');
INSERT INTO `think_order` VALUES ('16', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564557516', '1564557516');
INSERT INTO `think_order` VALUES ('17', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564557561', '1564557561');
INSERT INTO `think_order` VALUES ('18', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564557671', '1564557671');
INSERT INTO `think_order` VALUES ('19', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564557711', '1564557711');
INSERT INTO `think_order` VALUES ('20', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564557746', '1564557746');
INSERT INTO `think_order` VALUES ('21', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564557796', '1564557796');
INSERT INTO `think_order` VALUES ('22', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564557895', '1564557895');
INSERT INTO `think_order` VALUES ('23', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564557953', '1564557953');
INSERT INTO `think_order` VALUES ('24', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564557993', '1564557993');
INSERT INTO `think_order` VALUES ('25', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564558005', '1564558005');
INSERT INTO `think_order` VALUES ('26', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564558051', '1564558051');
INSERT INTO `think_order` VALUES ('27', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564558078', '1564558078');
INSERT INTO `think_order` VALUES ('28', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564558121', '1564558121');
INSERT INTO `think_order` VALUES ('29', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564558345', '1564558345');
INSERT INTO `think_order` VALUES ('30', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564558387', '1564558387');
INSERT INTO `think_order` VALUES ('31', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564558795', '1564558795');
INSERT INTO `think_order` VALUES ('32', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564558992', '1564558992');
INSERT INTO `think_order` VALUES ('33', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564559011', '1564559011');
INSERT INTO `think_order` VALUES ('34', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564560089', '1564560089');
INSERT INTO `think_order` VALUES ('35', 'null', '212082', '1', '10.00', '支付10人民币购买100积分', '0', '', 'null', '', '', '0', '', '1564560116', '1564560116');

-- -----------------------------
-- Table structure for `think_profession_cate`
-- -----------------------------
DROP TABLE IF EXISTS `think_profession_cate`;
CREATE TABLE `think_profession_cate` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '行业类别名称',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '显示状态(0:显示 1:不显示)',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='行业分类';

-- -----------------------------
-- Records of `think_profession_cate`
-- -----------------------------
INSERT INTO `think_profession_cate` VALUES ('1', '日餐', '0', '1563073476', '1563073476');
INSERT INTO `think_profession_cate` VALUES ('2', '中餐', '0', '1563073476', '1563073476');
INSERT INTO `think_profession_cate` VALUES ('3', '铁板', '0', '1563073476', '1563073476');
INSERT INTO `think_profession_cate` VALUES ('4', '台企', '0', '1563073476', '1563073476');
INSERT INTO `think_profession_cate` VALUES ('5', '其他', '0', '1563073476', '1563073476');

-- -----------------------------
-- Table structure for `think_region_list`
-- -----------------------------
DROP TABLE IF EXISTS `think_region_list`;
CREATE TABLE `think_region_list` (
  `region_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '区域表ID',
  `region_name` varchar(255) DEFAULT NULL COMMENT '区域名称',
  `region_status` int(1) DEFAULT NULL COMMENT '删除状态(0真删除，1假删除)',
  `delete_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`region_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_region_list`
-- -----------------------------
INSERT INTO `think_region_list` VALUES ('1', '海淀', '0', '');
INSERT INTO `think_region_list` VALUES ('2', '东城', '0', '');
INSERT INTO `think_region_list` VALUES ('3', '昌平', '1', '');
INSERT INTO `think_region_list` VALUES ('4', '朝阳', '1', '');
INSERT INTO `think_region_list` VALUES ('5', '西城', '1', '');

-- -----------------------------
-- Table structure for `think_rent_comment`
-- -----------------------------
DROP TABLE IF EXISTS `think_rent_comment`;
CREATE TABLE `think_rent_comment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rent_id` int(11) unsigned NOT NULL COMMENT '房屋ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '用户ID',
  `body` text NOT NULL COMMENT '评论内容',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '审核状态(0:以审核 1:未审核 2:审核未通过)',
  `create_time` int(11) unsigned NOT NULL,
  `update_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COMMENT='房屋出租评论';

-- -----------------------------
-- Records of `think_rent_comment`
-- -----------------------------
INSERT INTO `think_rent_comment` VALUES ('1', '1', '13', '房屋出租评论测试', '1', '1563615974', '1563615974');
INSERT INTO `think_rent_comment` VALUES ('2', '1', '13', '房屋出租评论测试', '1', '1563615983', '1563615983');
INSERT INTO `think_rent_comment` VALUES ('3', '1', '13', '房屋出租评论测试', '1', '1563615984', '1563615984');
INSERT INTO `think_rent_comment` VALUES ('4', '2', '13', '房屋出租评论测试', '1', '1563615987', '1563615987');
INSERT INTO `think_rent_comment` VALUES ('5', '2', '13', '房屋出租评论测试', '1', '1563615988', '1563615988');
INSERT INTO `think_rent_comment` VALUES ('6', '2', '13', '房屋出租评论测试', '1', '1563615989', '1563615989');
INSERT INTO `think_rent_comment` VALUES ('7', '3', '13', '房屋出租评论测试', '1', '1563615992', '1563615992');
INSERT INTO `think_rent_comment` VALUES ('8', '3', '13', '房屋出租评论测试', '1', '1563615992', '1563615992');
INSERT INTO `think_rent_comment` VALUES ('9', '3', '13', '房屋出租评论测试', '1', '1563615994', '1563615994');
INSERT INTO `think_rent_comment` VALUES ('10', '4', '13', '房屋出租评论测试', '1', '1563615997', '1563615997');
INSERT INTO `think_rent_comment` VALUES ('11', '4', '13', '房屋出租评论测试', '1', '1563615997', '1563615997');
INSERT INTO `think_rent_comment` VALUES ('12', '4', '13', '房屋出租评论测试', '1', '1563615998', '1563615998');
INSERT INTO `think_rent_comment` VALUES ('13', '5', '13', '房屋出租评论测试', '1', '1563616001', '1563616001');
INSERT INTO `think_rent_comment` VALUES ('14', '5', '13', '房屋出租评论测试', '1', '1563616003', '1563616003');
INSERT INTO `think_rent_comment` VALUES ('15', '5', '13', '房屋出租评论测试', '1', '1563616004', '1563616004');
INSERT INTO `think_rent_comment` VALUES ('16', '5', '13', '房屋出租评论测试', '1', '1563627694', '1563627694');
INSERT INTO `think_rent_comment` VALUES ('17', '5', '13', '房屋出租评论测试', '1', '1563638872', '1563638872');

-- -----------------------------
-- Table structure for `think_rent_comment_image`
-- -----------------------------
DROP TABLE IF EXISTS `think_rent_comment_image`;
CREATE TABLE `think_rent_comment_image` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` int(11) unsigned NOT NULL COMMENT '评论ID',
  `path` varchar(255) DEFAULT NULL COMMENT '评论图片路径',
  `create_time` int(10) unsigned NOT NULL,
  `update_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COMMENT='房屋出租评论图片';

-- -----------------------------
-- Records of `think_rent_comment_image`
-- -----------------------------
INSERT INTO `think_rent_comment_image` VALUES ('1', '1', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615974', '1563615974');
INSERT INTO `think_rent_comment_image` VALUES ('2', '1', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615974', '1563615974');
INSERT INTO `think_rent_comment_image` VALUES ('3', '2', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615983', '1563615983');
INSERT INTO `think_rent_comment_image` VALUES ('4', '2', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615983', '1563615983');
INSERT INTO `think_rent_comment_image` VALUES ('5', '3', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615984', '1563615984');
INSERT INTO `think_rent_comment_image` VALUES ('6', '3', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615984', '1563615984');
INSERT INTO `think_rent_comment_image` VALUES ('7', '4', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615987', '1563615987');
INSERT INTO `think_rent_comment_image` VALUES ('8', '4', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615987', '1563615987');
INSERT INTO `think_rent_comment_image` VALUES ('9', '5', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615988', '1563615988');
INSERT INTO `think_rent_comment_image` VALUES ('10', '5', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615988', '1563615988');
INSERT INTO `think_rent_comment_image` VALUES ('11', '6', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615989', '1563615989');
INSERT INTO `think_rent_comment_image` VALUES ('12', '6', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615989', '1563615989');
INSERT INTO `think_rent_comment_image` VALUES ('13', '7', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615992', '1563615992');
INSERT INTO `think_rent_comment_image` VALUES ('14', '7', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615992', '1563615992');
INSERT INTO `think_rent_comment_image` VALUES ('15', '8', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615992', '1563615992');
INSERT INTO `think_rent_comment_image` VALUES ('16', '8', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615992', '1563615992');
INSERT INTO `think_rent_comment_image` VALUES ('17', '9', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615994', '1563615994');
INSERT INTO `think_rent_comment_image` VALUES ('18', '9', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615994', '1563615994');
INSERT INTO `think_rent_comment_image` VALUES ('19', '10', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615997', '1563615997');
INSERT INTO `think_rent_comment_image` VALUES ('20', '10', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615997', '1563615997');
INSERT INTO `think_rent_comment_image` VALUES ('21', '11', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615997', '1563615997');
INSERT INTO `think_rent_comment_image` VALUES ('22', '11', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615997', '1563615997');
INSERT INTO `think_rent_comment_image` VALUES ('23', '12', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615998', '1563615998');
INSERT INTO `think_rent_comment_image` VALUES ('24', '12', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615999', '1563615999');
INSERT INTO `think_rent_comment_image` VALUES ('25', '13', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563616001', '1563616001');
INSERT INTO `think_rent_comment_image` VALUES ('26', '13', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563616001', '1563616001');
INSERT INTO `think_rent_comment_image` VALUES ('27', '14', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563616003', '1563616003');
INSERT INTO `think_rent_comment_image` VALUES ('28', '14', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563616003', '1563616003');
INSERT INTO `think_rent_comment_image` VALUES ('29', '15', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563616004', '1563616004');
INSERT INTO `think_rent_comment_image` VALUES ('30', '15', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563616004', '1563616004');
INSERT INTO `think_rent_comment_image` VALUES ('31', '16', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563627694', '1563627694');
INSERT INTO `think_rent_comment_image` VALUES ('32', '16', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563627694', '1563627694');
INSERT INTO `think_rent_comment_image` VALUES ('33', '17', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563638872', '1563638872');
INSERT INTO `think_rent_comment_image` VALUES ('34', '17', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563638872', '1563638872');

-- -----------------------------
-- Table structure for `think_rent_house`
-- -----------------------------
DROP TABLE IF EXISTS `think_rent_house`;
CREATE TABLE `think_rent_house` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL COMMENT '用户ID',
  `region_id` int(11) unsigned NOT NULL COMMENT '区域id',
  `body` text NOT NULL COMMENT '房屋描述',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '房屋出租价格',
  `sticky_create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '置顶开始时间',
  `sticky_end_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '置顶结束时间',
  `sticky_status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '置顶状态(0:置顶1:不置顶)',
  `phone` varchar(50) NOT NULL COMMENT '电话',
  `praise` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '点赞数量',
  `browse` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '浏览量',
  `review` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '评论数量',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '发布状态(0:以审核,1:未审核2:审核未通过)',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建日期',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '修改日期',
  `collect` int(11) NOT NULL DEFAULT '0' COMMENT '收藏数量',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='房屋出租';

-- -----------------------------
-- Records of `think_rent_house`
-- -----------------------------
INSERT INTO `think_rent_house` VALUES ('1', '13', '1', '房屋出租测试', '3880.00', '1563615914', '1563875114', '1', '1321654654', '1', '1', '3', '1', '1563615914', '1564118776', '1');
INSERT INTO `think_rent_house` VALUES ('2', '13', '1', '房屋出租测试', '3880.00', '1563615926', '1563875126', '1', '1321654654', '0', '0', '3', '1', '1563615926', '1564037610', '1');
INSERT INTO `think_rent_house` VALUES ('3', '13', '1', '房屋出租测试', '3880.00', '1563615927', '1563875127', '1', '1321654654', '0', '2', '3', '1', '1563615927', '1563961985', '0');
INSERT INTO `think_rent_house` VALUES ('4', '13', '2', '房屋出租测试', '3880.00', '1563615931', '1563875131', '1', '1321654654', '0', '0', '3', '1', '1563615931', '1563961985', '0');
INSERT INTO `think_rent_house` VALUES ('5', '13', '2', '房屋出租测试', '3880.00', '1563615932', '1563875132', '1', '1321654654', '1', '0', '5', '1', '1563615932', '1564106811', '0');
INSERT INTO `think_rent_house` VALUES ('6', '13', '2', '房屋出租测试', '3880.00', '1563615933', '1563875133', '1', '1321654654', '0', '0', '0', '1', '1563615933', '1563961985', '0');
INSERT INTO `think_rent_house` VALUES ('7', '13', '1', '11111', '1111.00', '1563623299', '1563709699', '1', '1111', '0', '0', '0', '1', '1563623299', '1563722626', '0');
INSERT INTO `think_rent_house` VALUES ('8', '13', '1', '1111111', '1231.00', '1563623622', '1563710022', '1', '12312312', '0', '0', '0', '1', '1563623622', '1563722626', '0');
INSERT INTO `think_rent_house` VALUES ('9', '13', '1', '房屋出租测试', '3880.00', '0', '0', '1', '1321654654', '0', '0', '0', '1', '1563627353', '1563627353', '0');
INSERT INTO `think_rent_house` VALUES ('10', '13', '1', '房屋出租测试', '3880.00', '0', '0', '1', '1321654654', '0', '0', '0', '1', '1563638330', '1564118202', '0');
INSERT INTO `think_rent_house` VALUES ('11', '13', '1', '房屋出租测试', '3880.00', '0', '0', '1', '1321654654', '0', '0', '0', '1', '1563638839', '1563638839', '0');
INSERT INTO `think_rent_house` VALUES ('12', '13', '1', '房屋出租测试', '3880.00', '1563623622', '1563964059', '1', '1321654654', '0', '0', '0', '1', '1563677659', '1564047329', '1');
INSERT INTO `think_rent_house` VALUES ('13', '212082', '2', '房屋发布测试', '500.00', '0', '0', '1', '13264978513', '0', '0', '0', '1', '1564206323', '1564206323', '0');
INSERT INTO `think_rent_house` VALUES ('14', '212082', '1', '发布房屋出租测试', '5000.00', '0', '0', '1', '13456798165', '0', '0', '0', '1', '1564206384', '1564206384', '0');
INSERT INTO `think_rent_house` VALUES ('15', '13', '1', '12312312312312', '23123123.00', '0', '0', '1', '123121', '0', '0', '0', '1', '1564449696', '1564449696', '0');

-- -----------------------------
-- Table structure for `think_rent_image`
-- -----------------------------
DROP TABLE IF EXISTS `think_rent_image`;
CREATE TABLE `think_rent_image` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rent_id` int(11) NOT NULL COMMENT '房屋ID',
  `path` varchar(255) DEFAULT NULL COMMENT '房屋图片路径',
  `create_time` int(11) DEFAULT '0',
  `update_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8 COMMENT='房屋出租图片';

-- -----------------------------
-- Records of `think_rent_image`
-- -----------------------------
INSERT INTO `think_rent_image` VALUES ('1', '1', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615914', '1563615914');
INSERT INTO `think_rent_image` VALUES ('2', '1', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615914', '1563615914');
INSERT INTO `think_rent_image` VALUES ('3', '1', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615914', '1563615914');
INSERT INTO `think_rent_image` VALUES ('4', '2', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615926', '1563615926');
INSERT INTO `think_rent_image` VALUES ('5', '2', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615926', '1563615926');
INSERT INTO `think_rent_image` VALUES ('6', '2', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615926', '1563615926');
INSERT INTO `think_rent_image` VALUES ('7', '3', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615927', '1563615927');
INSERT INTO `think_rent_image` VALUES ('8', '3', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615927', '1563615927');
INSERT INTO `think_rent_image` VALUES ('9', '3', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615927', '1563615927');
INSERT INTO `think_rent_image` VALUES ('10', '4', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615931', '1563615931');
INSERT INTO `think_rent_image` VALUES ('11', '4', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615931', '1563615931');
INSERT INTO `think_rent_image` VALUES ('12', '4', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615931', '1563615931');
INSERT INTO `think_rent_image` VALUES ('13', '5', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615932', '1563615932');
INSERT INTO `think_rent_image` VALUES ('14', '5', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615932', '1563615932');
INSERT INTO `think_rent_image` VALUES ('15', '5', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615932', '1563615932');
INSERT INTO `think_rent_image` VALUES ('16', '6', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615933', '1563615933');
INSERT INTO `think_rent_image` VALUES ('17', '6', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615933', '1563615933');
INSERT INTO `think_rent_image` VALUES ('18', '6', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563615933', '1563615933');
INSERT INTO `think_rent_image` VALUES ('19', '7', '', '1563623299', '1563623299');
INSERT INTO `think_rent_image` VALUES ('20', '8', '', '1563623622', '1563623622');
INSERT INTO `think_rent_image` VALUES ('21', '9', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563627353', '1563627353');
INSERT INTO `think_rent_image` VALUES ('22', '9', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563627353', '1563627353');
INSERT INTO `think_rent_image` VALUES ('23', '9', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563627353', '1563627353');
INSERT INTO `think_rent_image` VALUES ('24', '10', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563638330', '1563638330');
INSERT INTO `think_rent_image` VALUES ('25', '10', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563638330', '1563638330');
INSERT INTO `think_rent_image` VALUES ('26', '10', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563638330', '1563638330');
INSERT INTO `think_rent_image` VALUES ('27', '11', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563638839', '1563638839');
INSERT INTO `think_rent_image` VALUES ('28', '11', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563638839', '1563638839');
INSERT INTO `think_rent_image` VALUES ('29', '11', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563638839', '1563638839');
INSERT INTO `think_rent_image` VALUES ('30', '12', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563677659', '1563677659');
INSERT INTO `think_rent_image` VALUES ('31', '12', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563677659', '1563677659');
INSERT INTO `think_rent_image` VALUES ('32', '12', '\\/public\\/uploads\\/issue\\/20190720\\/1f8bf2788ce760af3f30a27e54dc2a9b.jpg', '1563677659', '1563677659');
INSERT INTO `think_rent_image` VALUES ('33', '13', '', '1564206323', '1564206323');
INSERT INTO `think_rent_image` VALUES ('34', '14', '/public/uploads/issue/20190727/51a271ed04ef8e8a47146c1d89d13814.jpg', '1564206384', '1564206384');
INSERT INTO `think_rent_image` VALUES ('35', '14', '/public/uploads/issue/20190727/1197de5bf838cc6c225fb03cfffb9d09.jpg', '1564206384', '1564206384');
INSERT INTO `think_rent_image` VALUES ('36', '14', '/public/uploads/issue/20190727/d6179caed52e2cf75f8954ce682b6e81.jpg', '1564206384', '1564206384');
INSERT INTO `think_rent_image` VALUES ('37', '14', '/public/uploads/issue/20190727/6037b6955e0df65ffaf424673c287cc3.jpg', '1564206384', '1564206384');
INSERT INTO `think_rent_image` VALUES ('38', '14', '/public/uploads/issue/20190727/e029bdcf25aef4e6aebd3df407e1baae.jpg', '1564206384', '1564206384');
INSERT INTO `think_rent_image` VALUES ('39', '14', '/public/uploads/issue/20190727/7c35fbc83ce47f1a5be341c258fbb500.jpg', '1564206384', '1564206384');
INSERT INTO `think_rent_image` VALUES ('40', '14', '/public/uploads/issue/20190727/1a5d5015ba103ef1e1c8e69a4c67ab0a.jpg', '1564206384', '1564206384');
INSERT INTO `think_rent_image` VALUES ('41', '15', '', '1564449696', '1564449696');

-- -----------------------------
-- Table structure for `think_sticky`
-- -----------------------------
DROP TABLE IF EXISTS `think_sticky`;
CREATE TABLE `think_sticky` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `day_num` int(11) unsigned NOT NULL COMMENT '置顶天数',
  `integral` int(11) unsigned NOT NULL COMMENT '所需积分',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否显示（0：显示 1：不显示）',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_sticky`
-- -----------------------------
INSERT INTO `think_sticky` VALUES ('1', '1', '15', '0', '1563612026', '1563612026');
INSERT INTO `think_sticky` VALUES ('2', '3', '30', '0', '1563612026', '1563612026');
INSERT INTO `think_sticky` VALUES ('3', '5', '40', '0', '1563612026', '1563612026');
INSERT INTO `think_sticky` VALUES ('4', '7', '50', '0', '1563612026', '1563612026');

-- -----------------------------
-- Table structure for `think_taxi_img`
-- -----------------------------
DROP TABLE IF EXISTS `think_taxi_img`;
CREATE TABLE `think_taxi_img` (
  `taxi_img_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '汽车图片详情表	',
  `taxi_id` int(11) DEFAULT NULL COMMENT '汽车列表ID',
  `taxi_images` varchar(255) DEFAULT NULL COMMENT '汽车详情图片',
  `img_status` int(1) DEFAULT NULL COMMENT '汽车公司图片ID状态(是否被删除)',
  PRIMARY KEY (`taxi_img_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_taxi_img`
-- -----------------------------
INSERT INTO `think_taxi_img` VALUES ('1', '1', '/public/uploads/images/20190726/e9af40cd0aa7f8cf86eabc69ef265593.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('2', '1', '/public/uploads/images/20190726/51057c5b789211ef7535154ff384b769.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('3', '1', '/public/uploads/images/20190726/0dad68687a57522d708792a6717abf99.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('4', '1', '/public/uploads/images/20190726/b20ef5d0774689cc964f154bdfc8aaa5.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('5', '2', '/public/uploads/images/20190728/6b98a9251a523a54fee7155cfb9e900c.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('6', '12', '/public/uploads/images/20190730/6d46335b50477d77bdef73bba818a60f.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('7', '2', '/public/uploads/images/20190730/f870c7cc43db73d0f75cdd18523e0618.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('8', '5', '/public/uploads/images/20190730/96ef49bb0345da29b8ac7c5d7019b1d2.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('9', '5', '/public/uploads/images/20190730/2930c9eeed998711012e1a5490d406b4.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('10', '5', '/public/uploads/images/20190730/ff18677feca4192a770994dc88b0a54a.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('11', '5', '/public/uploads/images/20190730/8ae772a60ce53fd5a85f135848badf38.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('12', '14', '/public/uploads/images/20190730/0f33e56c8c3d676df162334983fc06f9.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('13', '14', '/public/uploads/images/20190730/a1781cc7881748eac8ab54d88c5e0a92.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('14', '14', '/public/uploads/images/20190730/90eb47ffdaf60d1752ad8421b1ba0e8c.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('15', '14', '/public/uploads/images/20190730/0477f0873ac49f98df108d71120158b0.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('16', '14', '/public/uploads/images/20190730/a7914b954cc70d2da31641dc42b9a449.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('17', '2', '/public/uploads/images/20190730/c2f39612e72ebc1ea240fc2bac400f97.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('18', '1', '/public/uploads/images/20190730/282d326e140bd6c076aed721edf19fc3.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('19', '3', '/public/uploads/images/20190730/90d1784bb09cf7f9713d7c4e6a97f86b.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('20', '3', '/public/uploads/images/20190730/6d182a61f464ded1065909edc1aafce1.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('21', '3', '/public/uploads/images/20190730/d10c4baffcf57d269bf67b1227f16166.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('22', '3', '/public/uploads/images/20190730/f2c713f8273aa297f42355d6f5458eaf.jpg', '1');
INSERT INTO `think_taxi_img` VALUES ('23', '2', '/public/uploads/images/20190730/98bde1065d8270aaad97c56e1505cb07.jpg', '1');
INSERT INTO `think_taxi_img` VALUES ('24', '2', '/public/uploads/images/20190730/920a9fc64360fab3052f35cb1aa34584.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('25', '3', '/public/uploads/images/20190730/7dfa9f67d19f1c9e04ddc340d4966ea7.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('26', '4', '/public/uploads/images/20190730/7e1901c15833e2e72d3a01a278f435ab.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('27', '4', '/public/uploads/images/20190730/038185f91c24256fe8b54dcdfb883714.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('28', '4', '/public/uploads/images/20190730/3b5a749beb7bd41020245b80211a56a8.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('29', '4', '/public/uploads/images/20190730/6b17377e4b27d6bf39edc0b4d5af7a02.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('30', '6', '/public/uploads/images/20190730/72719ab6bac60ec2b08e0b42b0aadd05.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('31', '6', '/public/uploads/images/20190730/ff7ec2bbe3f62cf8a1306e66a65605fc.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('32', '6', '/public/uploads/images/20190730/7f4603bfd335bf98d02fe5803532dc00.jpg', '0');
INSERT INTO `think_taxi_img` VALUES ('33', '6', '/public/uploads/images/20190730/a37c7760da8de6fa7fa6d75df079153a.jpg', '0');

-- -----------------------------
-- Table structure for `think_taxi_list`
-- -----------------------------
DROP TABLE IF EXISTS `think_taxi_list`;
CREATE TABLE `think_taxi_list` (
  `taxi_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '叫车列表',
  `taxi_logo` varchar(255) DEFAULT NULL COMMENT '汽车公司logo',
  `taxi_class` varchar(255) DEFAULT NULL COMMENT '汽车公司所在区域',
  `taxi_name` varchar(255) DEFAULT NULL COMMENT '汽车公司全称',
  `taxi_content` varchar(255) DEFAULT NULL COMMENT '汽车公司介绍',
  `taxi_time` varchar(255) DEFAULT NULL COMMENT '营业时间',
  `taxi_day` varchar(255) DEFAULT NULL COMMENT '营业时间周几到周几',
  `taxi_phone` varchar(255) DEFAULT NULL COMMENT '联系电话',
  `taxi_address` varchar(255) DEFAULT NULL COMMENT '具体地址',
  `taxi_speed` int(11) DEFAULT NULL COMMENT '速度评分',
  `taxi_quality` int(11) DEFAULT NULL COMMENT '质量评分',
  `taxi_service` int(11) DEFAULT NULL COMMENT '服务质量平分',
  `taxi_all` int(11) DEFAULT NULL COMMENT '综合评分',
  `taxi_label` varchar(255) DEFAULT NULL COMMENT '汽车公司标签(24小时营业等)',
  `taxi_status` int(1) DEFAULT '1' COMMENT '推荐状态(0推荐 1未推荐，推荐之后可以展示在品质优选)',
  `collect` int(11) NOT NULL DEFAULT '0' COMMENT '收藏数量',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `exits_status` varchar(255) DEFAULT '0' COMMENT '删除状态（0为未删除 时间戳为删除时间）',
  PRIMARY KEY (`taxi_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_taxi_list`
-- -----------------------------
INSERT INTO `think_taxi_list` VALUES ('1', '/public/uploads/images/20190726/4945d54e8aaef31ec5f8e097d8e66caa.jpg', '海淀', '滴滴打车1', '公司介绍', '00:00-23:23', '周一到周日', '12345678910', '中关村', '3', '3', '3', '3', '[\"免费矿泉水\"]', '0', '2', '', '', '0');
INSERT INTO `think_taxi_list` VALUES ('2', '/public/uploads/images/20190726/2c8e4f55bb99c41985758a7b409853fb.jpg', '海淀', '快的打车2', '公司介绍', '00:00-23:23', '周一到周六', '12345678910', '长阳', '2', '2', '2', '2', '[\"24小时营业\"]', '0', '1', '', '', '0');
INSERT INTO `think_taxi_list` VALUES ('3', '/public/uploads/images/20190730/0eb4c10a26cd4a86558fd0c77911dc31.jpg', '海淀', '滴滴打车3', '公司介绍', '00:00-00:00', '周一到周一', '12345678910', '中关村', '2', '2', '2', '2', '[\"wifi\",\"wifi\"]', '0', '0', '', '', '0');
INSERT INTO `think_taxi_list` VALUES ('4', '/public/uploads/images/20190726/f04fd6c31c4ec049fb8a0cddbfce4277.jpg', '海淀', '滴滴打车4', '公司介绍', '00:00-00:00', '周一到周一', '12345678910', '中关村', '2', '2', '2', '2', '[\"24小时营业\"]', '0', '0', '', '', '0');
INSERT INTO `think_taxi_list` VALUES ('5', '/public/uploads/images/20190726/d5ca90bdef9adfae526e2480fa23925e.jpg', '东城', '滴滴打车5', '公司介绍', '00:00-19:19', '周一到周日', '12345678910', '中关村', '2', '2', '2', '2', '[\"24小时营业\"]', '1', '1', '', '', '0');
INSERT INTO `think_taxi_list` VALUES ('6', '/public/uploads/images/20190726/1ae70e7bcb8587d94269c454204676d1.jpg', '东城', '滴滴打车6', '公司介绍', '00:00-00:00', '周一到周日', '12345678910', '中关村', '2', '2', '2', '2', '[\"24小时营业\"]', '1', '0', '', '', '0');
INSERT INTO `think_taxi_list` VALUES ('7', '/public/uploads/images/20190726/59a2a05a3ffbb4622a7d892c485e36aa.jpg', '海淀', '滴滴打车7', '公司介绍', '00:00-23:23', '周一到周日', '12345678910', '中关村', '2', '2', '2', '2', '[\"wifi\"]', '1', '0', '', '', '1564128558');
INSERT INTO `think_taxi_list` VALUES ('8', '/public/uploads/images/20190726/5a070103f68b795d4143f7acb0b64835.jpg', '海淀', '滴滴打车8', '公司介绍', '00:00-22:22', '周一到周日', '12345678910', '中关村', '2', '2', '2', '2', '[\"免费矿泉水\"]', '1', '0', '', '', '0');
INSERT INTO `think_taxi_list` VALUES ('9', '/public/uploads/images/20190726/58642a9c589e96e23a7fa97587093048.jpg', '东城', '滴滴打车9', '公司介绍', '00:00-00:00', '周一到周日', '12345678910', '中关村', '2', '2', '2', '2', '[\"免费矿泉水\"]', '1', '0', '', '', '0');
INSERT INTO `think_taxi_list` VALUES ('10', '/public/uploads/images/20190726/57cdfd9d11a99499beaf574b8f77be70.jpg', '海淀', '滴滴打车10', '公司介绍', '00:00-19:19', '周一到周日', '12345678910', '中关村', '5', '5', '5', '5', '[\"wifi\"]', '1', '0', '', '', '0');
INSERT INTO `think_taxi_list` VALUES ('11', '/public/uploads/images/20190726/ecb6d4ea09734a2cc6371898277672f6.jpg', '东城', '快猴打车', '快猴打车', '00:00-00:00', '周一到周六', '18867453952', '北京东直门大街27号', '', '', '', '', '\"小时营业\"', '1', '0', '', '', '0');
INSERT INTO `think_taxi_list` VALUES ('12', '/public/uploads/images/20190726/52763f1a244f18bf0dea8e7a23168490.jpg', '东城', '曹操打车', '曹操打车曹操打车曹操打车曹操打车', '00:00-22:00', '周一到周日', '18867453952', '北京盘古大观', '', '', '', '', '[\"免费矿泉水\"]', '1', '0', '', '', '0');
INSERT INTO `think_taxi_list` VALUES ('13', '/public/uploads/images/20190727/fef544096d9bbf049eab34041d17c197.jpg', '东城', '飞鸟快车', '飞鸟快车就是快', '00:00-23:59', '周一到周日', '12584635874', '飞鸟大楼一层', '', '', '', '', '[\"免费零食\",\"免费矿泉水\"]', '1', '0', '', '', '1564449291');
INSERT INTO `think_taxi_list` VALUES ('14', '/public/uploads/images/20190730/4e7f76aa410ec5e258b942ef552624a7.jpg', '海淀', '飞鸟快车', '飞鸟快车就是快', '00:00-23:59', '周一到周日', '2342342341423', '飞鸟大厦', '', '', '', '', '[\"wifi\",\"免费矿泉水\"]', '1', '0', '', '', '1564467043');
INSERT INTO `think_taxi_list` VALUES ('15', '/public/uploads/images/20190805\\7b60d7c215c165d7746d6ec4f387ce37.jpg', '海淀', '<script>alert(11)</script>', 'dfadfa', '00:00-00:00', '周一到周一', 'asdf', 'asdf', '', '', '', '', '[\"asdf\",\"asdf\"]', '1', '0', '', '', '1564981469');
INSERT INTO `think_taxi_list` VALUES ('16', '/public/uploads/images/20190805\\cef1ed1196522a3c66bcacb386c31250.jpg', '海淀', 'alert(11)', 'fadsf', '00:00-00:00', '周一到周一', 'asdf', 'sadf', '', '', '', '', '[\"asdf\",\"asdf\"]', '1', '0', '', '', '0');

-- -----------------------------
-- Table structure for `think_taxi_user`
-- -----------------------------
DROP TABLE IF EXISTS `think_taxi_user`;
CREATE TABLE `think_taxi_user` (
  `taxi_user_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户评论汽车公司表',
  `taxi_id` int(11) DEFAULT NULL COMMENT '汽车公司ID',
  `id` int(11) DEFAULT NULL COMMENT '用户ID',
  `comment_time` int(11) DEFAULT NULL COMMENT '评论时间',
  `comment_content` varchar(255) DEFAULT NULL COMMENT '评论内容',
  `comment_images` text COMMENT '评论图片',
  `comment_all` int(11) DEFAULT NULL COMMENT '综合评分',
  `comment_speed` int(11) DEFAULT NULL COMMENT '汽车公司速度评分',
  `comment_quality` int(11) DEFAULT NULL COMMENT '汽车质量评分',
  `comment_service` int(11) DEFAULT NULL COMMENT '服务质量评分',
  `comment_sati` varchar(255) DEFAULT NULL COMMENT '满意度',
  PRIMARY KEY (`taxi_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_taxi_user`
-- -----------------------------
INSERT INTO `think_taxi_user` VALUES ('1', '1', '13', '1562997341', '评论1', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '1', '1', '1', '1', '不满意');
INSERT INTO `think_taxi_user` VALUES ('2', '1', '13', '1563012653', '这是啊2', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '2', '2', '2', '2', '不满意');
INSERT INTO `think_taxi_user` VALUES ('3', '1', '13', '1563012664', '这是啊3', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '2', '2', '2', '2', '不满意');
INSERT INTO `think_taxi_user` VALUES ('4', '1', '13', '1563012664', '这是啊4', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '2', '2', '2', '2', '不满意');
INSERT INTO `think_taxi_user` VALUES ('5', '1', '13', '1563012664', '这是啊5', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '2', '2', '2', '2', '不满意');
INSERT INTO `think_taxi_user` VALUES ('6', '1', '13', '1563012664', '这是啊6', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '2', '2', '2', '2', '不满意');
INSERT INTO `think_taxi_user` VALUES ('7', '1', '13', '1563012664', '这是啊7', '/public/uploads/dining/20190720/8a172c23333b657661f4b62d2ab14ef6.jpg', '2', '2', '2', '2', '不满意');
INSERT INTO `think_taxi_user` VALUES ('8', '1', '13', '1563012664', '111111111', 'http://ceshi.800123456.top//public/uploads/issue/20190721/96ca55f65dfe1352c79e4afc27eb3149.jpg', '3', '3', '3', '3', '一般');
INSERT INTO `think_taxi_user` VALUES ('9', '10', '212082', '1563012664', '厉害啦', '', '5', '5', '5', '5', '超满意');
INSERT INTO `think_taxi_user` VALUES ('10', '1', '212082', '1563012664', '不错不错不错', '/public/uploads/issue/20190730/f5d3e189a326c8d9b59ee17a37c61582.jpg,/public/uploads/issue/20190730/f3e5acb32d986347689f4ed368c40c12.jpg', '5', '5', '5', '5', '超满意');
INSERT INTO `think_taxi_user` VALUES ('11', '1', '13', '1563012664', '1231231', '/public/uploads/issue/20190730/a6a63eec3ff8b77afce29a99e01c2ddd.jpg', '4', '3', '3', '5', '满意');
INSERT INTO `think_taxi_user` VALUES ('12', '1', '13', '1563012664', '1231231', '/public/uploads/issue/20190730/28554eedd42b4cf6a61e3ba0cbade8b9.jpg', '3', '2', '3', '4', '一般');
INSERT INTO `think_taxi_user` VALUES ('13', '1', '13', '1563012664', 'qweqweqweqw', '/public/uploads/issue/20190730/4ba3aa84c408cdae74ef59abe41d1307.jpg,/public/uploads/issue/20190730/6bc8d4f421a790c5ab4681cc12598880.jpg', '3', '4', '2', '2', '一般');
INSERT INTO `think_taxi_user` VALUES ('14', '1', '13', '1563012664', 'aaaaa', '/public/uploads/issue/20190730/bcadad35c2ff1761174adf0ae86e80c2.jpg', '2', '2', '2', '2', '不满意');
INSERT INTO `think_taxi_user` VALUES ('15', '1', '13', '1563012664', '12312312312322aa', '/public/uploads/issue/20190730/8216a2a4cc5901f41da2778025db6e08.jpg', '3', '3', '3', '3', '一般');
INSERT INTO `think_taxi_user` VALUES ('16', '1', '212082', '1564539824', '不错不错不错', '', '4', '4', '4', '4', '满意');
INSERT INTO `think_taxi_user` VALUES ('17', '1', '212082', '1564539840', '不错不错不错', '', '2', '3', '3', '1', '不满意');
INSERT INTO `think_taxi_user` VALUES ('18', '1', '212082', '1564539857', '不错不错不错', '', '5', '5', '5', '5', '超满意');

-- -----------------------------
-- Table structure for `think_topic_cate`
-- -----------------------------
DROP TABLE IF EXISTS `think_topic_cate`;
CREATE TABLE `think_topic_cate` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '话题分类名称',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态(0:显示 1:不显示)',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='话题分类';

-- -----------------------------
-- Records of `think_topic_cate`
-- -----------------------------
INSERT INTO `think_topic_cate` VALUES ('1', '留学美国', '0', '1563104296', '1563104296');
INSERT INTO `think_topic_cate` VALUES ('2', '我在纽约', '0', '1563104296', '1563104296');
INSERT INTO `think_topic_cate` VALUES ('3', '我在美国', '1', '1564134164', '1564198735');

-- -----------------------------
-- Table structure for `think_turns_list`
-- -----------------------------
DROP TABLE IF EXISTS `think_turns_list`;
CREATE TABLE `think_turns_list` (
  `turns_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '轮播图表',
  `turns_img` varchar(255) DEFAULT NULL COMMENT '轮播图图片',
  `turns_url` varchar(255) DEFAULT NULL COMMENT '轮播图连接',
  `turns_class` int(11) unsigned DEFAULT NULL COMMENT '轮播图分类(0首页，1招聘，2出租，3买卖，4美食，5叫车，6酒店，7社区)',
  `turns_status` int(11) DEFAULT '0' COMMENT '显示状态（0：显示 1：不显示）',
  PRIMARY KEY (`turns_id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_turns_list`
-- -----------------------------
INSERT INTO `think_turns_list` VALUES ('1', '/public/uploads/turns/25235235235235345345.jpg', '', '0', '1');
INSERT INTO `think_turns_list` VALUES ('2', '/public/uploads/turns/25235235235235345345.jpg', '', '0', '1');
INSERT INTO `think_turns_list` VALUES ('3', '/public/uploads/turns/25235235235235345345.jpg', '', '0', '1');
INSERT INTO `think_turns_list` VALUES ('4', '/public/uploads/turns/25235235235235345345.jpg', '', '1', '20190725');
INSERT INTO `think_turns_list` VALUES ('5', '/public/uploads/images/20190726/a5c402f93b576ce43002acfff5973b2c.jpg', '', '1', '20190727');
INSERT INTO `think_turns_list` VALUES ('6', '/public/uploads/images/20190726/e44c8abc40d3edf3994d5cf9a742255e.jpg', '', '5', '20190727');
INSERT INTO `think_turns_list` VALUES ('7', '/public/uploads/images/20190726/d19350bddfed9cfb880184d997d6e1bd.jpg', '', '5', '20190727');
INSERT INTO `think_turns_list` VALUES ('8', '/public/uploads/images/20190726/b71a8b4b6f7b16577cd836cba76f3946.jpg', '', '5', '20190727');
INSERT INTO `think_turns_list` VALUES ('9', '/public/uploads/images/20190726/66707a7230a3bbf0de680e426773a7fb.jpg', '', '4', '20190727');
INSERT INTO `think_turns_list` VALUES ('10', '/public/uploads/images/20190726/cd077c21c7f2730c949b6d312d6b2d41.jpg', '', '4', '20190727');
INSERT INTO `think_turns_list` VALUES ('11', '/public/uploads/images/20190726/7c147f186b069d2327cdff8cf713a45d.jpg', '', '6', '20190726');
INSERT INTO `think_turns_list` VALUES ('12', '/public/uploads/images/20190726/61fdff2ab976a0538a56c635635b7766.jpg', '', '3', '20190727');
INSERT INTO `think_turns_list` VALUES ('13', '/public/uploads/images/public/uploads/turns/25235235235235345345.jpg', '', '4', '20190725');
INSERT INTO `think_turns_list` VALUES ('14', '/public/uploads/images/20190726/74a7e7d3fb136ba1961a91f4b6417abb.jpg', '', '6', '20190726');
INSERT INTO `think_turns_list` VALUES ('15', '/public/uploads/turns/25235235235235345345.jpg', '', '4', '20190725');
INSERT INTO `think_turns_list` VALUES ('16', '/public/uploads/images/20190726/ba9a5138a97bb1647a6f83166f0f96ea.jpg', '', '6', '20190726');
INSERT INTO `think_turns_list` VALUES ('17', '/public/uploads/turns/25235235235235345345.jpg', '', '5', '20190725');
INSERT INTO `think_turns_list` VALUES ('18', '/public/uploads/images/20190726/c39198c98526e98e1b8f49bb639324d5.jpg', '', '3', '0');
INSERT INTO `think_turns_list` VALUES ('19', '/public/uploads/images/20190726/c6fcca8ea3a8576621713e4f4a70d399.jpg', '', '3', '0');
INSERT INTO `think_turns_list` VALUES ('20', '/public/uploads/images/20190726/693e3410f27c8279c240ee1a0ac1cc31.jpg', '', '3', '0');
INSERT INTO `think_turns_list` VALUES ('21', '/public/uploads/images/20190726/0513cd035df5b798581fea7d99b6682e.jpg', '', '1', '20190727');
INSERT INTO `think_turns_list` VALUES ('22', '/public/uploads/images/20190726/f16c327088fff7a92100b05014c5a0fd.jpg', '', '1', '20190727');
INSERT INTO `think_turns_list` VALUES ('23', '/public/uploads/turns/25235235235235345345.jpg', '', '1', '1');
INSERT INTO `think_turns_list` VALUES ('24', '/public/uploads/images/20190726/a8be8d3f6fdeb6727f283c6cbae4fade.jpg', '', '2', '0');
INSERT INTO `think_turns_list` VALUES ('25', '/public/uploads/images/20190725/2fb3a6f0da0e2d1970aa753a14d01bd3.jpg', '', '2', '20190726');
INSERT INTO `think_turns_list` VALUES ('26', '/public/uploads/images/20190725/fd4cade060b87648a708d093026f60d8.jpg', '', '1', '20190727');
INSERT INTO `think_turns_list` VALUES ('27', '/public/uploads/images/20190725/a586bb4f6ca3f9b51ce5af8dd5ad3a09.jpg', '', '1', '20190727');
INSERT INTO `think_turns_list` VALUES ('28', '/public/uploads/images/20190726/0d564aabc8fcc128b55a8ee59f103fac.jpg', '', '2', '0');
INSERT INTO `think_turns_list` VALUES ('29', '/public/uploads/images/20190726/e3768ddcb7dbf24032337f90c64b3e66.jpg', '', '2', '0');
INSERT INTO `think_turns_list` VALUES ('30', '/public/uploads/images/20190726/8cc1d1f0523f427c1aa749d3a27c93fe.jpg', '', '7', '20190727');
INSERT INTO `think_turns_list` VALUES ('31', '/public/uploads/images/20190727/9bea46efb1b087f5e64c59e48e97f63b.jpg', '', '0', '0');
INSERT INTO `think_turns_list` VALUES ('32', '/public/uploads/images/20190727/de27d4f7f00bcc985bd8bc80207a2bdd.jpg', '', '0', '0');
INSERT INTO `think_turns_list` VALUES ('33', '/public/uploads/images/20190727/1188c89f99997a1508cc821eb63ce3e1.jpg', '', '0', '0');
INSERT INTO `think_turns_list` VALUES ('34', '/public/uploads/images/20190727/7a6f2d632fa156c38826a5b4161335a2.jpg', '', '1', '0');
INSERT INTO `think_turns_list` VALUES ('35', '/public/uploads/images/20190727/58856bcd46a59abce5e7a3f9f5a86144.jpg', '', '1', '0');
INSERT INTO `think_turns_list` VALUES ('36', '/public/uploads/images/20190727/0055200ce0279e231e9fafade151b7a5.jpg', '', '1', '0');
INSERT INTO `think_turns_list` VALUES ('37', '/public/uploads/images/20190727/2890e5a2f38986a3d282960e5a300573.jpg', '', '4', '0');
INSERT INTO `think_turns_list` VALUES ('38', '/public/uploads/images/20190727/fbf28788e9a0f7a0a33bd3bb757f8dac.jpg', '', '4', '0');
INSERT INTO `think_turns_list` VALUES ('39', '/public/uploads/images/20190727/bc743c6e656d0fc53f98353e5a878116.jpg', '', '4', '0');
INSERT INTO `think_turns_list` VALUES ('40', '/public/uploads/images/20190727/2e1afbedd045a9ba26aac8b38538b8bc.jpg', '', '5', '0');
INSERT INTO `think_turns_list` VALUES ('41', '/public/uploads/images/20190727/581582bd05dc3330c4d25ea11efeb393.jpg', '', '5', '0');
INSERT INTO `think_turns_list` VALUES ('42', '/public/uploads/images/20190727/39d9626b9c89adfd2442570c0ede5b60.jpg', '', '5', '0');
INSERT INTO `think_turns_list` VALUES ('43', '/public/uploads/images/20190727/aee6879acdf19ae8f0ddcd2d41b5ffc7.jpg', '', '6', '0');
INSERT INTO `think_turns_list` VALUES ('44', '/public/uploads/images/20190727/5ae9d321059b4413e3ddd8cd8492df89.jpg', '', '6', '0');
INSERT INTO `think_turns_list` VALUES ('45', '/public/uploads/images/20190727/26411257fd0cab0632b3cdab1e11e8fb.jpg', '', '6', '0');
INSERT INTO `think_turns_list` VALUES ('46', '/public/uploads/images/20190727/5c21284bb07ed5727b2169c1d6587863.jpg', '', '7', '0');
INSERT INTO `think_turns_list` VALUES ('47', '/public/uploads/images/20190727/3983089bdc9d2d751b7339cf134304c7.jpg', '', '7', '0');
INSERT INTO `think_turns_list` VALUES ('48', '/public/uploads/images/20190727/6776742a17e865d24201897a2d6499c5.jpg', '', '7', '0');

-- -----------------------------
-- Table structure for `think_used_comment`
-- -----------------------------
DROP TABLE IF EXISTS `think_used_comment`;
CREATE TABLE `think_used_comment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `used_id` int(11) unsigned NOT NULL COMMENT '二手物品ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '用户ID',
  `body` text NOT NULL COMMENT '评论内容',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '审核状态(0:已审核 1:未审核 2:审核未通过)',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COMMENT='二手物品评论';

-- -----------------------------
-- Records of `think_used_comment`
-- -----------------------------
INSERT INTO `think_used_comment` VALUES ('1', '1', '13', '评论测试1', '1', '1563615791', '1563615791');
INSERT INTO `think_used_comment` VALUES ('2', '1', '13', '评论测试1', '1', '1563615793', '1563615793');
INSERT INTO `think_used_comment` VALUES ('3', '1', '13', '评论测试1', '1', '1563615795', '1563615795');
INSERT INTO `think_used_comment` VALUES ('4', '2', '13', '评论测试1', '1', '1563615799', '1563615799');
INSERT INTO `think_used_comment` VALUES ('5', '2', '13', '评论测试1', '1', '1563615801', '1563615801');
INSERT INTO `think_used_comment` VALUES ('6', '2', '13', '评论测试1', '1', '1563615804', '1563615804');
INSERT INTO `think_used_comment` VALUES ('7', '3', '13', '评论测试1', '1', '1563615808', '1563615808');
INSERT INTO `think_used_comment` VALUES ('8', '3', '13', '评论测试1', '1', '1563615811', '1563615811');
INSERT INTO `think_used_comment` VALUES ('9', '3', '13', '评论测试1', '1', '1563615812', '1563615812');
INSERT INTO `think_used_comment` VALUES ('10', '3', '13', '评论测试1', '1', '1563627663', '1563627663');
INSERT INTO `think_used_comment` VALUES ('11', '3', '13', '评论测试1', '1', '1563638282', '1563638282');
INSERT INTO `think_used_comment` VALUES ('12', '7', '13', '12312312312323123', '1', '1564480130', '1564480130');
INSERT INTO `think_used_comment` VALUES ('13', '7', '13', '12312312312323123', '1', '1564480147', '1564480147');
INSERT INTO `think_used_comment` VALUES ('14', '7', '13', 'xwwwa', '1', '1564480260', '1564480260');
INSERT INTO `think_used_comment` VALUES ('15', '3', '13', '评论测试1', '1', '1564480502', '1564480502');
INSERT INTO `think_used_comment` VALUES ('16', '7', '13', 'aaaaaaa', '1', '1564480564', '1564480564');
INSERT INTO `think_used_comment` VALUES ('17', '7', '13', 'asdasdas', '1', '1564480926', '1564480926');

-- -----------------------------
-- Table structure for `think_used_comment_image`
-- -----------------------------
DROP TABLE IF EXISTS `think_used_comment_image`;
CREATE TABLE `think_used_comment_image` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` int(11) unsigned NOT NULL COMMENT '评论ID',
  `path` varchar(255) DEFAULT NULL COMMENT '图片路径',
  `create_time` int(11) unsigned DEFAULT NULL,
  `update_time` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COMMENT='二手物品评论图片';

-- -----------------------------
-- Records of `think_used_comment_image`
-- -----------------------------
INSERT INTO `think_used_comment_image` VALUES ('1', '1', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563615791', '1563615791');
INSERT INTO `think_used_comment_image` VALUES ('2', '1', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563615791', '1563615791');
INSERT INTO `think_used_comment_image` VALUES ('3', '2', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563615793', '1563615793');
INSERT INTO `think_used_comment_image` VALUES ('4', '2', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563615794', '1563615794');
INSERT INTO `think_used_comment_image` VALUES ('5', '3', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563615795', '1563615795');
INSERT INTO `think_used_comment_image` VALUES ('6', '3', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563615795', '1563615795');
INSERT INTO `think_used_comment_image` VALUES ('7', '4', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563615799', '1563615799');
INSERT INTO `think_used_comment_image` VALUES ('8', '4', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563615799', '1563615799');
INSERT INTO `think_used_comment_image` VALUES ('9', '5', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563615801', '1563615801');
INSERT INTO `think_used_comment_image` VALUES ('10', '5', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563615801', '1563615801');
INSERT INTO `think_used_comment_image` VALUES ('11', '6', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563615804', '1563615804');
INSERT INTO `think_used_comment_image` VALUES ('12', '6', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563615804', '1563615804');
INSERT INTO `think_used_comment_image` VALUES ('13', '7', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563615808', '1563615808');
INSERT INTO `think_used_comment_image` VALUES ('14', '7', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563615808', '1563615808');
INSERT INTO `think_used_comment_image` VALUES ('15', '8', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563615811', '1563615811');
INSERT INTO `think_used_comment_image` VALUES ('16', '8', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563615811', '1563615811');
INSERT INTO `think_used_comment_image` VALUES ('17', '9', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563615812', '1563615812');
INSERT INTO `think_used_comment_image` VALUES ('18', '9', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563615812', '1563615812');
INSERT INTO `think_used_comment_image` VALUES ('19', '10', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563627663', '1563627663');
INSERT INTO `think_used_comment_image` VALUES ('20', '10', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563627663', '1563627663');
INSERT INTO `think_used_comment_image` VALUES ('21', '11', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563638282', '1563638282');
INSERT INTO `think_used_comment_image` VALUES ('22', '11', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563638282', '1563638282');
INSERT INTO `think_used_comment_image` VALUES ('23', '12', '/public/uploads/issue/20190730/a05b1630f4d7ddc79df3f1eeab6dd5cc.png', '1564480130', '1564480130');
INSERT INTO `think_used_comment_image` VALUES ('24', '13', '/public/uploads/issue/20190730/a05b1630f4d7ddc79df3f1eeab6dd5cc.png', '1564480147', '1564480147');
INSERT INTO `think_used_comment_image` VALUES ('25', '14', '/public/uploads/issue/20190730/370f9828b46836089462a4b327d7980b.png', '1564480260', '1564480260');
INSERT INTO `think_used_comment_image` VALUES ('26', '15', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1564480502', '1564480502');
INSERT INTO `think_used_comment_image` VALUES ('27', '15', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1564480502', '1564480502');
INSERT INTO `think_used_comment_image` VALUES ('28', '16', '/public/uploads/issue/20190730/c0e1c69389463f6a1cd5f2fc6bde404a.jpg', '1564480564', '1564480564');
INSERT INTO `think_used_comment_image` VALUES ('29', '17', '/public/uploads/issue/20190730/a8052b7571477c17d093a7a84adb0466.jpg', '1564480926', '1564480926');

-- -----------------------------
-- Table structure for `think_used_image`
-- -----------------------------
DROP TABLE IF EXISTS `think_used_image`;
CREATE TABLE `think_used_image` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `used_id` int(10) unsigned NOT NULL COMMENT '二手商品ID',
  `path` varchar(255) DEFAULT NULL COMMENT '二手商品图片路径',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COMMENT='二手物品图片';

-- -----------------------------
-- Records of `think_used_image`
-- -----------------------------
INSERT INTO `think_used_image` VALUES ('1', '1', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563615731', '1563615731');
INSERT INTO `think_used_image` VALUES ('2', '1', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563615731', '1563615731');
INSERT INTO `think_used_image` VALUES ('3', '1', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563615731', '1563615731');
INSERT INTO `think_used_image` VALUES ('4', '2', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563615752', '1563615752');
INSERT INTO `think_used_image` VALUES ('5', '2', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563615752', '1563615752');
INSERT INTO `think_used_image` VALUES ('6', '2', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563615752', '1563615752');
INSERT INTO `think_used_image` VALUES ('7', '3', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563615759', '1563615759');
INSERT INTO `think_used_image` VALUES ('8', '3', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563615759', '1563615759');
INSERT INTO `think_used_image` VALUES ('9', '3', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563615759', '1563615759');
INSERT INTO `think_used_image` VALUES ('10', '4', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563624333', '1563624333');
INSERT INTO `think_used_image` VALUES ('11', '5', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563624350', '1563624350');
INSERT INTO `think_used_image` VALUES ('12', '6', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563627263', '1563627263');
INSERT INTO `think_used_image` VALUES ('13', '6', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563627263', '1563627263');
INSERT INTO `think_used_image` VALUES ('14', '6', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563627263', '1563627263');
INSERT INTO `think_used_image` VALUES ('15', '7', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563638278', '1563638278');
INSERT INTO `think_used_image` VALUES ('16', '7', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563638278', '1563638278');
INSERT INTO `think_used_image` VALUES ('17', '7', '\\/public\\/uploads\\/issue\\/20190720\\/0fa9a8c2674b2fb62bb21c724c0eb54e.jpg', '1563638278', '1563638278');

-- -----------------------------
-- Table structure for `think_used_product`
-- -----------------------------
DROP TABLE IF EXISTS `think_used_product`;
CREATE TABLE `think_used_product` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `region_id` int(10) unsigned NOT NULL COMMENT '区域id',
  `body` text NOT NULL COMMENT '商品描述',
  `price` decimal(10,2) NOT NULL DEFAULT '1.00' COMMENT '商品价格',
  `sticky_create_time` int(11) unsigned DEFAULT NULL COMMENT '置顶开始时间',
  `sticky_end_time` int(11) unsigned DEFAULT NULL COMMENT '置顶结束时间',
  `sticky_status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '置顶状态(0:置顶1:不置顶)',
  `phone` int(32) NOT NULL COMMENT '电话',
  `praise` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '点赞数量',
  `browse` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览量',
  `review` int(11) NOT NULL DEFAULT '0' COMMENT '评论数量',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '发布状态(0:以审核,1:未审核2:审核未通过)',
  `create_time` int(11) unsigned NOT NULL COMMENT '创建日期',
  `update_time` int(11) unsigned NOT NULL COMMENT '修改日期',
  `collect` int(11) NOT NULL DEFAULT '0' COMMENT '收藏数量',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='二手物品';

-- -----------------------------
-- Records of `think_used_product`
-- -----------------------------
INSERT INTO `think_used_product` VALUES ('1', '13', '1', '二手商品1', '150.22', '0', '0', '1', '2147483647', '0', '4', '3', '0', '1563615731', '1564106803', '1');
INSERT INTO `think_used_product` VALUES ('2', '13', '1', '二手商品2', '150.22', '0', '0', '1', '2147483647', '0', '2', '3', '0', '1563615752', '1564106301', '1');
INSERT INTO `think_used_product` VALUES ('3', '13', '1', '二手商品3', '150.22', '0', '0', '1', '2147483647', '0', '0', '6', '0', '1563615759', '1563615759', '0');
INSERT INTO `think_used_product` VALUES ('4', '13', '1', '11111111', '1111111.00', '0', '0', '1', '1111111', '0', '0', '0', '0', '1563624333', '1563624333', '0');
INSERT INTO `think_used_product` VALUES ('5', '13', '2', '111111', '11111.00', '1563624350', '1564056350', '1', '11111', '1', '10', '0', '0', '1563624350', '1564058083', '1');
INSERT INTO `think_used_product` VALUES ('6', '13', '1', '二手商品3', '150.22', '0', '0', '1', '2147483647', '0', '0', '0', '0', '1563627263', '1563627263', '0');
INSERT INTO `think_used_product` VALUES ('7', '13', '1', '二手商品3', '150.22', '0', '0', '1', '2147483647', '0', '22', '5', '0', '1563638278', '1564480909', '1');

-- -----------------------------
-- Table structure for `think_user`
-- -----------------------------
DROP TABLE IF EXISTS `think_user`;
CREATE TABLE `think_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account` varchar(20) DEFAULT NULL COMMENT '认证的手机号码',
  `nickname` varchar(32) DEFAULT NULL COMMENT '昵称',
  `password` char(32) DEFAULT NULL,
  `head_img` varchar(255) DEFAULT NULL COMMENT '头像',
  `status` tinyint(1) DEFAULT NULL COMMENT '1激活  0 未激活',
  `token` varchar(255) DEFAULT '0' COMMENT '令牌',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_user`
-- -----------------------------
INSERT INTO `think_user` VALUES ('1', '18693281982', '田建龙', 'e10adc3949ba59abbe56e057f20f883e', 'http://123.56.237.22:8888/group1/M00/00/08/ezjtFlj4IHyAcjlzAABDms0T3Kk671.jpg', '1', 'LWBYIiLWinNiulNXYD1UzGgfynNx+gy/zmq5Ega0E0we4a0WyB8UaG4x+VKRoc9CG4e1BXrqZww=');
INSERT INTO `think_user` VALUES ('2', '18993075721', '账号1', 'e10adc3949ba59abbe56e057f20f883e', 'http://opgkfon0o.bkt.clouddn.com/108.png', '1', 'VslU7gKYuddZFPq4ssWLZCNYBsi3YQIicyG1jm5pUfvZHI4qw03b3A2sygA4efLyWHRkYBQX8LAscwsA7sLzhg==');
INSERT INTO `think_user` VALUES ('3', '15095340657', '呼丽华', 'e10adc3949ba59abbe56e057f20f883e', 'http://123.56.237.22:8888/group1/M00/00/00/ezjtFliGwvWAaYeXAABu1D1rZNo655.jpg', '1', '2d8471d156a9e6db155145571cedea5a');

-- -----------------------------
-- Table structure for `think_user_list`
-- -----------------------------
DROP TABLE IF EXISTS `think_user_list`;
CREATE TABLE `think_user_list` (
  `user_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nickname` varchar(255) DEFAULT NULL COMMENT '昵称',
  `sex` varchar(255) DEFAULT NULL COMMENT '性别',
  `country` varchar(255) DEFAULT NULL COMMENT '国家',
  `city` varchar(255) DEFAULT NULL COMMENT '城市',
  `province` varchar(255) DEFAULT NULL COMMENT '省份',
  `user_img` varchar(255) DEFAULT NULL COMMENT '用户头像',
  `every_time` varchar(255) DEFAULT NULL COMMENT '登录时间(计算是否当天可以签到)',
  `user_token` varchar(255) DEFAULT NULL COMMENT '用户token值',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_user_list`
-- -----------------------------
INSERT INTO `think_user_list` VALUES ('2', '火炎焱か', '1', 'China', 'Taian', 'Shandong', 'https://wx.qlogo.cn/mmopen/vi_32/CJZibDZdvTBSCVAHv7R2xbic2gtaAOXt4XNeYXRpZXQVoLmaoiby0SJ30uaX7TsyVX3rujj5Zc9HjLZ2qovZ9ajiag/132', '1562775803', '35692dce422d5711ba79693fde893da1');

-- -----------------------------
-- Table structure for `think_user_login`
-- -----------------------------
DROP TABLE IF EXISTS `think_user_login`;
CREATE TABLE `think_user_login` (
  `login_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_token` varchar(255) DEFAULT NULL,
  `openid` varchar(255) DEFAULT NULL,
  `login_time` varchar(255) DEFAULT NULL COMMENT '登录时间',
  PRIMARY KEY (`login_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_user_login`
-- -----------------------------
INSERT INTO `think_user_login` VALUES ('12', '35692dce422d5711ba79693fde893da1', 'ozBCf4u7oQJ2aipXSVN0zdr7Mu64', '1562775392');
INSERT INTO `think_user_login` VALUES ('13', '416af5bbbf2b83b3b3d4857e4e506867', 'owxMC0c3FXPZRlCwvyM_OczqQizU', '1563431788');
INSERT INTO `think_user_login` VALUES ('14', '196088cbf60cd7373278ed907dec6814', 'owxMC0VcdPIQSOJraZp0ZzqvBhSI', '1564192068');
INSERT INTO `think_user_login` VALUES ('15', '9658db24be1c6cefff85634efe340386', 'owxMC0U_gGxJn01LdHryIOpP2f8E', '1564483301');
INSERT INTO `think_user_login` VALUES ('16', '8d0c0d8c56ba6d8f1c9191472959d81a', 'owxMC0cHY-Sn0TZLDXQp41EzCjXQ', '1564970805');

-- -----------------------------
-- Table structure for `think_user_task`
-- -----------------------------
DROP TABLE IF EXISTS `think_user_task`;
CREATE TABLE `think_user_task` (
  `task_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户任务完成表',
  `id` int(11) DEFAULT NULL COMMENT '用户ID',
  `sign` varchar(255) DEFAULT NULL COMMENT '签到时间',
  `sign_type` int(1) DEFAULT '2' COMMENT '签到任务状态(0 已领取 2未完成)',
  `collect` varchar(255) DEFAULT NULL COMMENT '收藏时间',
  `collect_type` int(1) DEFAULT '2' COMMENT '收藏任务状态(0 已领取 2未完成)',
  `publish` varchar(255) DEFAULT NULL COMMENT '发表时间',
  `publish_type` int(1) DEFAULT '2' COMMENT '发表任务状态(0 已领取 2未完成)',
  `share` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '分享时间',
  `share_type` int(1) DEFAULT '2' COMMENT '分享任务状态(0 已领取 2未完成)',
  PRIMARY KEY (`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_user_task`
-- -----------------------------
INSERT INTO `think_user_task` VALUES ('4', '22', '1563254020', '1', '', '2', '', '2', '1563254020', '1');
INSERT INTO `think_user_task` VALUES ('48', '13', '20190726', '0', '20190730', '0', '20190730', '0', '', '2');
INSERT INTO `think_user_task` VALUES ('49', '212082', '20190731', '0', '20190731', '0', '20190801', '0', '20190801', '0');
